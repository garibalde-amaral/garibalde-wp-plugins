<?php
/**
 * Plugin Name: Garibalde Amaral — Central Digital do Cliente
 * Description: Central de triagem inicial, ditado por voz e recebimento controlado de documentos com armazenamento fora do diretório público quando o servidor permitir.
 * Version: 1.1.1
 * Author: Garibalde Amaral Advogados Associados
 * Requires at least: 6.2
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) { exit; }

final class GA_Central_Digital_Cliente {
    const VERSION = '1.1.1';
    const PAGE_SLUG = 'central-digital-do-cliente';
    const TABLE_SUFFIX = 'ga_cdc_intakes';
    const FILES_TABLE_SUFFIX = 'ga_cdc_attachments';
    const OPTION_PRIVACY_URL = 'ga_cdc_privacy_url';
    const OPTION_NOTIFY_EMAIL = 'ga_cdc_notify_email';
    const OPTION_STORAGE_DIR = 'ga_cdc_private_storage_dir';
    const OPTION_SCHEMA = 'ga_cdc_schema_version';
    const MAX_FILES = 3;
    const MAX_FILE_BYTES = 5 * 1024 * 1024;
    const MAX_TOTAL_BYTES = 6 * 1024 * 1024;

    public static function init() {
        add_action('plugins_loaded', [__CLASS__, 'maybe_upgrade'], 5);
        add_shortcode('ga_central_digital', [__CLASS__, 'render_shortcode']);
        add_action('admin_menu', [__CLASS__, 'admin_menu']);
        add_action('admin_init', [__CLASS__, 'register_settings']);
        add_action('admin_notices', [__CLASS__, 'admin_notices']);
        add_action('admin_post_nopriv_ga_cdc_submit', [__CLASS__, 'handle_submit']);
        add_action('admin_post_ga_cdc_submit', [__CLASS__, 'handle_submit']);
        add_action('admin_post_ga_cdc_delete', [__CLASS__, 'handle_delete']);
        add_action('admin_post_ga_cdc_download_file', [__CLASS__, 'handle_download_file']);
        add_filter('wp_nav_menu_items', [__CLASS__, 'append_menu_link'], 20, 2);
        add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
    }

    public static function activate() {
        self::upgrade_schema();
        self::ensure_private_storage();
        self::ensure_page();
        if (!get_option(self::OPTION_NOTIFY_EMAIL)) {
            update_option(self::OPTION_NOTIFY_EMAIL, get_option('admin_email'));
        }
        update_option(self::OPTION_SCHEMA, self::VERSION);
        flush_rewrite_rules();
    }

    public static function deactivate() {
        // Keep intake records and private documents on deactivation; never delete client data silently.
        flush_rewrite_rules();
    }

    public static function maybe_upgrade() {
        if (get_option(self::OPTION_SCHEMA) !== self::VERSION) {
            self::upgrade_schema();
            self::ensure_private_storage();
            update_option(self::OPTION_SCHEMA, self::VERSION);
        }
    }

    private static function upgrade_schema() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $intakes = $wpdb->prefix . self::TABLE_SUFFIX;
        $files = $wpdb->prefix . self::FILES_TABLE_SUFFIX;
        $sql1 = "CREATE TABLE {$intakes} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            created_at datetime NOT NULL,
            full_name varchar(180) NOT NULL,
            phone varchar(40) NOT NULL,
            email varchar(190) NOT NULL,
            area varchar(80) NOT NULL,
            summary text NOT NULL,
            consent_at datetime NOT NULL,
            status varchar(24) NOT NULL DEFAULT 'novo',
            PRIMARY KEY  (id),
            KEY created_at (created_at),
            KEY status (status)
        ) {$charset};";
        $sql2 = "CREATE TABLE {$files} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            intake_id bigint(20) unsigned NOT NULL,
            original_name varchar(255) NOT NULL,
            stored_name varchar(80) NOT NULL,
            mime varchar(120) NOT NULL,
            size_bytes bigint(20) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY intake_id (intake_id)
        ) {$charset};";
        dbDelta($sql1);
        dbDelta($sql2);
    }

    private static function ensure_page() {
        $existing = get_page_by_path(self::PAGE_SLUG, OBJECT, 'page');
        if (!$existing) {
            wp_insert_post([
                'post_title'   => 'Central Digital do Cliente',
                'post_name'    => self::PAGE_SLUG,
                'post_type'    => 'page',
                'post_status'  => 'publish',
                'post_content' => '[ga_central_digital]',
                'post_excerpt' => 'Atendimento inicial e encaminhamento digital da Garibalde Amaral Advogados Associados.',
            ], true);
        }
    }

    private static function path_is_inside($path, $root) {
        $path = rtrim(str_replace('\\', '/', (string) $path), '/');
        $root = rtrim(str_replace('\\', '/', (string) $root), '/');
        if ($path === '' || $root === '') { return false; }
        return $path === $root || strpos($path . '/', $root . '/') === 0;
    }

    private static function ensure_private_storage() {
        $wp_root = realpath(ABSPATH);
        if (!$wp_root) { $wp_root = untrailingslashit(ABSPATH); }
        $docroot = isset($_SERVER['DOCUMENT_ROOT']) ? realpath(wp_unslash($_SERVER['DOCUMENT_ROOT'])) : false;
        if (!$docroot) { $docroot = $wp_root; }
        $base = dirname($wp_root);
        $guard = 0;
        while (self::path_is_inside($base, $docroot) && $guard < 8) {
            $parent = dirname($base);
            if ($parent === $base) { break; }
            $base = $parent;
            $guard++;
        }
        $target = trailingslashit($base) . 'ga-central-digital-private';
        if (!is_dir($target)) {
            if (!@mkdir($target, 0700, true) && !is_dir($target)) {
                delete_option(self::OPTION_STORAGE_DIR);
                return false;
            }
        }
        @chmod($target, 0700);
        $real = realpath($target);
        if (!$real || self::path_is_inside($real, $docroot) || !is_writable($real)) {
            delete_option(self::OPTION_STORAGE_DIR);
            return false;
        }
        // Defensive files; primary protection is that the directory is outside DOCUMENT_ROOT.
        if (!file_exists(trailingslashit($real) . 'index.php')) {
            @file_put_contents(trailingslashit($real) . 'index.php', "<?php\nhttp_response_code(404);\nexit;\n");
        }
        if (!file_exists(trailingslashit($real) . '.htaccess')) {
            @file_put_contents(trailingslashit($real) . '.htaccess', "Require all denied\n");
        }
        update_option(self::OPTION_STORAGE_DIR, $real, false);
        return true;
    }

    private static function storage_dir() {
        $dir = get_option(self::OPTION_STORAGE_DIR, '');
        if (!$dir || !is_dir($dir) || !is_writable($dir)) { return false; }
        $real = realpath($dir);
        $docroot = isset($_SERVER['DOCUMENT_ROOT']) ? realpath(wp_unslash($_SERVER['DOCUMENT_ROOT'])) : false;
        if (!$docroot) { $docroot = realpath(ABSPATH); }
        if (!$real || !$docroot || self::path_is_inside($real, $docroot)) { return false; }
        return $real;
    }

    public static function admin_notices() {
        if (!current_user_can('manage_options')) { return; }
        $central_page = get_page_by_path(self::PAGE_SLUG, OBJECT, 'page');
        if ($central_page && strpos((string) $central_page->post_content, '[ga_central_digital]') === false) {
            echo '<div class="notice notice-warning"><p><strong>Central Digital:</strong> já existe uma página com o endereço esperado, mas ela não contém o shortcode [ga_central_digital]. Para não sobrescrever o conteúdo existente, o plugin a preservou. Confira a página e insira o shortcode no editor antes de divulgar o link.</p></div>';
        }
        if (!self::storage_dir()) {
            echo '<div class="notice notice-warning"><p><strong>Central Digital:</strong> o servidor não permitiu confirmar um diretório privado fora da área pública. O formulário de triagem continuará funcionando, mas o envio de arquivos ficará desabilitado até a configuração segura do armazenamento.</p></div>';
        }
        if (!class_exists('finfo')) {
            echo '<div class="notice notice-error"><p><strong>Central Digital:</strong> a extensão PHP fileinfo não está disponível. O recebimento de anexos será desabilitado até que a hospedagem habilite essa extensão.</p></div>';
        }
        if (!class_exists('ZipArchive')) {
            echo '<div class="notice notice-warning"><p><strong>Central Digital:</strong> a extensão PHP ZipArchive não foi detectada. O envio de arquivos DOCX será desabilitado; PDF e imagens só ficarão disponíveis se o armazenamento privado e a extensão fileinfo estiverem validados.</p></div>';
        }
    }

    public static function enqueue_assets() {
        if (!is_page(self::PAGE_SLUG)) { return; }
        wp_register_style('ga-cdc-inline', false, [], self::VERSION);
        wp_enqueue_style('ga-cdc-inline');
        wp_add_inline_style('ga-cdc-inline', self::css());
        wp_register_script('ga-cdc-inline', false, [], self::VERSION, true);
        wp_enqueue_script('ga-cdc-inline');
        wp_add_inline_script('ga-cdc-inline', self::js());
    }

    private static function page_url() {
        $page = get_page_by_path(self::PAGE_SLUG, OBJECT, 'page');
        if ($page && !empty($page->ID)) {
            $permalink = get_permalink($page->ID);
            if ($permalink) { return $permalink; }
        }
        return home_url('/' . self::PAGE_SLUG . '/');
    }

    private static function asset_url($name) {
        return plugins_url('assets/' . ltrim($name, '/'), __FILE__);
    }

    private static function css() {
        return '
        .ga-cdc{--ga-espresso:#241915;--ga-graphite:#302724;--ga-ivory:#F2EEE7;--ga-gold:#C99A55;--ga-silver:#B8BBC0;--ga-mist:#D9D2CC;--ga-ink:#2b2724;--ga-muted:#6a625c;--ga-line:#ddd4cb;max-width:1160px;margin:0 auto;padding:clamp(18px,4vw,48px) 16px;color:var(--ga-ink);font-family:inherit}
        .ga-cdc *{box-sizing:border-box}.ga-cdc-hero{background:linear-gradient(125deg,var(--ga-espresso) 0%,var(--ga-graphite) 100%);border:1px solid rgba(201,154,85,.45);border-radius:18px;padding:clamp(22px,4vw,48px);color:var(--ga-ivory);position:relative;overflow:hidden}
        .ga-cdc-brand{display:flex;gap:20px;align-items:center}.ga-cdc-logo{width:88px;height:88px;object-fit:contain;border-radius:12px;flex:none;background:#1b110d}.ga-cdc-kicker{font-size:.76rem;letter-spacing:.14em;text-transform:uppercase;color:#dcb77d;font-weight:700;margin:0 0 10px}.ga-cdc h1{color:var(--ga-ivory);font-size:clamp(1.9rem,4vw,3rem);line-height:1.1;max-width:760px;margin:0 0 14px;letter-spacing:-.025em}.ga-cdc-hero p.ga-cdc-hero-copy{max-width:800px;color:#f1e9df;font-size:1.03rem;line-height:1.7;margin:18px 0 0}
        .ga-cdc-security{display:flex;gap:10px;align-items:flex-start;margin-top:20px;font-size:.9rem;color:#e6dcd0;line-height:1.6}.ga-cdc-security svg{flex:none;margin-top:2px}.ga-cdc-section-title{font-size:clamp(1.4rem,3vw,1.85rem);color:var(--ga-espresso);margin:32px 0 8px;letter-spacing:-.02em}.ga-cdc-intro{color:var(--ga-muted);line-height:1.65;margin:0 0 20px;max-width:830px}
        .ga-cdc-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:15px}.ga-cdc-card{border:1px solid var(--ga-line);border-radius:14px;padding:22px;background:#fff;box-shadow:0 6px 20px rgba(36,25,21,.045)}.ga-cdc-card h3{margin:0 0 8px;font-size:1.08rem;color:var(--ga-espresso)}.ga-cdc-card p{margin:0;color:var(--ga-muted);line-height:1.6;font-size:.94rem}.ga-cdc-icon{height:40px;width:40px;border-radius:10px;background:var(--ga-ivory);color:var(--ga-espresso);display:flex;align-items:center;justify-content:center;margin-bottom:16px;font-size:1.1rem;border:1px solid var(--ga-line)}
        .ga-cdc-downloads{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin:18px 0 24px}.ga-cdc-download{border:1px solid var(--ga-line);border-radius:14px;background:#fff;padding:19px}.ga-cdc-download h3{margin:0 0 8px;color:var(--ga-espresso);font-size:1.02rem}.ga-cdc-download p{margin:0 0 14px;color:var(--ga-muted);font-size:.91rem;line-height:1.55}.ga-cdc-download-links{display:flex;gap:9px;flex-wrap:wrap}.ga-cdc-download-links a{display:inline-flex;align-items:center;justify-content:center;padding:9px 12px;border:1px solid #c9b48f;border-radius:9px;color:var(--ga-espresso);text-decoration:none;font-weight:700;font-size:.88rem}.ga-cdc-download-links a:hover{background:var(--ga-ivory)}
        .ga-cdc-form-wrap{margin-top:20px;border:1px solid var(--ga-line);border-radius:16px;padding:clamp(18px,4vw,32px);background:#fbf9f6}.ga-cdc-form-wrap h2{margin:0 0 8px;color:var(--ga-espresso);font-size:1.5rem}.ga-cdc-form-intro{color:var(--ga-muted);line-height:1.6;margin:0 0 22px}.ga-cdc-form{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:15px}.ga-cdc-field{display:flex;flex-direction:column;gap:7px;min-width:0}.ga-cdc-field-full{grid-column:1/-1}.ga-cdc-field label{font-weight:650;color:#352c26;font-size:.93rem}.ga-cdc input[type=text],.ga-cdc input[type=email],.ga-cdc input[type=tel],.ga-cdc input[type=file],.ga-cdc select,.ga-cdc textarea{width:100%;padding:12px 13px;border:1px solid #cfc4b8;border-radius:9px;background:#fff;color:#2b2724;font:inherit;min-height:46px}.ga-cdc input[type=file]{padding:10px}.ga-cdc textarea{min-height:140px;resize:vertical}.ga-cdc input:focus,.ga-cdc select:focus,.ga-cdc textarea:focus{outline:3px solid rgba(201,154,85,.25);border-color:#9f7438}.ga-cdc-help{font-size:.82rem;color:var(--ga-muted);line-height:1.5}.ga-cdc-consent{display:flex;gap:10px;align-items:flex-start;line-height:1.55;font-size:.89rem;color:#443b34}.ga-cdc-consent input{margin-top:5px;flex:none}.ga-cdc-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;border:1px solid #b48644;border-radius:999px;background:var(--ga-gold);color:var(--ga-espresso);padding:13px 22px;min-height:48px;font-weight:750;text-decoration:none;cursor:pointer;line-height:1.2}.ga-cdc-btn:hover{filter:brightness(.97);color:var(--ga-espresso)}.ga-cdc-btn:focus{outline:3px solid rgba(201,154,85,.35);outline-offset:3px}.ga-cdc-btn-secondary{background:#fff;border:1px solid #cfc4b8;color:var(--ga-espresso)}.ga-cdc-actions{display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin-top:15px}.ga-cdc-status{padding:15px 17px;border-radius:10px;background:#f0f4ec;border:1px solid #c7d6bb;color:#33432a;margin:0 0 20px;line-height:1.55}.ga-cdc-notice{padding:15px 18px;border-left:4px solid var(--ga-gold);background:#f7f1e7;color:#493a2c;border-radius:0 9px 9px 0;line-height:1.6;margin:18px 0}.ga-cdc-footer-note{font-size:.82rem;color:var(--ga-muted);line-height:1.6;margin:22px 0 0}.ga-cdc-hp{position:absolute!important;left:-9999px!important;width:1px!important;height:1px!important;overflow:hidden!important}.ga-cdc-small-link{color:#69451b;text-decoration:underline;text-underline-offset:3px}
        @media(max-width:800px){.ga-cdc-grid{grid-template-columns:1fr}.ga-cdc-downloads{grid-template-columns:1fr}.ga-cdc-form{grid-template-columns:1fr}.ga-cdc-field-full{grid-column:auto}.ga-cdc-brand{align-items:flex-start;gap:14px}.ga-cdc-logo{width:64px;height:64px}.ga-cdc-hero{border-radius:13px}.ga-cdc-card{padding:19px}.ga-cdc-actions{align-items:stretch;flex-direction:column}.ga-cdc-btn{width:100%;text-align:center}.ga-cdc-download-links a{flex:1}}
        @media(prefers-reduced-motion:reduce){.ga-cdc *{scroll-behavior:auto!important;transition:none!important;animation:none!important}}
        ';
    }

    private static function js() {
        return "(function(){function ready(fn){if(document.readyState!=='loading'){fn()}else{document.addEventListener('DOMContentLoaded',fn)}}ready(function(){var btn=document.querySelector('[data-ga-cdc-voice]');var ta=document.getElementById('ga-cdc-summary');var status=document.getElementById('ga-cdc-voice-status');if(!btn||!ta)return;var SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){btn.disabled=true;btn.setAttribute('aria-disabled','true');if(status)status.textContent='Ditado por voz não é compatível com este navegador. Você pode digitar normalmente.';return;}btn.addEventListener('click',function(){var rec=new SR();rec.lang='pt-BR';rec.interimResults=false;rec.maxAlternatives=1;btn.disabled=true;if(status)status.textContent='Ouvindo… fale agora.';rec.onresult=function(e){var t=e.results&&e.results[0]&&e.results[0][0]?e.results[0][0].transcript:'';if(t){ta.value=(ta.value?ta.value+' ':'')+t;ta.dispatchEvent(new Event('input',{bubbles:true}));}if(status)status.textContent='Texto reconhecido. Revise antes de enviar; o áudio não é armazenado por esta página.';};rec.onerror=function(){if(status)status.textContent='Não foi possível reconhecer a fala. Digite o relato ou tente novamente.';};rec.onend=function(){btn.disabled=false;};try{rec.start();}catch(err){btn.disabled=false;if(status)status.textContent='Não foi possível iniciar o ditado neste momento.';}});});})();";
    }

    public static function render_shortcode() {
        $privacy_url = esc_url(get_option(self::OPTION_PRIVACY_URL, ''));
        $status = isset($_GET['ga_cdc_status']) ? sanitize_key(wp_unslash($_GET['ga_cdc_status'])) : '';
        $storage_ready = (bool) self::storage_dir();
        $upload_ready = $storage_ready && class_exists('finfo');
        $docx_upload_ready = $upload_ready && class_exists('ZipArchive');
        $accepted_uploads = $docx_upload_ready ? '.pdf,.docx,.jpg,.jpeg,.png' : '.pdf,.jpg,.jpeg,.png';
        ob_start(); ?>
        <main class="ga-cdc">
          <section class="ga-cdc-hero" aria-labelledby="ga-cdc-title">
            <div class="ga-cdc-brand">
              <img class="ga-cdc-logo" src="<?php echo esc_url(self::asset_url('logo-oficial.png')); ?>" alt="Logotipo oficial Garibalde Amaral Advogados Associados" width="88" height="88" loading="eager">
              <div><p class="ga-cdc-kicker">Garibalde Amaral Advogados Associados</p><h1 id="ga-cdc-title">Central Digital do Cliente</h1><p class="ga-cdc-hero-copy">Um ponto de entrada organizado para iniciar contato com o escritório e encaminhar informações de forma estruturada.</p></div>
            </div>
            <div class="ga-cdc-security"><span aria-hidden="true">◆</span><span>Envie apenas informações necessárias. O formulário não cria, por si só, relação contratual, não confirma aceitação do caso e não substitui a análise do escritório.</span></div>
          </section>

          <?php if ($status === 'recebido') : ?>
            <div class="ga-cdc-status" role="status"><strong>Solicitação recebida.</strong> A equipe poderá entrar em contato pelos dados informados. O envio não confirma contratação nem conclusão de análise jurídica.</div>
          <?php elseif ($status === 'erro') : ?>
            <div class="ga-cdc-notice" role="alert"><strong>Não foi possível enviar.</strong> Confira os campos obrigatórios, os formatos e o tamanho dos arquivos e tente novamente. Se o problema persistir, use o canal de contato assistido do escritório.</div>
          <?php elseif ($status === 'upload_indisponivel') : ?>
            <div class="ga-cdc-notice" role="alert"><strong>Envio de documentos temporariamente indisponível.</strong> Nenhum arquivo foi enviado. Encaminhe apenas os dados de contato sem anexos e aguarde o retorno do escritório por canal seguro.</div>
          <?php endif; ?>

          <section class="ga-cdc-form-wrap" aria-labelledby="ga-cdc-docs-title">
            <h2 id="ga-cdc-docs-title">Documentos do cliente</h2>
            <p class="ga-cdc-form-intro">Os modelos de procuração e declaração econômica estão em revisão técnica e não são disponibilizados nesta versão. O escritório publicará os documentos após concluir a revisão jurídica e visual. Não utilize versões antigas ou rascunhos como documentos finais.</p>
          </section>

          <h2 class="ga-cdc-section-title">Como funciona o primeiro contato</h2>
          <div class="ga-cdc-grid" aria-label="Etapas do atendimento">
            <article class="ga-cdc-card"><div class="ga-cdc-icon" aria-hidden="true">01</div><h3>Identifique o assunto</h3><p>Selecione a área aproximada e informe como o escritório pode retornar.</p></article>
            <article class="ga-cdc-card"><div class="ga-cdc-icon" aria-hidden="true">02</div><h3>Descreva o essencial</h3><p>Use texto ou ditado por voz. Revise nomes, datas e o conteúdo antes de enviar.</p></article>
            <article class="ga-cdc-card"><div class="ga-cdc-icon" aria-hidden="true">03</div><h3>Aguarde o encaminhamento</h3><p>A equipe fará a triagem inicial e indicará o próximo passo, se houver possibilidade de atendimento.</p></article>
          </div>

          <section class="ga-cdc-form-wrap" aria-labelledby="ga-cdc-form-title">
            <h2 id="ga-cdc-form-title">Iniciar atendimento</h2>
            <p class="ga-cdc-form-intro">Campos com * são obrigatórios. Não informe senhas ou dados bancários. Anexe apenas documentos pertinentes ao assunto, quando o campo seguro estiver disponível.</p>
            <form class="ga-cdc-form" method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
              <input type="hidden" name="action" value="ga_cdc_submit">
              <?php wp_nonce_field('ga_cdc_submit', 'ga_cdc_nonce'); ?>
              <div class="ga-cdc-hp" aria-hidden="true"><label>Deixe vazio <input type="text" name="company_website" tabindex="-1" autocomplete="off"></label></div>
              <div class="ga-cdc-field"><label for="ga-cdc-name">Nome completo *</label><input id="ga-cdc-name" name="full_name" type="text" maxlength="180" autocomplete="name" required></div>
              <div class="ga-cdc-field"><label for="ga-cdc-phone">Telefone com DDD *</label><input id="ga-cdc-phone" name="phone" type="tel" maxlength="40" autocomplete="tel" required></div>
              <div class="ga-cdc-field"><label for="ga-cdc-email">E-mail *</label><input id="ga-cdc-email" name="email" type="email" maxlength="190" autocomplete="email" required></div>
              <div class="ga-cdc-field"><label for="ga-cdc-area">Assunto principal *</label><select id="ga-cdc-area" name="area" required><option value="">Selecione</option><option>Trabalhista</option><option>Cível e contratos</option><option>Consumidor</option><option>Família e sucessões</option><option>Previdenciário</option><option>Imobiliário</option><option>Empresarial</option><option>Administrativo</option><option>Outro / não sei identificar</option></select></div>
              <div class="ga-cdc-field ga-cdc-field-full"><label for="ga-cdc-summary">Resumo inicial</label><textarea id="ga-cdc-summary" name="summary" maxlength="3000" placeholder="Em poucas linhas, informe o assunto e o que precisa esclarecer."></textarea><div class="ga-cdc-actions"><button class="ga-cdc-btn ga-cdc-btn-secondary" type="button" data-ga-cdc-voice>Ditado por voz</button><span class="ga-cdc-help" id="ga-cdc-voice-status" aria-live="polite">Se compatível com o navegador, a fala será convertida em texto no dispositivo. O áudio não será enviado.</span></div></div>
              <?php if ($upload_ready) : ?>
              <div class="ga-cdc-field ga-cdc-field-full"><label for="ga-cdc-documents">Documentos relacionados (opcional)</label><input id="ga-cdc-documents" name="documents[]" type="file" multiple accept="<?php echo esc_attr($accepted_uploads); ?>"><span class="ga-cdc-help">Até 3 arquivos; <?php echo $docx_upload_ready ? 'PDF, DOCX, JPG ou PNG' : 'PDF, JPG ou PNG (DOCX indisponível neste servidor)'; ?>; máximo de 5 MB por arquivo e 6 MB no total. Os arquivos são guardados em diretório privado fora da área pública quando o servidor confirma essa condição. Não envie documentos sem relação com o caso.</span></div>
              <?php else : ?>
              <div class="ga-cdc-field ga-cdc-field-full"><div class="ga-cdc-notice"><strong>Envio privado de documentos ainda não está habilitado neste servidor.</strong> Você pode concluir o contato sem anexos; o escritório solicitará os documentos por canal apropriado.</div></div>
              <?php endif; ?>
              <div class="ga-cdc-field ga-cdc-field-full"><label class="ga-cdc-consent"><input type="checkbox" name="consent" value="1" required><span>Autorizo o uso dos dados informados e, se anexados, dos documentos para retorno e triagem inicial pelo escritório. Entendo que o formulário não cria, por si só, relação contratual nem garante aceitação do caso. <?php if ($privacy_url) : ?><a class="ga-cdc-small-link" href="<?php echo $privacy_url; ?>" target="_blank" rel="noopener">Ler aviso de privacidade</a><?php endif; ?></span></label></div>
              <div class="ga-cdc-field ga-cdc-field-full"><button class="ga-cdc-btn" type="submit">Enviar solicitação inicial <span aria-hidden="true">→</span></button><span class="ga-cdc-help">A triagem inicial não é uma consulta jurídica automatizada. Se a situação exigir providência urgente, informe isso ao escritório por um canal de contato assistido.</span></div>
            </form>
          </section>
          <div class="ga-cdc-notice"><strong>Privacidade:</strong> evite publicar informações pessoais em comentários de redes sociais. A página “Consulta Processual” é separada e serve somente para consulta de processos; o atendimento inicial deve começar por esta Central Digital.</div>
          <p class="ga-cdc-footer-note">Os modelos documentais permanecem temporariamente indisponíveis enquanto passam por revisão. Esta versão não oferece preenchimento automático, assinatura eletrônica, acompanhamento público por protocolo nem respostas automáticas por WhatsApp.</p>
        </main>
        <?php return ob_get_clean();
    }

    private static function normalized_uploads() {
        if (empty($_FILES['documents']) || !isset($_FILES['documents']['name']) || !is_array($_FILES['documents']['name'])) { return []; }
        $files = $_FILES['documents'];
        $result = [];
        $total = 0;
        $count = count($files['name']);
        if ($count > self::MAX_FILES) { return false; }
        for ($i = 0; $i < $count; $i++) {
            $err = isset($files['error'][$i]) ? (int) $files['error'][$i] : UPLOAD_ERR_NO_FILE;
            if ($err === UPLOAD_ERR_NO_FILE) { continue; }
            if ($err !== UPLOAD_ERR_OK) { return false; }
            $tmp = isset($files['tmp_name'][$i]) ? $files['tmp_name'][$i] : '';
            $original = isset($files['name'][$i]) ? sanitize_file_name(wp_unslash($files['name'][$i])) : '';
            $size = isset($files['size'][$i]) ? (int) $files['size'][$i] : 0;
            $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));
            if (!$tmp || !is_uploaded_file($tmp) || !$original || !$size || $size > self::MAX_FILE_BYTES) { return false; }
            $total += $size;
            if ($total > self::MAX_TOTAL_BYTES) { return false; }
            if (!in_array($ext, ['pdf','docx','jpg','jpeg','png'], true)) { return false; }
            if (!class_exists('finfo')) { return false; }
            $fi = new finfo(FILEINFO_MIME_TYPE);
            $mime = $fi->file($tmp);
            $ok = false;
            if ($ext === 'pdf' && $mime === 'application/pdf') { $ok = true; }
            if (in_array($ext, ['jpg','jpeg'], true) && $mime === 'image/jpeg') { $ok = true; }
            if ($ext === 'png' && $mime === 'image/png') { $ok = true; }
            if ($ext === 'docx') {
                $zip_mimes = ['application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/zip','application/x-zip'];
                if (in_array($mime, $zip_mimes, true) && class_exists('ZipArchive')) {
                    $zip = new ZipArchive();
                    if ($zip->open($tmp) === true) {
                        $ok = ($zip->locateName('[Content_Types].xml') !== false && $zip->locateName('word/document.xml') !== false);
                        $zip->close();
                    }
                }
            }
            if (!$ok) { return false; }
            $result[] = ['tmp'=>$tmp, 'original'=>$original, 'ext'=>($ext === 'jpeg' ? 'jpg' : $ext), 'mime'=>$mime, 'size'=>$size];
        }
        return $result;
    }

    public static function handle_submit() {
        if (!isset($_POST['ga_cdc_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['ga_cdc_nonce'])), 'ga_cdc_submit')) {
            self::redirect_status('erro');
        }
        if (!empty($_POST['company_website'])) {
            self::redirect_status('recebido');
        }
        $name = isset($_POST['full_name']) ? sanitize_text_field(wp_unslash($_POST['full_name'])) : '';
        $phone = isset($_POST['phone']) ? sanitize_text_field(wp_unslash($_POST['phone'])) : '';
        $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
        $area = isset($_POST['area']) ? sanitize_text_field(wp_unslash($_POST['area'])) : '';
        $summary = isset($_POST['summary']) ? sanitize_textarea_field(wp_unslash($_POST['summary'])) : '';
        $consent = isset($_POST['consent']) && (string) wp_unslash($_POST['consent']) === '1';
        $allowed_areas = ['Trabalhista','Cível e contratos','Consumidor','Família e sucessões','Previdenciário','Imobiliário','Empresarial','Administrativo','Outro / não sei identificar'];
        if (!$name || !$phone || !$email || !is_email($email) || !in_array($area, $allowed_areas, true) || !$consent || strlen($summary) > 3000) {
            self::redirect_status('erro');
        }
        $uploads_present = !empty($_FILES['documents']['name']) && is_array($_FILES['documents']['name']) && count(array_filter($_FILES['documents']['name'])) > 0;
        if ($uploads_present && !self::storage_dir()) { self::redirect_status('upload_indisponivel'); }
        $uploads = self::normalized_uploads();
        if ($uploads === false) { self::redirect_status('erro'); }

        // Rate-limit by a one-way IP hash; the raw IP address is not stored.
        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown';
        $rate_key = 'ga_cdc_rate_' . substr(hash_hmac('sha256', $ip, wp_salt('nonce')), 0, 32);
        if (get_transient($rate_key)) { self::redirect_status('erro'); }
        set_transient($rate_key, 1, 60);

        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;
        $now = current_time('mysql');
        $inserted = $wpdb->insert($table, [
            'created_at' => $now,
            'full_name' => $name,
            'phone' => $phone,
            'email' => $email,
            'area' => $area,
            'summary' => $summary,
            'consent_at' => $now,
            'status' => 'novo',
        ], ['%s','%s','%s','%s','%s','%s','%s','%s']);
        if (!$inserted) { self::redirect_status('erro'); }
        $intake_id = (int) $wpdb->insert_id;
        $saved_paths = [];
        $files_table = $wpdb->prefix . self::FILES_TABLE_SUFFIX;
        $storage = self::storage_dir();
        foreach ($uploads as $file) {
            try { $stored = bin2hex(random_bytes(16)) . '.' . $file['ext']; }
            catch (Exception $e) { $stored = wp_generate_password(32, false, false) . '.' . $file['ext']; }
            $target = trailingslashit($storage) . $stored;
            if (!@move_uploaded_file($file['tmp'], $target)) {
                self::rollback_submission($intake_id, $saved_paths);
                self::redirect_status('erro');
            }
            @chmod($target, 0600);
            $saved_paths[] = $target;
            $file_mime = ($file['ext'] === 'docx') ? 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' : $file['mime'];
            $ok = $wpdb->insert($files_table, [
                'intake_id' => $intake_id,
                'original_name' => $file['original'],
                'stored_name' => $stored,
                'mime' => $file_mime,
                'size_bytes' => $file['size'],
                'created_at' => $now,
            ], ['%d','%s','%s','%s','%d','%s']);
            if (!$ok) {
                self::rollback_submission($intake_id, $saved_paths);
                self::redirect_status('erro');
            }
        }
        $to = sanitize_email(get_option(self::OPTION_NOTIFY_EMAIL, get_option('admin_email')));
        if ($to && is_email($to)) {
            $subject = sprintf('Nova solicitação na Central Digital — registro #%d', $intake_id);
            $body = "Uma solicitação inicial foi recebida.\n\nRegistro: #{$intake_id}\nÁrea: {$area}\nAnexos: " . count($uploads) . "\nData: {$now}\n\nPor privacidade, o relato, os dados de contato e os arquivos não foram incluídos neste e-mail. Entre no WordPress e acesse Central Digital > Solicitações.";
            wp_mail($to, $subject, $body);
        }
        self::redirect_status('recebido');
    }

    private static function rollback_submission($intake_id, $paths) {
        global $wpdb;
        foreach ($paths as $path) { if (is_file($path)) { @unlink($path); } }
        $wpdb->delete($wpdb->prefix . self::FILES_TABLE_SUFFIX, ['intake_id'=>(int)$intake_id], ['%d']);
        $wpdb->delete($wpdb->prefix . self::TABLE_SUFFIX, ['id'=>(int)$intake_id], ['%d']);
    }

    private static function redirect_status($status) {
        $referer = wp_get_referer();
        $url = $referer ? $referer : self::page_url();
        $url = remove_query_arg(['ga_cdc_status'], $url);
        wp_safe_redirect(add_query_arg('ga_cdc_status', sanitize_key($status), $url));
        exit;
    }

    public static function admin_menu() {
        add_menu_page('Solicitações da Central Digital', 'Central Digital', 'manage_options', 'ga-cdc', [__CLASS__, 'render_admin_page'], 'dashicons-id-alt', 26);
        add_submenu_page('ga-cdc', 'Configurações', 'Configurações', 'manage_options', 'ga-cdc-settings', [__CLASS__, 'render_settings_page']);
    }

    public static function register_settings() {
        register_setting('ga_cdc_settings', self::OPTION_PRIVACY_URL, ['type'=>'string','sanitize_callback'=>'esc_url_raw','default'=>'']);
        register_setting('ga_cdc_settings', self::OPTION_NOTIFY_EMAIL, ['type'=>'string','sanitize_callback'=>'sanitize_email','default'=>get_option('admin_email')]);
    }

    public static function render_settings_page() {
        if (!current_user_can('manage_options')) { return; }
        $storage_ready = (bool) self::storage_dir();
        $finfo_ready = class_exists('finfo');
        $zip_ready = class_exists('ZipArchive');
        $central_page = get_page_by_path(self::PAGE_SLUG, OBJECT, 'page');
        $page_ready = $central_page && strpos((string) $central_page->post_content, '[ga_central_digital]') !== false; ?>
        <div class="wrap"><h1>Central Digital do Cliente — Configurações</h1><p>Configure o aviso de privacidade e o e-mail que recebe somente o alerta de nova solicitação. O e-mail não inclui relato nem arquivos do cliente.</p>
          <table class="widefat striped" style="max-width:920px;margin:18px 0"><tbody><tr><th>Página de atendimento</th><td><?php echo $page_ready ? '<strong style="color:#176b35">Página localizada e shortcode presente — ainda precisa de teste público</strong>' : ($central_page ? '<strong style="color:#98502b">Página existente sem shortcode — revisar manualmente</strong>' : '<strong style="color:#98502b">Página não localizada — conferir a ativação</strong>'); ?></td></tr><tr><th>Armazenamento privado de documentos</th><td><?php echo $storage_ready ? '<strong style="color:#176b35">Validado localmente como fora do diretório público</strong>' : '<strong style="color:#98502b">Não validado — envio de anexos desabilitado</strong>'; ?></td></tr><tr><th>Extensão PHP fileinfo</th><td><?php echo $finfo_ready ? '<strong style="color:#176b35">Disponível</strong>' : '<strong style="color:#98502b">Ausente — anexos desabilitados</strong>'; ?></td></tr><tr><th>Extensão PHP ZipArchive</th><td><?php echo $zip_ready ? '<strong style="color:#176b35">Disponível — DOCX pode ser validado</strong>' : '<strong style="color:#98502b">Ausente — DOCX não será aceito</strong>'; ?></td></tr><tr><th>Limite</th><td>Até 3 arquivos; 5 MB por arquivo e 6 MB totais. O limite também depende das configurações PHP da hospedagem.</td></tr></tbody></table>
          <form method="post" action="options.php"><?php settings_fields('ga_cdc_settings'); ?>
            <table class="form-table" role="presentation"><tr><th scope="row"><label for="ga-cdc-privacy-url">URL do aviso de privacidade</label></th><td><input class="regular-text" type="url" id="ga-cdc-privacy-url" name="<?php echo esc_attr(self::OPTION_PRIVACY_URL); ?>" value="<?php echo esc_attr(get_option(self::OPTION_PRIVACY_URL, '')); ?>"><p class="description">Deixe em branco até existir uma página de privacidade revisada e publicada.</p></td></tr><tr><th scope="row"><label for="ga-cdc-notify-email">E-mail de alerta</label></th><td><input class="regular-text" type="email" id="ga-cdc-notify-email" name="<?php echo esc_attr(self::OPTION_NOTIFY_EMAIL); ?>" value="<?php echo esc_attr(get_option(self::OPTION_NOTIFY_EMAIL, get_option('admin_email'))); ?>" required><p class="description">O e-mail contém apenas o número de protocolo interno, a área e a quantidade de anexos.</p></td></tr></table>
            <?php submit_button('Salvar configurações'); ?>
          </form><hr><p><strong>Limites desta versão:</strong> os modelos documentais estão indisponíveis nesta versão enquanto passam por revisão. Não há assinatura eletrônica, análise jurídica automatizada, integração com WhatsApp recebendo mensagens ou painel de acompanhamento público. O escritório deve definir prazo de retenção e rotina de eliminação dos dados.</p></div>
        <?php
    }

    public static function render_admin_page() {
        if (!current_user_can('manage_options')) { wp_die('Acesso não autorizado.'); }
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;
        $files_table = $wpdb->prefix . self::FILES_TABLE_SUFFIX;
        $rows = $wpdb->get_results("SELECT id, created_at, full_name, phone, email, area, summary, consent_at, status FROM {$table} ORDER BY id DESC LIMIT 100");
        echo '<div class="wrap"><h1>Central Digital do Cliente — Solicitações</h1><p>Área restrita a administradores. Os anexos são servidos somente por ação autenticada; não encaminhe dados do cliente por e-mail.</p>';
        if (!$rows) { echo '<p>Nenhuma solicitação recebida.</p></div>'; return; }
        echo '<table class="widefat striped"><thead><tr><th>ID / Data</th><th>Contato</th><th>Área</th><th>Resumo inicial</th><th>Arquivos</th><th>Consentimento</th><th>Ação</th></tr></thead><tbody>';
        foreach ($rows as $row) {
            echo '<tr><td>#' . (int)$row->id . '<br>' . esc_html($row->created_at) . '<br><strong>' . esc_html($row->status) . '</strong></td>';
            echo '<td><strong>' . esc_html($row->full_name) . '</strong><br>' . esc_html($row->phone) . '<br><a href="mailto:' . esc_attr($row->email) . '">' . esc_html($row->email) . '</a></td>';
            echo '<td>' . esc_html($row->area) . '</td><td style="min-width:220px;max-width:360px;white-space:pre-wrap">' . esc_html($row->summary) . '</td><td>';
            $attachments = $wpdb->get_results($wpdb->prepare("SELECT id, original_name, size_bytes FROM {$files_table} WHERE intake_id = %d ORDER BY id ASC", (int)$row->id));
            if ($attachments) {
                foreach ($attachments as $att) {
                    $url = wp_nonce_url(admin_url('admin-post.php?action=ga_cdc_download_file&file_id=' . (int)$att->id), 'ga_cdc_download_file_' . (int)$att->id);
                    echo '<a href="' . esc_url($url) . '">' . esc_html($att->original_name) . '</a> <small>(' . esc_html(size_format((int)$att->size_bytes)) . ')</small><br>';
                }
            } else { echo '—'; }
            echo '</td><td>' . esc_html($row->consent_at) . '</td><td><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" onsubmit="return confirm(\'Excluir permanentemente este registro e seus anexos?\')">';
            echo '<input type="hidden" name="action" value="ga_cdc_delete"><input type="hidden" name="id" value="' . (int)$row->id . '">';
            wp_nonce_field('ga_cdc_delete_' . (int)$row->id, 'ga_cdc_delete_nonce');
            echo '<button type="submit" class="button button-secondary">Excluir</button></form></td></tr>';
        }
        echo '</tbody></table><p class="description">A listagem mostra os 100 registros mais recentes. Esta versão não elimina automaticamente dados antigos; estabeleça prazo de retenção e faça revisão periódica.</p></div>';
    }

    public static function handle_download_file() {
        if (!current_user_can('manage_options')) { wp_die('Acesso não autorizado.'); }
        $id = isset($_GET['file_id']) ? absint($_GET['file_id']) : 0;
        $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';
        if (!$id || !wp_verify_nonce($nonce, 'ga_cdc_download_file_' . $id)) { wp_die('Validação de segurança falhou.'); }
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare('SELECT original_name, stored_name, mime, size_bytes FROM ' . $wpdb->prefix . self::FILES_TABLE_SUFFIX . ' WHERE id = %d', $id));
        $dir = self::storage_dir();
        if (!$row || !$dir) { wp_die('Arquivo não encontrado ou armazenamento privado indisponível.'); }
        $stored = basename((string)$row->stored_name);
        $path = trailingslashit($dir) . $stored;
        if (!is_file($path) || realpath($path) === false || strpos(realpath($path), trailingslashit(realpath($dir))) !== 0) { wp_die('Arquivo não encontrado.'); }
        $mime = in_array($row->mime, ['application/pdf','application/vnd.openxmlformats-officedocument.wordprocessingml.document','image/jpeg','image/png'], true) ? $row->mime : 'application/octet-stream';
        $name = sanitize_file_name($row->original_name);
        nocache_headers();
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . (string) filesize($path));
        header("Content-Disposition: attachment; filename*=UTF-8''" . rawurlencode($name));
        header('X-Content-Type-Options: nosniff');
        readfile($path);
        exit;
    }

    public static function handle_delete() {
        if (!current_user_can('manage_options')) { wp_die('Acesso não autorizado.'); }
        $id = isset($_POST['id']) ? absint($_POST['id']) : 0;
        $nonce = isset($_POST['ga_cdc_delete_nonce']) ? sanitize_text_field(wp_unslash($_POST['ga_cdc_delete_nonce'])) : '';
        if (!$id || !wp_verify_nonce($nonce, 'ga_cdc_delete_' . $id)) { wp_die('Validação de segurança falhou.'); }
        global $wpdb;
        $files_table = $wpdb->prefix . self::FILES_TABLE_SUFFIX;
        $rows = $wpdb->get_results($wpdb->prepare("SELECT stored_name FROM {$files_table} WHERE intake_id = %d", $id));
        $dir = self::storage_dir();
        if ($rows && $dir) {
            foreach ($rows as $r) {
                $path = trailingslashit($dir) . basename((string)$r->stored_name);
                if (is_file($path) && realpath($path) && strpos(realpath($path), trailingslashit(realpath($dir))) === 0) { @unlink($path); }
            }
        }
        $wpdb->delete($files_table, ['intake_id'=>$id], ['%d']);
        $wpdb->delete($wpdb->prefix . self::TABLE_SUFFIX, ['id'=>$id], ['%d']);
        wp_safe_redirect(admin_url('admin.php?page=ga-cdc&deleted=1'));
        exit;
    }

    public static function append_menu_link($items, $args) {
        if (!is_object($args) || empty($args->theme_location)) { return $items; }
        $location = strtolower((string) $args->theme_location);
        $is_header = (strpos($location, 'primary') !== false || strpos($location, 'main') !== false || strpos($location, 'header') !== false || strpos($location, 'top') !== false || strpos($location, 'navigation') !== false);
        if (!$is_header || strpos($location, 'footer') !== false) { return $items; }
        $url = self::page_url();
        if (strpos($items, esc_url($url)) !== false || strpos($items, 'menu-item-ga-central-digital') !== false) { return $items; }
        return $items . '<li class="menu-item menu-item-ga-central-digital"><a href="' . esc_url($url) . '">Central Digital do Cliente</a></li>';
    }
}

GA_Central_Digital_Cliente::init();
register_activation_hook(__FILE__, ['GA_Central_Digital_Cliente', 'activate']);
register_deactivation_hook(__FILE__, ['GA_Central_Digital_Cliente', 'deactivate']);
