<?php
/**
 * Plugin Name: Garibalde Amaral — Fale Conosco
 * Description: Recupera o conteúdo vazio da página Fale Conosco com formulário responsivo, acessível e protegido contra spam.
 * Version: 1.0.0
 * Author: Garibalde Amaral Advogados Associados
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 * Text Domain: garibalde-fale-conosco
 */

if (!defined('ABSPATH')) { exit; }

final class GA_Fale_Conosco {
    const VERSION = '1.0.0';
    const NONCE_ACTION = 'ga_fale_conosco_submit';
    const NONCE_NAME = 'ga_fale_conosco_nonce';

    public static function init() {
        add_shortcode('ga_fale_conosco', array(__CLASS__, 'render_form'));
        add_filter('the_content', array(__CLASS__, 'repair_empty_contact_page'), 99);
        add_action('admin_post_nopriv_ga_fale_conosco_submit', array(__CLASS__, 'handle_submit'));
        add_action('admin_post_ga_fale_conosco_submit', array(__CLASS__, 'handle_submit'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue_styles'));
    }

    public static function enqueue_styles() {
        if (!is_page('fale-conosco')) { return; }
        wp_register_style('ga-fale-conosco', false, array(), self::VERSION);
        wp_enqueue_style('ga-fale-conosco');
        wp_add_inline_style('ga-fale-conosco', self::css());
    }

    private static function content_is_empty($content) {
        $decoded = html_entity_decode((string) $content, ENT_QUOTES | ENT_HTML5, get_bloginfo('charset') ?: 'UTF-8');
        $text = preg_replace('/[\s\p{Z}\x{00A0}\x{200B}\x{FEFF}]+/u', '', wp_strip_all_tags($decoded));
        if ($text !== '') { return false; }
        // Don't replace intentional image-only content.
        if (preg_match('/<(img|picture|video|iframe|audio|object|embed)\b/i', (string) $content)) { return false; }
        return true;
    }

    public static function repair_empty_contact_page($content) {
        if (is_admin() || !is_singular('page') || !is_page('fale-conosco') || !in_the_loop() || !is_main_query()) {
            return $content;
        }
        if (self::content_is_empty($content)) {
            return self::render_form();
        }
        return $content;
    }

    public static function render_form() {
        $status = isset($_GET['ga_contact_status']) ? sanitize_key(wp_unslash($_GET['ga_contact_status'])) : '';
        $notice = '';
        if ($status === 'sent') {
            $notice = '<div class="ga-contact-notice ga-contact-success" role="status">Mensagem enviada. Obrigado. A equipe analisará o contato e retornará pelos dados informados.</div>';
        } elseif ($status === 'error') {
            $notice = '<div class="ga-contact-notice ga-contact-error" role="alert">Não foi possível confirmar o envio agora. Tente novamente ou utilize o WhatsApp do escritório.</div>';
        } elseif ($status === 'invalid') {
            $notice = '<div class="ga-contact-notice ga-contact-error" role="alert">Confira os campos obrigatórios e o consentimento antes de enviar.</div>';
        } elseif ($status === 'limit') {
            $notice = '<div class="ga-contact-notice ga-contact-error" role="alert">Recebemos muitas tentativas deste acesso. Aguarde alguns minutos e tente novamente.</div>';
        }

        $action = esc_url(admin_url('admin-post.php'));
        $whatsapp_url = 'https://wa.me/5562991340228?text=' . rawurlencode('Olá, entrei pelo site da Garibalde Amaral Advogados Associados e gostaria de informações sobre atendimento.');
        ob_start(); ?>
        <section class="ga-contact" aria-labelledby="ga-contact-title">
            <div class="ga-contact-intro">
                <span class="ga-contact-eyebrow">ATENDIMENTO DIGITAL</span>
                <h2 id="ga-contact-title">Como podemos orientar você?</h2>
                <p>Envie uma mensagem inicial. Nossa equipe indicará o próximo passo e, quando necessário, encaminhará você à Central Digital do Cliente para continuidade segura do atendimento.</p>
            </div>
            <?php echo $notice; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
            <form class="ga-contact-form" method="post" action="<?php echo $action; ?>">
                <input type="hidden" name="action" value="ga_fale_conosco_submit">
                <input type="hidden" name="redirect_to" value="<?php echo esc_url(get_permalink()); ?>">
                <?php wp_nonce_field(self::NONCE_ACTION, self::NONCE_NAME); ?>
                <div class="ga-contact-hp" aria-hidden="true">
                    <label for="ga-contact-website">Não preencha este campo</label>
                    <input id="ga-contact-website" type="text" name="ga_contact_website" tabindex="-1" autocomplete="off">
                </div>
                <div class="ga-contact-grid">
                    <div class="ga-field">
                        <label for="ga-contact-name">Nome completo <span aria-hidden="true">*</span></label>
                        <input id="ga-contact-name" name="ga_contact_name" type="text" maxlength="120" autocomplete="name" required>
                    </div>
                    <div class="ga-field">
                        <label for="ga-contact-phone">Telefone / WhatsApp <span aria-hidden="true">*</span></label>
                        <input id="ga-contact-phone" name="ga_contact_phone" type="tel" maxlength="30" autocomplete="tel" inputmode="tel" required>
                    </div>
                    <div class="ga-field ga-field-full">
                        <label for="ga-contact-email">E-mail</label>
                        <input id="ga-contact-email" name="ga_contact_email" type="email" maxlength="190" autocomplete="email">
                    </div>
                    <div class="ga-field ga-field-full">
                        <label for="ga-contact-topic">Assunto</label>
                        <select id="ga-contact-topic" name="ga_contact_topic">
                            <option value="Orientação inicial">Orientação inicial</option>
                            <option value="Direito empresarial e contratos">Direito empresarial e contratos</option>
                            <option value="Direito tributário">Direito tributário</option>
                            <option value="Direito civil">Direito civil</option>
                            <option value="Direito do trabalho">Direito do trabalho</option>
                            <option value="Processo em andamento no escritório">Processo em andamento no escritório</option>
                            <option value="Outro assunto">Outro assunto</option>
                        </select>
                    </div>
                    <div class="ga-field ga-field-full">
                        <label for="ga-contact-message">Mensagem inicial <span aria-hidden="true">*</span></label>
                        <textarea id="ga-contact-message" name="ga_contact_message" rows="5" maxlength="4000" required placeholder="Descreva brevemente o motivo do contato, sem incluir dados sigilosos ou documentos neste formulário."></textarea>
                        <div class="ga-field-hint">Até 4.000 caracteres. Não envie senhas, dados bancários ou documentos confidenciais por este formulário.</div>
                    </div>
                </div>
                <label class="ga-contact-consent"><input type="checkbox" name="ga_contact_consent" value="1" required> <span>Autorizo o uso dos dados informados para responder a esta solicitação, conforme a finalidade de atendimento e a política de privacidade do escritório.</span></label>
                <div class="ga-contact-actions">
                    <button type="submit" class="ga-contact-submit">Enviar mensagem <span aria-hidden="true">→</span></button>
                    <a class="ga-contact-whatsapp" href="<?php echo esc_url($whatsapp_url); ?>" target="_blank" rel="noopener noreferrer">Continuar pelo WhatsApp</a>
                </div>
                <p class="ga-contact-footnote">O envio desta mensagem não constitui contratação nem substitui protocolo processual. O formulário não recebe anexos; se forem necessários documentos, a equipe indicará o canal apropriado.</p>
            </form>
        </section>
        <?php
        return ob_get_clean();
    }

    public static function handle_submit() {
        $redirect = isset($_POST['redirect_to']) ? wp_validate_redirect(wp_unslash($_POST['redirect_to']), home_url('/fale-conosco/')) : home_url('/fale-conosco/');
        if (!isset($_POST[self::NONCE_NAME]) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST[self::NONCE_NAME])), self::NONCE_ACTION)) {
            self::redirect_status($redirect, 'error');
        }
        // Honeypot: silently accept automated submissions without sending mail.
        if (!empty($_POST['ga_contact_website'])) { self::redirect_status($redirect, 'sent'); }

        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown';
        $rate_key = 'ga_contact_rate_' . hash_hmac('sha256', $ip, wp_salt('auth'));
        $attempts = (int) get_transient($rate_key);
        if ($attempts >= 5) { self::redirect_status($redirect, 'limit'); }
        set_transient($rate_key, $attempts + 1, 15 * MINUTE_IN_SECONDS);

        $name = isset($_POST['ga_contact_name']) ? sanitize_text_field(wp_unslash($_POST['ga_contact_name'])) : '';
        $phone = isset($_POST['ga_contact_phone']) ? sanitize_text_field(wp_unslash($_POST['ga_contact_phone'])) : '';
        $email = isset($_POST['ga_contact_email']) ? sanitize_email(wp_unslash($_POST['ga_contact_email'])) : '';
        $topic = isset($_POST['ga_contact_topic']) ? sanitize_text_field(wp_unslash($_POST['ga_contact_topic'])) : 'Orientação inicial';
        $message = isset($_POST['ga_contact_message']) ? sanitize_textarea_field(wp_unslash($_POST['ga_contact_message'])) : '';
        $consent = !empty($_POST['ga_contact_consent']);
        if ($name === '' || $phone === '' || $message === '' || !$consent || (isset($_POST['ga_contact_email']) && $_POST['ga_contact_email'] !== '' && !is_email($email))) {
            self::redirect_status($redirect, 'invalid');
        }

        $to = 'contato@garibaldeadvogados.com.br';
        $subject = '[Site] Novo contato — ' . $topic;
        $body = "Novo contato recebido pelo formulário Fale Conosco.\n\nNome: {$name}\nTelefone/WhatsApp: {$phone}\nE-mail: " . ($email ?: 'Não informado') . "\nAssunto: {$topic}\n\nMensagem inicial:\n{$message}\n\nConsentimento registrado no envio do formulário.";
        $headers = array('Content-Type: text/plain; charset=UTF-8');
        if ($email && is_email($email)) { $headers[] = 'Reply-To: ' . $name . ' <' . $email . '>'; }
        $sent = wp_mail($to, $subject, $body, $headers);
        self::redirect_status($redirect, $sent ? 'sent' : 'error');
    }

    private static function redirect_status($url, $status) {
        wp_safe_redirect(add_query_arg('ga_contact_status', sanitize_key($status), $url));
        exit;
    }

    private static function css() {
        return <<<'CSS'
.ga-contact{--ga-coffee:#241915;--ga-graphite:#302724;--ga-ivory:#F2EEE7;--ga-gold:#C99A55;--ga-silver:#B8BBC0;max-width:100%;margin:8px 0 24px;padding:clamp(20px,3.5vw,34px);background:linear-gradient(145deg,#fffdf9 0%,var(--ga-ivory) 100%);border:1px solid rgba(36,25,21,.12);border-radius:16px;box-shadow:0 16px 38px rgba(36,25,21,.08);color:var(--ga-graphite);font-family:inherit;box-sizing:border-box}
.ga-contact *{box-sizing:border-box}.ga-contact-intro{max-width:680px;margin:0 0 24px}.ga-contact-eyebrow{display:inline-block;margin-bottom:10px;color:#8b6530;font-size:11px;font-weight:800;letter-spacing:.16em}.ga-contact-intro h2{margin:0 0 12px!important;font-size:clamp(24px,3vw,32px);line-height:1.18;color:var(--ga-coffee);font-family:inherit;font-weight:700}.ga-contact-intro p{margin:0;color:#625751;font-size:15px;line-height:1.7}.ga-contact-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}.ga-field{min-width:0}.ga-field-full{grid-column:1/-1}.ga-contact-form label{display:block;margin:0 0 7px;color:#433730;font-weight:650;font-size:13px}.ga-contact-form label span{color:#9a6c25}.ga-contact-form input[type=text],.ga-contact-form input[type=tel],.ga-contact-form input[type=email],.ga-contact-form select,.ga-contact-form textarea{display:block;width:100%;min-width:0;max-width:100%;border:1px solid #d4c9bc;border-radius:8px;background:#fffdfa;color:#302724;padding:12px 13px;font:inherit;font-size:15px;line-height:1.5;box-shadow:none;transition:border-color .15s ease,box-shadow .15s ease}.ga-contact-form textarea{resize:vertical;min-height:125px}.ga-contact-form input:focus,.ga-contact-form select:focus,.ga-contact-form textarea:focus{outline:0;border-color:#a57d42;box-shadow:0 0 0 3px rgba(201,154,85,.2)}.ga-field-hint{font-size:12px;line-height:1.5;color:#776c63;margin-top:6px}.ga-contact-consent{display:flex!important;align-items:flex-start;gap:10px;margin:20px 0 18px!important;font-weight:400!important;font-size:12px!important;line-height:1.55;color:#665951!important}.ga-contact-consent input{flex:0 0 auto;margin:3px 0 0;accent-color:#8b6530}.ga-contact-actions{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.ga-contact-submit,.ga-contact-whatsapp{display:inline-flex;justify-content:center;align-items:center;gap:10px;min-height:46px;padding:12px 18px;border-radius:8px;text-decoration:none!important;font-size:14px;font-weight:750;line-height:1.2;cursor:pointer;transition:transform .15s ease,background .15s ease;border:1px solid transparent}.ga-contact-submit{background:var(--ga-coffee);color:#fff!important}.ga-contact-submit:hover{background:#4a352a;transform:translateY(-1px)}.ga-contact-whatsapp{border-color:#c7b49a;background:transparent;color:var(--ga-coffee)!important}.ga-contact-whatsapp:hover{background:#fffaf1}.ga-contact-footnote{margin:16px 0 0;font-size:11px;line-height:1.65;color:#7b7067}.ga-contact-notice{padding:13px 15px;border-radius:8px;margin:0 0 18px;font-size:14px;line-height:1.55}.ga-contact-success{background:#eef6ef;border:1px solid #c6e0c9;color:#245b30}.ga-contact-error{background:#fff1ee;border:1px solid #e6c0b9;color:#7f2e23}.ga-contact-hp{position:absolute!important;left:-10000px!important;top:auto!important;width:1px!important;height:1px!important;overflow:hidden!important}
@media(max-width:560px){.ga-contact{padding:20px 16px;border-radius:12px}.ga-contact-grid{grid-template-columns:1fr;gap:15px}.ga-field-full{grid-column:auto}.ga-contact-actions{align-items:stretch;flex-direction:column}.ga-contact-submit,.ga-contact-whatsapp{width:100%}.ga-contact-intro h2{font-size:25px}}
@media(prefers-reduced-motion:reduce){.ga-contact-submit,.ga-contact-whatsapp,.ga-contact-form input,.ga-contact-form select,.ga-contact-form textarea{transition:none}}
CSS;
    }
}

GA_Fale_Conosco::init();
