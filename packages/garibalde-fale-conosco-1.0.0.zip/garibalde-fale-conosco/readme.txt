Garibalde Amaral — Fale Conosco 1.0.0

Objetivo
Recupera a página /fale-conosco/ quando o conteúdo principal estiver efetivamente vazio, sem editar o tema WMD nem alterar o banco diretamente. Também oferece o shortcode [ga_fale_conosco] para uso manual.

Recursos
- Formulário responsivo com identidade marrom, grafite, marfim e ouro fosco.
- Nome, telefone/WhatsApp, e-mail opcional, assunto e mensagem inicial.
- Consentimento, nonce, validação no servidor, honeypot e limite de tentativas por IP com hash.
- Mensagem encaminhada para contato@garibaldeadvogados.com.br via wp_mail (depende de SMTP funcional).
- Alternativa para abrir WhatsApp Business do escritório.
- Não recebe anexos nem armazena o teor da mensagem no banco de dados.

Instalação
WordPress > Plugins > Adicionar novo > Enviar plugin > selecionar ZIP > Instalar > Ativar. Depois testar a página no computador e celular e enviar um contato de teste. Confirmar recebimento de e-mail. Se SMTP não estiver configurado, o formulário mostrará falha de envio.

Segurança e limites
Não substitui central digital com upload privado. O formulário pede apenas dados de contato e resumo inicial; não orientar o visitante a enviar documentos ou detalhes sigilosos por esse canal.
