<?php
/**
 * Plugin Name: Consulta Processual Segura - Garibalde Advogados
 * Description: Integra o cabeçalho clássico do site, protege a consulta com senha configurável no painel e apresenta links para portais oficiais.
 * Version: 1.6.2
 * Author: Garibalde Advogados
 */
if (!defined('ABSPATH')) { exit; }

function ga_cps_v15_portals_markup() {
    $portals = array(
        array('num' => '01', 'tag' => 'JUSTIÇA ESTADUAL', 'title' => 'PROJUDI — TJGO', 'desc' => 'Consulta pública de processos do Tribunal de Justiça do Estado de Goiás.', 'url' => 'https://projudi.tjgo.jus.br/BuscaProcesso', 'icon' => 'court'),
        array('num' => '02', 'tag' => 'JUSTIÇA FEDERAL', 'title' => 'TRF1 — Goiás', 'desc' => 'Consulta processual da Justiça Federal da 1ª Região, Seção Judiciária de Goiás.', 'url' => 'https://processual.trf1.jus.br/consultaProcessual/index.php?secao=GO', 'icon' => 'columns'),
        array('num' => '03', 'tag' => 'JUSTIÇA DO TRABALHO', 'title' => 'TRT18 — Goiás', 'desc' => 'Consulta processual do Tribunal Regional do Trabalho da 18ª Região.', 'url' => 'https://sistemas.trt18.jus.br/consultasPortal/pages/Processuais/ListaProcessos.seam', 'icon' => 'scales'),
        array('num' => '04', 'tag' => 'JUSTIÇA DO DISTRITO FEDERAL', 'title' => 'TJDFT — PJe', 'desc' => 'Acesso ao Processo Judicial Eletrônico e às consultas públicas do Tribunal de Justiça do Distrito Federal e dos Territórios.', 'url' => 'https://www.tjdft.jus.br/pje', 'icon' => 'court'),
    );
    $icons = array(
      'court' => '<svg viewBox="0 0 48 48" aria-hidden="true"><path d="M5 17 24 7l19 10H5Zm4 4h30M8 39h32M5 43h38M12 22v15m8-15v15m8-15v15m8-15v15" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
      'columns' => '<svg viewBox="0 0 48 48" aria-hidden="true"><path d="M6 17 24 7l18 10H6Zm3 4h30M10 39h28M7 43h34M14 22v15m10-15v15m10-15v15" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
      'scales' => '<svg viewBox="0 0 48 48" aria-hidden="true"><path d="M24 7v33m-9 0h18M12 15h24M24 9l-12 6m12-6 12 6M12 15 5 28h14L12 15Zm24 0-7 13h14l-7-13Z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/><path d="M5 28c1 5 13 5 14 0m8 0c1 5 13 5 14 0" fill="none" stroke="currentColor" stroke-width="1.7"/></svg>'
    );
    $html = '<div class="ga-cps-page ga-cps-v15"><section class="ga-cps-hero"><div class="ga-cps-hero-copy"><p class="ga-cps-eyebrow">GARIBALDE AMARAL <span>·</span> ADVOGADOS ASSOCIADOS</p><h1>Consulta processual</h1><p class="ga-cps-lead">Acesso direto aos sistemas oficiais do Poder Judiciário.</p><div class="ga-cps-ornament" aria-hidden="true"><span></span><i></i><span></span></div></div><aside class="ga-cps-security"><span class="ga-cps-security-mark" aria-hidden="true">✓</span><div><h2>Privacidade em primeiro lugar</h2><p>A senha protege esta página de acesso do escritório. Não solicitamos nem armazenamos senhas dos sistemas dos tribunais. Ao selecionar um tribunal, você acessará o ambiente oficial correspondente.</p></div></aside></section><div class="ga-cps-choose"><div><p class="ga-cps-overline">CONSULTA POR TRIBUNAL</p><h2>Selecione o sistema correspondente ao seu processo</h2></div><p class="ga-cps-choose-note">Escolha uma das opções abaixo para continuar.</p></div><div class="ga-cps-portals">';
    foreach ($portals as $p) {
        $html .= '<a class="ga-cps-portal" href="' . esc_url($p['url']) . '" target="_blank" rel="noopener noreferrer" aria-label="Abrir portal oficial: ' . esc_attr($p['title']) . '"><div class="ga-cps-card-top"><span class="ga-cps-portal-num">' . esc_html($p['num']) . '</span><span class="ga-cps-portal-icon">' . $icons[$p['icon']] . '</span></div><p class="ga-cps-portal-tag">' . esc_html($p['tag']) . '</p><h3>' . esc_html($p['title']) . '</h3><p class="ga-cps-portal-desc">' . esc_html($p['desc']) . '</p><span class="ga-cps-portal-cta">Acessar portal oficial <span aria-hidden="true">↗</span></span></a>';
    }
    $html .= '</div><div class="ga-cps-note"><span class="ga-cps-note-symbol" aria-hidden="true">i</span><p><strong>Informação importante.</strong> Processos sob segredo de justiça ou com restrição de acesso podem não aparecer nas consultas públicas. Se tiver dúvida sobre o tribunal competente, entre em contato com o escritório por seus canais oficiais.</p></div><p class="ga-cps-bottom-line">Informação clara. Acesso seguro. Respeito à sua privacidade.</p></div>';
    return $html;
}

function ga_cps_v15_activate() {
    $page = get_page_by_path('consulta-processual', OBJECT, 'page');
    if (!$page) {
        wp_insert_post(array('post_title' => 'Consulta Processual', 'post_name' => 'consulta-processual', 'post_status' => 'publish', 'post_type' => 'page', 'post_content' => ''));
    } elseif ($page->post_status !== 'publish') {
        wp_update_post(array('ID' => $page->ID, 'post_status' => 'publish'));
    }
}
register_activation_hook(__FILE__, 'ga_cps_v15_activate');

function ga_cps_v16_get_consult_page() {
    $page = get_page_by_path('consulta-processual', OBJECT, 'page');
    if (!$page) {
        $candidate = get_post(258);
        if ($candidate && $candidate->post_type === 'page' && $candidate->post_status === 'publish' && strcasecmp(trim($candidate->post_title), 'Consulta Processual') === 0) {
            $page = $candidate;
        }
    }
    return $page;
}

/** Localized and styled WordPress password form for the consultation page only. */
function ga_cps_v162_consult_password_form($output, $post, $invalid_password = '') {
    $page = ga_cps_v16_get_consult_page();
    if (!$page || !$post || (int) $page->ID !== (int) $post->ID) {
        return $output;
    }
    $field_id = 'ga-cps-access-password-' . (int) $page->ID;
    $message = '';
    if (!empty($invalid_password)) {
        $message = '<p class="ga-cps-access-error" role="alert">A senha informada não confere. Tente novamente.</p>';
    }
    $html  = '<section class="ga-cps-access-gate" aria-labelledby="ga-cps-access-title">';
    $html .= '<p class="ga-cps-access-eyebrow">GARIBALDE AMARAL · ÁREA DO CLIENTE</p>';
    $html .= '<h1 id="ga-cps-access-title">Consulta processual</h1>';
    $html .= '<p class="ga-cps-access-description">Esta área é destinada a clientes autorizados. Digite a senha de acesso fornecida pelo escritório para consultar os portais judiciais.</p>';
    $html .= $message;
    $html .= '<form action="' . esc_url(site_url('wp-login.php?action=postpass', 'login_post')) . '" class="ga-cps-access-form post-password-form" method="post">';
    $html .= '<label class="ga-cps-access-field" for="' . esc_attr($field_id) . '">Senha de acesso';
    $html .= '<input id="' . esc_attr($field_id) . '" name="post_password" type="password" autocomplete="current-password" required maxlength="255" spellcheck="false"></label>';
    $html .= '<button class="ga-cps-access-submit" type="submit" name="Submit">Entrar na consulta <span aria-hidden="true"> ↗</span></button>';
    $html .= '</form><p class="ga-cps-access-foot">A senha protege esta página; os sistemas judiciais abrem em seus próprios sites oficiais.</p></section>';
    return $html;
}
add_filter('the_password_form', 'ga_cps_v162_consult_password_form', 10, 3);

/** Admin-only settings screen: the shared password is stored in the page's native WordPress post_password field. */
function ga_cps_v162_add_settings_page() {
    add_options_page('Proteção da Consulta Processual', 'Proteção da Consulta Processual', 'manage_options', 'ga-cps-protecao', 'ga_cps_v162_settings_page');
}
add_action('admin_menu', 'ga_cps_v162_add_settings_page');

function ga_cps_v162_save_password() {
    if (!current_user_can('manage_options')) {
        wp_die('Você não tem permissão para alterar a senha da consulta.');
    }
    check_admin_referer('ga_cps_v162_save_password');
    $page = ga_cps_v16_get_consult_page();
    if (!$page) {
        wp_die('A página Consulta Processual não foi encontrada.');
    }
    $password = isset($_POST['ga_cps_access_password']) ? sanitize_text_field(wp_unslash($_POST['ga_cps_access_password'])) : '';
    if (strlen($password) < 10) {
        wp_safe_redirect(add_query_arg('ga_cps_status', 'short', admin_url('options-general.php?page=ga-cps-protecao')));
        exit;
    }
    $updated = wp_update_post(array('ID' => (int) $page->ID, 'post_password' => $password), true);
    if (is_wp_error($updated) || !$updated) {
        wp_safe_redirect(add_query_arg('ga_cps_status', 'error', admin_url('options-general.php?page=ga-cps-protecao')));
        exit;
    }
    clean_post_cache($page->ID);
    wp_safe_redirect(add_query_arg('ga_cps_status', 'saved', admin_url('options-general.php?page=ga-cps-protecao')));
    exit;
}
add_action('admin_post_ga_cps_v162_save_password', 'ga_cps_v162_save_password');

function ga_cps_v162_settings_page() {
    if (!current_user_can('manage_options')) { return; }
    $page = ga_cps_v16_get_consult_page();
    $status = isset($_GET['ga_cps_status']) ? sanitize_key(wp_unslash($_GET['ga_cps_status'])) : '';
    echo '<div class="wrap"><h1>Proteção da Consulta Processual</h1>';
    if ($status === 'saved') {
        echo '<div class="notice notice-success is-dismissible"><p>Senha salva. A página da consulta agora exige a senha para visitantes não autenticados pelo WordPress.</p></div>';
    } elseif ($status === 'short') {
        echo '<div class="notice notice-error"><p>Use uma senha com pelo menos 10 caracteres.</p></div>';
    } elseif ($status === 'error') {
        echo '<div class="notice notice-error"><p>Não foi possível salvar a senha. Verifique a página e tente novamente.</p></div>';
    }
    if (!$page) {
        echo '<div class="notice notice-error"><p>A página Consulta Processual não foi encontrada. Nenhuma configuração foi alterada.</p></div></div>';
        return;
    }
    if (!empty($page->post_password)) {
        echo '<div class="notice notice-success"><p><strong>Estado: protegida por senha.</strong> A senha atual não é exibida.</p></div>';
    } else {
        echo '<div class="notice notice-warning"><p><strong>Estado: sem senha.</strong> A página ainda está acessível publicamente. Defina uma senha abaixo para restringir o acesso.</p></div>';
    }
    echo '<p>A senha é compartilhada: somente pessoas que a receberem poderão abrir a página de consulta. Use uma senha exclusiva, com no mínimo 10 caracteres, e não reutilize a senha de e-mail ou do WordPress.</p>';
    echo '<p><a class="button" href="' . esc_url(get_edit_post_link($page->ID, 'url')) . '">Abrir edição da página</a> &nbsp; <a class="button" href="' . esc_url(get_permalink($page->ID)) . '" target="_blank" rel="noopener noreferrer">Visualizar consulta</a></p>';
    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="max-width:620px;background:#fff;border:1px solid #dcdcde;padding:20px;margin-top:20px">';
    echo '<input type="hidden" name="action" value="ga_cps_v162_save_password">';
    wp_nonce_field('ga_cps_v162_save_password');
    echo '<p><label for="ga-cps-access-password"><strong>Definir ou trocar senha de acesso</strong></label></p>';
    echo '<p><input id="ga-cps-access-password" class="regular-text" style="width:100%;max-width:480px" name="ga_cps_access_password" type="password" autocomplete="new-password" minlength="10" maxlength="255" required></p>';
    echo '<p class="description">Por segurança, a senha atual não pode ser recuperada nesta tela; para trocar, defina uma nova senha. Ela será aplicada à página existente sem alterar o conteúdo visual nem os links.</p>';
    submit_button('Salvar senha e proteger consulta');
    echo '</form><p><strong>Importante:</strong> após salvar, limpe o cache do site, caso exista. Teste em uma janela privada: a página deve solicitar a senha antes de mostrar os quatro portais. Esta proteção é uma senha compartilhada de página, não substitui contas individuais para dados sigilosos.</p></div>';
}

function ga_cps_v15_render_page($content) {
    $page = ga_cps_v16_get_consult_page();
    if (!is_admin() && $page && (is_page($page->ID) || is_page('consulta-processual')) && in_the_loop() && is_main_query()) {
        // Critical: the custom renderer must never bypass WordPress page-password protection.
        if (post_password_required($page)) {
            return get_the_password_form($page);
        }
        return ga_cps_v15_portals_markup();
    }
    return $content;
}
add_filter('the_content', 'ga_cps_v15_render_page', 99);

function ga_cps_v15_styles() {
    if (is_admin()) { return; }
    echo '<style id="ga-cps-v15-styles">
/* Garibalde — visual editorial discreto: marrom profundo, marfim e latão suave. */
.ga-cps-v15,.ga-cps-v15 *{box-sizing:border-box!important}.ga-cps-v15{--ga-ink:#29221d;--ga-muted:#6e655c;--ga-gold:#a97939;--ga-plum:#6a5a81;--ga-silver:#bab7cf;--ga-line:#e6ddd1;--ga-paper:#fbf8f3;display:block!important;width:calc(100% - 44px)!important;max-width:1060px!important;margin:34px auto 54px!important;padding:0!important;color:var(--ga-ink)!important;font-family:Arial,Helvetica,sans-serif!important;font-size:15px!important;line-height:1.7!important;text-align:left!important}.ga-cps-v15 a{transition:transform .2s ease,box-shadow .2s ease,border-color .2s ease,background-color .2s ease!important}.ga-cps-v15 .ga-cps-hero{position:relative!important;overflow:hidden!important;padding:37px 40px 30px!important;background:linear-gradient(135deg,#fbf8f3 0%,#f5eee4 100%)!important;border:1px solid #e5d8c7!important;border-top:3px solid var(--ga-gold)!important;border-radius:3px 3px 10px 10px!important;box-shadow:0 10px 30px rgba(49,36,24,.045)!important}.ga-cps-v15 .ga-cps-hero:after{content:""!important;position:absolute!important;right:-56px!important;top:-72px!important;width:230px!important;height:230px!important;border:1px solid rgba(169,121,57,.13)!important;border-radius:50%!important;box-shadow:0 0 0 20px rgba(169,121,57,.025),0 0 0 40px rgba(169,121,57,.02)!important;pointer-events:none!important}.ga-cps-v15 .ga-cps-hero-copy{position:relative!important;z-index:1!important}.ga-cps-v15 .ga-cps-eyebrow,.ga-cps-v15 .ga-cps-overline{margin:0 0 10px!important;color:#6a5a81!important;font-size:10px!important;line-height:1.5!important;font-weight:700!important;letter-spacing:1.9px!important}.ga-cps-v15 .ga-cps-eyebrow span{padding:0 5px!important;color:#c3a071!important}.ga-cps-v15 h1{display:block!important;margin:0!important;padding:0!important;color:#2c241e!important;font-family:Georgia,"Times New Roman",serif!important;font-size:clamp(30px,3.7vw,43px)!important;font-weight:normal!important;line-height:1.18!important;letter-spacing:-.6px!important}.ga-cps-v15 .ga-cps-lead{margin:12px 0 0!important;color:#65594d!important;font-size:16px!important;line-height:1.6!important}.ga-cps-v15 .ga-cps-ornament{display:flex!important;align-items:center!important;gap:7px!important;width:74px!important;margin-top:22px!important}.ga-cps-v15 .ga-cps-ornament span{height:1px!important;flex:1!important;background:#c6a575!important}.ga-cps-v15 .ga-cps-ornament i{display:block!important;width:5px!important;height:5px!important;border:1px solid #a97939!important;transform:rotate(45deg)!important}.ga-cps-v15 .ga-cps-security{position:relative!important;z-index:1!important;display:flex!important;align-items:flex-start!important;gap:13px!important;margin:26px 0 0!important;padding:15px 17px!important;background:rgba(255,255,255,.72)!important;border:1px solid #e7ddcf!important;border-radius:5px!important}.ga-cps-v15 .ga-cps-security-mark{display:flex!important;align-items:center!important;justify-content:center!important;flex:0 0 24px!important;width:24px!important;height:24px!important;margin-top:1px!important;border-radius:50%!important;background:#e9dfcf!important;color:#765128!important;font-size:13px!important;font-weight:700!important}.ga-cps-v15 .ga-cps-security h2{margin:0 0 3px!important;color:#3b3026!important;font-family:Arial,Helvetica,sans-serif!important;font-size:12px!important;font-weight:700!important;letter-spacing:.2px!important;line-height:1.5!important}.ga-cps-v15 .ga-cps-security p{margin:0!important;color:#665d54!important;font-size:12px!important;line-height:1.65!important}.ga-cps-v15 .ga-cps-choose{display:flex!important;align-items:flex-end!important;justify-content:space-between!important;gap:25px!important;margin:37px 0 17px!important}.ga-cps-v15 .ga-cps-overline{margin-bottom:5px!important;font-size:9px!important;letter-spacing:1.7px!important}.ga-cps-v15 .ga-cps-choose h2{max-width:620px!important;margin:0!important;padding:0!important;color:#30271f!important;font-family:Georgia,"Times New Roman",serif!important;font-size:25px!important;font-weight:normal!important;line-height:1.35!important}.ga-cps-v15 .ga-cps-choose-note{flex:0 0 auto!important;margin:0 0 3px!important;color:#756b61!important;font-size:12px!important}.ga-cps-v15 .ga-cps-portals{display:grid!important;grid-template-columns:repeat(4,minmax(0,1fr))!important;gap:14px!important}.ga-cps-v15 a.ga-cps-portal{position:relative!important;display:flex!important;flex-direction:column!important;align-items:stretch!important;min-width:0!important;min-height:270px!important;padding:23px 22px 21px!important;overflow:hidden!important;background:#fff!important;border:1px solid #e8e1d8!important;border-radius:7px!important;box-shadow:0 4px 14px rgba(47,34,23,.045)!important;color:var(--ga-ink)!important;text-decoration:none!important}.ga-cps-v15 a.ga-cps-portal:before{content:""!important;position:absolute!important;top:0!important;left:0!important;width:100%!important;height:2px!important;background:#d9c3a3!important;transform:scaleX(.28)!important;transform-origin:left!important;transition:transform .2s ease!important}.ga-cps-v15 a.ga-cps-portal:hover,.ga-cps-v15 a.ga-cps-portal:focus-visible{transform:translateY(-3px)!important;border-color:#d3b58d!important;box-shadow:0 12px 28px rgba(47,34,23,.09)!important;outline:none!important}.ga-cps-v15 a.ga-cps-portal:hover:before,.ga-cps-v15 a.ga-cps-portal:focus-visible:before{transform:scaleX(1)!important;background:var(--ga-gold)!important}.ga-cps-v15 .ga-cps-card-top{display:flex!important;align-items:flex-start!important;justify-content:space-between!important;margin-bottom:17px!important}.ga-cps-v15 .ga-cps-portal-num{color:#b6a18a!important;font-family:Georgia,"Times New Roman",serif!important;font-size:14px!important;letter-spacing:1px!important}.ga-cps-v15 .ga-cps-portal-icon{display:flex!important;align-items:center!important;justify-content:center!important;width:43px!important;height:43px!important;border:1px solid #e9dfd2!important;border-radius:50%!important;background:#faf7f2!important;color:#9c713d!important}.ga-cps-v15 .ga-cps-portal-icon svg{display:block!important;width:25px!important;height:25px!important}.ga-cps-v15 .ga-cps-portal-tag{margin:0 0 5px!important;color:#6a5a81!important;font-size:9px!important;font-weight:700!important;letter-spacing:1.25px!important;line-height:1.5!important}.ga-cps-v15 .ga-cps-portal h3{margin:0 0 9px!important;padding:0!important;color:#30251d!important;font-family:Georgia,"Times New Roman",serif!important;font-size:23px!important;font-weight:normal!important;line-height:1.25!important}.ga-cps-v15 .ga-cps-portal-desc{margin:0 0 20px!important;color:#70675e!important;font-size:12px!important;line-height:1.65!important}.ga-cps-v15 .ga-cps-portal-cta{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:10px!important;margin-top:auto!important;padding-top:13px!important;border-top:1px solid #eee8e0!important;color:#5c4024!important;font-size:10px!important;font-weight:700!important;letter-spacing:.65px!important;text-transform:uppercase!important}.ga-cps-v15 .ga-cps-portal-cta span{display:inline-flex!important;align-items:center!important;justify-content:center!important;width:25px!important;height:25px!important;border:1px solid #e2d4c1!important;border-radius:50%!important;font-size:13px!important;line-height:1!important}.ga-cps-v15 a.ga-cps-portal:hover .ga-cps-portal-cta span{background:#33251d!important;border-color:#33251d!important;color:#fff!important}.ga-cps-v15 .ga-cps-note{display:flex!important;align-items:flex-start!important;gap:12px!important;margin:21px 0 0!important;padding:16px 18px!important;background:#f1ece5!important;border:1px solid #e6ddd1!important;border-radius:5px!important}.ga-cps-v15 .ga-cps-note-symbol{display:flex!important;align-items:center!important;justify-content:center!important;flex:0 0 21px!important;width:21px!important;height:21px!important;margin-top:1px!important;border:1px solid #cdb99e!important;border-radius:50%!important;color:#80603a!important;font-family:Georgia,serif!important;font-size:13px!important;font-style:italic!important}.ga-cps-v15 .ga-cps-note p{margin:0!important;color:#655b51!important;font-size:11px!important;line-height:1.7!important}.ga-cps-v15 .ga-cps-note strong{color:#3e3329!important}.ga-cps-v15 .ga-cps-bottom-line{margin:23px 0 0!important;color:#9a8d7e!important;font-family:Georgia,"Times New Roman",serif!important;font-size:12px!important;font-style:italic!important;text-align:center!important;letter-spacing:.2px!important}
/* Pequeno cartão de acesso no cabeçalho legado. */
.ga-cps-header-card{box-sizing:border-box!important;display:flex!important;align-items:center!important;justify-content:space-between!important;gap:9px!important;width:276px!important;max-width:100%!important;min-height:0!important;height:auto!important;margin:0 auto!important;padding:7px 9px!important;background:rgba(251,248,243,.97)!important;border:1px solid #dfd1bd!important;border-top:2px solid #a97939!important;border-radius:5px!important;box-shadow:0 3px 12px rgba(0,0,0,.12)!important;color:#2e251e!important;font:12px/1.3 Arial,Helvetica,sans-serif!important;text-align:left!important;position:relative!important;z-index:3!important}.ga-cps-header-card .ga-cps-header-copy{display:flex!important;flex-direction:column!important;gap:2px!important;min-width:0!important}.ga-cps-header-card .ga-cps-header-label{display:block!important;margin:0!important;color:#947044!important;font-size:8px!important;font-weight:700!important;letter-spacing:1.2px!important;line-height:1.3!important}.ga-cps-header-card strong{display:block!important;margin:0!important;color:#30251d!important;font-size:11px!important;line-height:1.35!important}.ga-cps-header-card a{display:inline-flex!important;align-items:center!important;justify-content:center!important;flex:0 0 auto!important;gap:5px!important;margin:0!important;padding:7px 9px!important;background:#33251d!important;color:#fff!important;border:1px solid #33251d!important;border-radius:3px!important;text-decoration:none!important;font-size:9px!important;font-weight:700!important;line-height:1.2!important;white-space:nowrap!important;letter-spacing:.3px!important;text-transform:uppercase!important}.ga-cps-header-card a:hover,.ga-cps-header-card a:focus{background:#8b622f!important;border-color:#8b622f!important;color:#fff!important}
@media(max-width:800px){.ga-cps-v15{width:calc(100% - 28px)!important;margin:24px auto 36px!important}.ga-cps-v15 .ga-cps-hero{padding:28px 23px 23px!important}.ga-cps-v15 .ga-cps-choose{display:block!important;margin-top:30px!important}.ga-cps-v15 .ga-cps-choose-note{margin-top:8px!important}.ga-cps-v15 .ga-cps-portals{grid-template-columns:1fr!important;gap:12px!important}.ga-cps-v15 a.ga-cps-portal{min-height:0!important;padding:19px 19px 17px!important}.ga-cps-v15 .ga-cps-card-top{margin-bottom:12px!important}.ga-cps-v15 .ga-cps-portal-desc{margin-bottom:14px!important}.ga-cps-v15 .ga-cps-choose h2{font-size:23px!important}}
@media(max-width:480px){.ga-cps-v15{width:calc(100% - 22px)!important;margin-top:18px!important}.ga-cps-v15 .ga-cps-hero{padding:24px 17px 19px!important}.ga-cps-v15 h1{font-size:31px!important}.ga-cps-v15 .ga-cps-lead{font-size:14px!important}.ga-cps-v15 .ga-cps-security{padding:12px!important}.ga-cps-v15 .ga-cps-choose h2{font-size:21px!important}.ga-cps-header-card{width:100%!important;gap:5px!important;padding:6px 7px!important}.ga-cps-header-card a{padding:6px 7px!important;font-size:8px!important}}

/* Integração com o tema clássico Garibalde: remove o título/faixa duplicada nesta página, preservando o cabeçalho global. */
body.page-id-258 .titulo-pagina,body.page-id-258 .breadcrumb,body.page-consulta-processual .titulo-pagina,body.page-consulta-processual .breadcrumb{display:none!important;height:0!important;margin:0!important;padding:0!important;overflow:hidden!important}
body.page-id-258 .conteudo-pagina,body.page-consulta-processual .conteudo-pagina{background:transparent!important;padding:0!important;margin:0 0 20px!important;border-radius:0!important;box-shadow:none!important;text-shadow:none!important;overflow:visible!important}
/* Ocupa o espaço original do módulo de consulta, sem deixar títulos ou campos antigos ao redor. */
#topo .processos.ga-cps-header-card{box-sizing:border-box!important;display:flex!important;flex-direction:row!important;align-items:center!important;justify-content:space-between!important;gap:10px!important;width:310px!important;max-width:calc(100% - 12px)!important;min-height:65px!important;height:auto!important;margin:0!important;padding:10px 12px!important;position:absolute!important;top:28px!important;left:365px!important;right:auto!important;float:none!important;overflow:visible!important;background:linear-gradient(135deg,rgba(250,247,242,.98),rgba(239,232,223,.98))!important;border:1px solid rgba(186,183,207,.75)!important;border-top:2px solid #a97939!important;border-radius:5px!important;box-shadow:0 5px 18px rgba(0,0,0,.15)!important;color:#30251d!important;text-align:left!important;font:12px/1.35 Arial,Helvetica,sans-serif!important;z-index:20!important}
#topo .processos.ga-cps-header-card .ga-cps-header-copy{display:flex!important;flex:1 1 auto!important;flex-direction:column!important;gap:3px!important;min-width:0!important}
#topo .processos.ga-cps-header-card .ga-cps-header-label{display:block!important;margin:0!important;color:#6a5a81!important;font-size:8px!important;font-weight:700!important;letter-spacing:1.25px!important;line-height:1.3!important}
#topo .processos.ga-cps-header-card strong{display:block!important;margin:0!important;color:#30251d!important;font-family:Georgia,"Times New Roman",serif!important;font-size:14px!important;font-weight:normal!important;line-height:1.3!important}
#topo .processos.ga-cps-header-card a{display:inline-flex!important;align-items:center!important;justify-content:center!important;flex:0 0 auto!important;gap:6px!important;margin:0!important;padding:9px 11px!important;background:#33251d!important;color:#fff!important;border:1px solid #33251d!important;border-radius:3px!important;text-decoration:none!important;font-size:9px!important;font-weight:700!important;line-height:1.2!important;white-space:nowrap!important;letter-spacing:.45px!important;text-transform:uppercase!important}
#topo .processos.ga-cps-header-card a:hover,#topo .processos.ga-cps-header-card a:focus{background:#6a5a81!important;border-color:#6a5a81!important;color:#fff!important}
@media(max-width:1000px){#topo .processos.ga-cps-header-card{left:36.8%!important;width:32%!important;gap:6px!important;padding:8px!important}#topo .processos.ga-cps-header-card strong{font-size:12px!important}#topo .processos.ga-cps-header-card a{padding:7px 8px!important;font-size:8px!important}}
@media(max-width:700px){#topo .processos.ga-cps-header-card{left:32%!important;top:22px!important;width:36%!important;min-height:58px!important;padding:7px!important}#topo .processos.ga-cps-header-card .ga-cps-header-label{font-size:7px!important;letter-spacing:.6px!important}#topo .processos.ga-cps-header-card strong{font-size:10px!important}#topo .processos.ga-cps-header-card a{padding:6px!important;font-size:7px!important}}

/* Password gate for the client-only consultation page. */
body.page-consulta-processual .ga-cps-access-gate,body.page-id-258 .ga-cps-access-gate{box-sizing:border-box;max-width:620px;margin:52px auto;padding:38px 36px;background:linear-gradient(135deg,#fbf8f3 0%,#f5eee4 100%);border:1px solid #e5d8c7;border-top:3px solid #a97939;border-radius:5px;box-shadow:0 10px 30px rgba(49,36,24,.06);color:#29221d;font:15px/1.7 Arial,Helvetica,sans-serif;text-align:left}
.ga-cps-access-gate *{box-sizing:border-box}
.ga-cps-access-gate .ga-cps-access-eyebrow{margin:0 0 9px;color:#6a5a81;font-size:10px;font-weight:700;letter-spacing:1.7px;text-transform:uppercase}
.ga-cps-access-gate h1{margin:0 0 10px;color:#2c241e;font:normal clamp(27px,3.5vw,38px)/1.2 Georgia,"Times New Roman",serif}
.ga-cps-access-gate .ga-cps-access-description{margin:0 0 22px;color:#65594d;font-size:14px}
.ga-cps-access-gate .ga-cps-access-field{display:block;margin:0 0 15px;color:#44382d;font-size:12px;font-weight:700}
.ga-cps-access-gate input[type=password]{display:block;width:100%;max-width:100%;height:46px;margin-top:7px;padding:10px 12px;border:1px solid #cfc0ad;border-radius:4px;background:#fff;color:#29221d;font:16px Arial,Helvetica,sans-serif;box-shadow:none}
.ga-cps-access-gate input[type=password]:focus{outline:2px solid rgba(106,90,129,.32);outline-offset:1px;border-color:#6a5a81}
.ga-cps-access-gate .ga-cps-access-submit{display:inline-flex;align-items:center;justify-content:center;min-height:43px;padding:11px 20px;border:1px solid #33251d;border-radius:4px;background:#33251d;color:#fff;font:700 11px Arial,Helvetica,sans-serif;letter-spacing:.7px;text-transform:uppercase;cursor:pointer}
.ga-cps-access-gate .ga-cps-access-submit:hover,.ga-cps-access-gate .ga-cps-access-submit:focus{background:#6a5a81;border-color:#6a5a81;color:#fff}
.ga-cps-access-gate .ga-cps-access-error{margin:0 0 15px;padding:10px 12px;border-left:3px solid #9c3b35;background:#fff0ed;color:#782f2a;font-size:12px}
.ga-cps-access-gate .ga-cps-access-foot{margin:17px 0 0;color:#8b7d6d;font:italic 11px Georgia,"Times New Roman",serif}
@media(max-width:800px){body.page-consulta-processual .ga-cps-access-gate,body.page-id-258 .ga-cps-access-gate{margin:28px 14px;padding:27px 22px}.ga-cps-portals{grid-template-columns:repeat(2,minmax(0,1fr))!important}}
@media(max-width:520px){.ga-cps-portals{grid-template-columns:1fr!important}body.page-consulta-processual .ga-cps-access-gate,body.page-id-258 .ga-cps-access-gate{margin:22px 10px;padding:22px 17px}}
</style>';
}
add_action('wp_head', 'ga_cps_v15_styles', 99);

function ga_cps_v15_header_script() {
    if (is_admin()) { return; }
    $consult_page = ga_cps_v16_get_consult_page();
    $dest = ($consult_page && $consult_page->post_status === 'publish') ? esc_url(get_permalink($consult_page->ID)) : esc_url(home_url('/consulta-processual/'));
    $card = '<div class="ga-cps-header-copy"><span class="ga-cps-header-label">ÁREA DO CLIENTE</span><strong>Consulta processual</strong></div><a href="' . $dest . '" aria-label="Acessar a consulta processual"><span>Acessar</span><span aria-hidden="true">↗</span></a>';
    echo '<script id="ga-cps-v15-script">(function(){"use strict";var cardHtml=' . wp_json_encode($card) . ';function norm(s){return (s||"").replace(/\\s+/g," ").trim().toLocaleLowerCase("pt-BR");}function decorateProcessBox(){var boxes=[].slice.call(document.querySelectorAll("#topo .processos"));var box=boxes.find(function(el){return el && !el.closest(".ga-cps-v15") && (el.querySelector("form#frEntrar, form[action*=\\"api.adv.br\\"], input[type=password]") || /acompanhamento de processos|preencha abaixo com seus dados|consulta processual|consultar/.test(norm(el.innerText||el.textContent)));});if(!box)return;if(box.getAttribute("data-ga-cps-v15")==="1")return;box.classList.add("ga-cps-header-card");box.innerHTML=cardHtml;box.setAttribute("data-ga-cps-v15","1");}function replaceLooseLegacyForm(){document.querySelectorAll("#topo form").forEach(function(f){var action=(f.getAttribute("action")||f.action||"").toLowerCase();if(action.indexOf("api.adv.br/integra/login1.asp")!==-1){var box=f.closest(".processos")||f.parentElement;if(box&&!box.closest(".ga-cps-v15")){box.classList.add("ga-cps-header-card");box.innerHTML=cardHtml;box.setAttribute("data-ga-cps-v15","1");}}});}function removeOldHeadingText(){var phrases={"preencha abaixo com seus dados":1,"acompanhamento de processos":1,"acompanhamento de processos:":1};var all=[].slice.call(document.querySelectorAll("#topo .processos, #topo h1, #topo h2, #topo h3, #topo h4, #topo h5, #topo h6, #topo p, #topo span, #topo label, #topo strong, #topo b, #topo font"));all.forEach(function(el){if(!el||el.closest(".ga-cps-header-card")||el.closest(".ga-cps-v15"))return;var t=norm(el.innerText||el.textContent);if(!phrases[t])return;if(el.querySelector("a,button,input,form,select,textarea"))return;var parent=el.parentElement;while(parent&&parent.id!=="topo"&&parent.tagName&&/^(DIV|P|SPAN|STRONG|B|FONT|H[1-6])$/.test(parent.tagName)&&norm(parent.innerText||parent.textContent)===t){el=parent;parent=el.parentElement;}if(el.parentNode)el.parentNode.removeChild(el);});}function fix(){decorateProcessBox();replaceLooseLegacyForm();removeOldHeadingText();}function start(){fix();if(document.body&&window.MutationObserver){var queued=false;var obs=new MutationObserver(function(){if(queued)return;queued=true;window.setTimeout(function(){queued=false;fix();},120);});obs.observe(document.body,{childList:true,subtree:true});}}if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",start);else start();window.addEventListener("load",fix);})();</script>';
}
add_action('wp_footer', 'ga_cps_v15_header_script', 99);

/** Restore the legacy "all news" link to the Articles page. The original site content used /artigos/. */
function ga_cps_v16_restore_news_archive_link() {
    if (is_admin()) { return; }
    $articles_page = get_page_by_path('artigos', OBJECT, 'page');
    $articles_url = ($articles_page && $articles_page->post_status === 'publish') ? get_permalink($articles_page->ID) : home_url('/artigos/');
    echo '<script id="ga-cps-v16-news-link-repair">(function(){"use strict";var target=' . wp_json_encode(esc_url($articles_url)) . ';function fix(){document.querySelectorAll("#meio #noticias-lateral a.vermais").forEach(function(a){a.setAttribute("href",target);});}if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",fix);else fix();})();</script>';
}
add_action('wp_footer', 'ga_cps_v16_restore_news_archive_link', 4);


/** Version 1.6 — restore the original three-slide homepage carousel without the legacy jQuery dependency. */
function ga_cps_v16_carousel_styles() {
    if (is_admin()) { return; }
    echo '<style id="ga-cps-v16-polish">
/* Keep the original Garibalde artwork and gently restore a premium, fluid carousel. */
#topo #slide.ga-cps-home-carousel{box-sizing:border-box!important;position:absolute!important;top:190px!important;left:0!important;right:auto!important;float:none!important;width:990px!important;max-width:100%!important;height:267px!important;min-height:0!important;overflow:hidden!important;border-radius:11px!important;background:#29211d!important;isolation:isolate!important;box-shadow:0 12px 28px rgba(22,16,12,.20),0 2px 5px rgba(22,16,12,.12)!important;z-index:2!important}
#topo #slide.ga-cps-home-carousel .ga-cps-slide{position:absolute!important;inset:0!important;display:block!important;float:none!important;width:100%!important;height:100%!important;margin:0!important;padding:0!important;overflow:hidden!important;border-radius:11px!important;opacity:0!important;visibility:hidden!important;z-index:0!important;transition:opacity 1050ms ease,visibility 1050ms ease!important}
#topo #slide.ga-cps-home-carousel .ga-cps-slide.is-active{opacity:1!important;visibility:visible!important;z-index:1!important}
#topo #slide.ga-cps-home-carousel .ga-cps-slide img{display:block!important;position:absolute!important;inset:0!important;width:100%!important;height:100%!important;max-width:none!important;object-fit:cover!important;object-position:center!important;float:none!important;border:0!important;border-radius:11px!important;box-shadow:none!important}
#topo #slide.ga-cps-home-carousel .ga-cps-slider-controls{position:absolute!important;right:15px!important;bottom:13px!important;z-index:5!important;display:flex!important;align-items:center!important;gap:7px!important;padding:6px 8px!important;background:rgba(33,26,23,.43)!important;border:1px solid rgba(255,255,255,.28)!important;border-radius:30px!important;backdrop-filter:blur(8px)!important;-webkit-backdrop-filter:blur(8px)!important}
#topo #slide.ga-cps-home-carousel .ga-cps-slide-link{display:block!important;position:absolute!important;inset:0!important;z-index:2!important;text-decoration:none!important;border:0!important;outline-offset:3px!important}
#topo #slide.ga-cps-home-carousel .ga-cps-slider-ctas{position:absolute!important;left:15px!important;bottom:13px!important;z-index:6!important;display:flex!important;flex-wrap:wrap!important;align-items:center!important;gap:7px!important;max-width:calc(100% - 180px)!important}
#topo #slide.ga-cps-home-carousel .ga-cps-slider-cta-link{display:inline-flex!important;align-items:center!important;justify-content:center!important;padding:8px 12px!important;background:rgba(41,33,29,.78)!important;border:1px solid rgba(255,255,255,.55)!important;border-radius:4px!important;color:#fff!important;font:700 11px/1.35 Arial,Helvetica,sans-serif!important;text-decoration:none!important;box-shadow:none!important}
#topo #slide.ga-cps-home-carousel .ga-cps-slider-cta-link:hover,#topo #slide.ga-cps-home-carousel .ga-cps-slider-cta-link:focus-visible{background:#6a5a81!important;color:#fff!important;outline:2px solid #fff!important;outline-offset:2px!important}
#topo #slide.ga-cps-home-carousel .ga-cps-slider-arrow{display:flex!important;align-items:center!important;justify-content:center!important;width:27px!important;height:27px!important;padding:0!important;border:1px solid rgba(255,255,255,.45)!important;border-radius:50%!important;background:rgba(255,255,255,.12)!important;color:#fff!important;font:normal 21px/1 Arial,Helvetica,sans-serif!important;cursor:pointer!important;box-shadow:none!important;transition:background .2s ease,border-color .2s ease!important}
#topo #slide.ga-cps-home-carousel .ga-cps-slider-arrow:hover,#topo #slide.ga-cps-home-carousel .ga-cps-slider-arrow:focus-visible{background:#a97939!important;border-color:#ead4b5!important;outline:2px solid rgba(255,255,255,.8)!important;outline-offset:1px!important}
#topo #slide.ga-cps-home-carousel .ga-cps-slider-dots{display:flex!important;align-items:center!important;gap:5px!important;margin:0 2px!important;padding:0!important}
#topo #slide.ga-cps-home-carousel .ga-cps-slider-dot{display:block!important;width:7px!important;height:7px!important;min-width:7px!important;margin:0!important;padding:0!important;border:1px solid rgba(255,255,255,.9)!important;border-radius:50%!important;background:transparent!important;cursor:pointer!important;box-shadow:none!important}
#topo #slide.ga-cps-home-carousel .ga-cps-slider-dot[aria-current="true"]{width:19px!important;min-width:19px!important;border-radius:8px!important;background:#e8c99b!important;border-color:#e8c99b!important}
/* Quiet refinement of the existing homepage cards: retain their structure and historic content. */
body.home #meio #sobre-home{border:1px solid rgba(140,118,92,.18)!important;border-radius:12px!important;overflow:hidden!important;box-shadow:0 7px 22px rgba(47,35,25,.07)!important;transition:box-shadow .25s ease,transform .25s ease!important}
body.home #meio #sobre-home:hover{box-shadow:0 12px 30px rgba(47,35,25,.11)!important;transform:translateY(-2px)!important}
body.home #meio #sobre-home>a{border-radius:5px!important;transition:background .2s ease,transform .2s ease!important}
body.home #meio #sobre-home>a:hover{background:#6a5a81!important;transform:translateY(-1px)!important}
body.home #meio #noticias-lateral{border:1px solid rgba(140,118,92,.17)!important;border-radius:12px!important;box-shadow:0 6px 20px rgba(47,35,25,.045)!important;overflow:hidden!important}
body.home #meio #noticias-lateral .titulo-bloco{padding-bottom:10px!important;border-bottom:1px solid rgba(140,118,92,.25)!important;font-family:Georgia,"Times New Roman",serif!important;font-size:22px!important;color:#3e3329!important}
body.home #meio #noticias-lateral li{padding:12px 0!important;border-bottom:1px solid rgba(140,118,92,.15)!important;line-height:1.6!important}
body.home #meio #noticias-lateral li:last-child{border-bottom:0!important}
body.home #meio #noticias-lateral li a{color:#625477!important;text-decoration:none!important;transition:color .2s ease!important}
body.home #meio #noticias-lateral li a:hover{color:#986a32!important}
body.home #meio #newsletter-home .titulo-bloco{font-family:Georgia,"Times New Roman",serif!important;font-size:25px!important;color:#3e3329!important}
body.home #meio #newsletter-home input:not([type=hidden]){max-width:100%!important;box-sizing:border-box!important;border:1px solid #d8ccbc!important;border-radius:5px!important;background:rgba(255,255,255,.84)!important;padding:9px 11px!important;box-shadow:none!important}
body.home #meio #newsletter-home .sml_submitbtn{background:#33251d!important;color:#fff!important;border-color:#33251d!important;cursor:pointer!important}
body.home #meio #newsletter-home .sml_submitbtn:hover{background:#6a5a81!important;border-color:#6a5a81!important}
/* The old theme outputs a decorative page-title strip. Keep the new consultation layout clear. */
body.page-consulta-processual .titulo-pagina,body.page-consulta-processual .breadcrumb,body.page-consulta-processual .breadcrumbs,body.page-consulta-processual .page-title,body.page-consulta-processual .entry-title,body.page-id-258 .titulo-pagina,body.page-id-258 .breadcrumb,body.page-id-258 .breadcrumbs,body.page-id-258 .page-title,body.page-id-258 .entry-title{display:none!important;visibility:hidden!important;height:0!important;min-height:0!important;margin:0!important;padding:0!important;border:0!important;overflow:hidden!important}
body.page-consulta-processual .conteudo-pagina,body.page-id-258 .conteudo-pagina{background:transparent!important;padding:0!important;margin:0!important;border:0!important;border-radius:0!important;box-shadow:none!important;text-shadow:none!important;overflow:visible!important}
@media(max-width:700px){#topo #slide.ga-cps-home-carousel{top:190px!important;width:100%!important;height:auto!important;aspect-ratio:990/267!important;border-radius:8px!important}#topo #slide.ga-cps-home-carousel .ga-cps-slide,#topo #slide.ga-cps-home-carousel .ga-cps-slide img{border-radius:8px!important}#topo #slide.ga-cps-home-carousel .ga-cps-slider-controls{right:8px!important;bottom:8px!important;gap:5px!important;padding:4px 6px!important}#topo #slide.ga-cps-home-carousel .ga-cps-slider-arrow{width:23px!important;height:23px!important;font-size:18px!important}}
@media(prefers-reduced-motion:reduce){#topo #slide.ga-cps-home-carousel .ga-cps-slide{transition:none!important}}
</style>';
}
add_action('wp_head', 'ga_cps_v16_carousel_styles', 100);

function ga_cps_v16_carousel_script() {
    if (is_admin() || (!is_front_page() && !is_home())) { return; }
    $fallback_base = esc_url(plugins_url('assets/', __FILE__));
    echo '<script id="ga-cps-v16-carousel">(function(){"use strict";
function initGaribaldeCarousel(){
 var root=document.querySelector("#topo #slide");
 if(!root||root.getAttribute("data-ga-carousel-v16")==="1")return;
 var original=[].slice.call(root.querySelectorAll("img"));
 var slides=[],seen={},standaloneCtas=[];
 [].slice.call(root.querySelectorAll("a")).forEach(function(a){var text=(a.textContent||"").replace(/\s+/g," ").trim();if(!a.querySelector("img")&&a.href&&text){standaloneCtas.push({href:a.href,text:text,target:a.getAttribute("target")||"",rel:a.getAttribute("rel")||"",aria:a.getAttribute("aria-label")||""});}});
 original.forEach(function(img){var src=img.currentSrc||img.getAttribute("src")||"";var a=img.closest("a");var href=a?(a.getAttribute("href")||a.href||""):"";var key=src+"|"+href;if(src&&!seen[key]){seen[key]=1;slides.push({src:src,alt:img.getAttribute("alt")||"Advocacia e Consultoria Empresarial e Tributária",href:href,target:a?(a.getAttribute("target")||""):"",rel:a?(a.getAttribute("rel")||""):"",aria:a?(a.getAttribute("aria-label")||""):""});}});
 var fallback=' . wp_json_encode($fallback_base) . ';
 if(slides.length<3){slides=[];seen={};["slide-1.png","slide-2.png","slide-3.png"].forEach(function(file){var src=fallback+file;if(!seen[src]){seen[src]=1;slides.push({src:src,alt:"Advocacia e Consultoria Empresarial e Tributária"});}});}
 if(slides.length<2)return;
 root.setAttribute("data-ga-carousel-v16","1");root.classList.add("ga-cps-home-carousel");root.setAttribute("role","region");root.setAttribute("aria-label","Imagens de apresentação do escritório");root.setAttribute("aria-roledescription","carrossel");
 root.innerHTML="";
 var frames=[],dots=[],current=0,timer=null,reduce=window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches;
 slides.forEach(function(item,index){var frame=document.createElement("div");frame.className="ga-cps-slide"+(index===0?" is-active":"");frame.setAttribute("role","group");frame.setAttribute("aria-roledescription","slide");frame.setAttribute("aria-label",(index+1)+" de "+slides.length);var img=document.createElement("img");img.src=item.src;img.alt=item.alt;img.decoding="async";img.loading=index===0?"eager":"lazy";if(item.href){var link=document.createElement("a");link.className="ga-cps-slide-link";link.href=item.href;if(item.target)link.target=item.target;if(item.rel)link.rel=item.rel;if(item.aria)link.setAttribute("aria-label",item.aria);else link.setAttribute("aria-label",item.alt||"Abrir conteúdo");link.appendChild(img);frame.appendChild(link);}else{frame.appendChild(img);}root.appendChild(frame);frames.push(frame);});
 if(standaloneCtas.length){var ctaWrap=document.createElement("div");ctaWrap.className="ga-cps-slider-ctas";ctaWrap.setAttribute("aria-label","Links da apresentação do escritório");standaloneCtas.forEach(function(item){var link=document.createElement("a");link.className="ga-cps-slider-cta-link";link.href=item.href;link.textContent=item.text;if(item.target)link.target=item.target;if(item.rel)link.rel=item.rel;if(item.aria)link.setAttribute("aria-label",item.aria);ctaWrap.appendChild(link);});root.appendChild(ctaWrap);}
 var controls=document.createElement("div");controls.className="ga-cps-slider-controls";controls.setAttribute("aria-label","Controles do carrossel");
 var prev=document.createElement("button");prev.type="button";prev.className="ga-cps-slider-arrow";prev.setAttribute("aria-label","Imagem anterior");prev.innerHTML="&#8249;";
 var dotWrap=document.createElement("div");dotWrap.className="ga-cps-slider-dots";
 slides.forEach(function(item,index){var dot=document.createElement("button");dot.type="button";dot.className="ga-cps-slider-dot";dot.setAttribute("aria-label","Mostrar imagem "+(index+1));dot.setAttribute("aria-current",index===0?"true":"false");dot.addEventListener("click",function(){show(index,true);});dotWrap.appendChild(dot);dots.push(dot);});
 var next=document.createElement("button");next.type="button";next.className="ga-cps-slider-arrow";next.setAttribute("aria-label","Próxima imagem");next.innerHTML="&#8250;";controls.appendChild(prev);controls.appendChild(dotWrap);controls.appendChild(next);root.appendChild(controls);
 function show(index,resetTimer){current=(index+frames.length)%frames.length;frames.forEach(function(frame,i){frame.classList.toggle("is-active",i===current);frame.setAttribute("aria-hidden",i===current?"false":"true");});dots.forEach(function(dot,i){dot.setAttribute("aria-current",i===current?"true":"false");});if(resetTimer)restart();}
 function stop(){if(timer){window.clearInterval(timer);timer=null;}}
 function restart(){stop();if(!reduce&&!document.hidden)timer=window.setInterval(function(){show(current+1,false);},6000);}
 prev.addEventListener("click",function(){show(current-1,true);});next.addEventListener("click",function(){show(current+1,true);});root.addEventListener("mouseenter",stop);root.addEventListener("mouseleave",restart);root.addEventListener("focusin",stop);root.addEventListener("focusout",restart);document.addEventListener("visibilitychange",function(){document.hidden?stop():restart();});restart();
}
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",initGaribaldeCarousel);else initGaribaldeCarousel();
})();</script>';
}
add_action('wp_footer', 'ga_cps_v16_carousel_script', 5);
