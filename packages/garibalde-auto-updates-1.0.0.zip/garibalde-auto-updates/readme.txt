=== Garibalde Amaral — Atualizações Automáticas ===
Contributors: garibaldeamaral
Tags: updates, private-plugin, auto-updates
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Gerencia versões estáveis dos plugins personalizados da Garibalde Amaral por manifesto JSON hospedado em URL HTTPS e utiliza o mecanismo nativo de atualizações do WordPress.

= Importante =
O plugin não cria nem publica o repositório remoto. Depois de publicar o repositório e os pacotes ZIP, informe a URL HTTPS de manifest.json em Configurações > Garibalde Atualizações. Não habilite atualizações automáticas antes de validar os pacotes.
