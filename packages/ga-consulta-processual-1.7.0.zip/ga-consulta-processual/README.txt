GARIBALDE — CONSULTA PROCESSUAL SEGURA 1.7.0

INSTALAÇÃO SEGURA
1. Faça backup do site e da base de dados.
2. Em WordPress > Plugins, DESATIVE o plugin antigo “Consulta Processual Segura - Garibalde Advogados” 1.6.1. Não o exclua.
3. Plugins > Adicionar novo plugin > Enviar plugin; envie ga-consulta-processual-1.7.0.zip, instale e ative.
4. Edite a página existente “Consulta Processual” e insira no conteúdo: [ga_consulta_processual]
5. Atualize a página. Teste os três links em nova aba e no celular.
6. Para reverter: desative 1.7.0 e reative 1.6.1.

Esta versão não cria nem redireciona páginas, não altera o cabeçalho, o tema WMD, o carrossel, as notícias ou as páginas de áreas de atuação. O problema da página Arbitragem e Mediação é independente e precisa de reparo próprio. Os URLs dos tribunais devem ser testados no navegador.
