<?php
/**
 * Plugin Name: Garibalde Amaral — Alertas de Atendimento R.A.I.
 * Description: Diagnostica a integração Resolai/R.A.I. e notifica o e-mail interno quando uma conversa for encaminhada para atendimento humano. Não lê nem reproduz o conteúdo das conversas no aviso.
 * Version: 1.0.1
 * Author: Garibalde Amaral Advogados Associados
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 * Text Domain: garibalde-rai-alertas
 */

if (!defined('ABSPATH')) { exit; }

final class Garibalde_RAI_Alertas {
    const VERSION = '1.0.1';
    const OPT_EMAIL = 'ga_rai_alert_email';
    const OPT_STARTED = 'ga_rai_alert_started_at';
    const OPT_LAST_CHECK = 'ga_rai_alert_last_check';
    const CRON_HOOK = 'ga_rai_alert_check_handoffs';

    public static function init() {
        add_filter('cron_schedules', array(__CLASS__, 'cron_schedules'));
        add_action('init', array(__CLASS__, 'ensure_cron'));
        add_action(self::CRON_HOOK, array(__CLASS__, 'check_handoffs'));
        add_action('admin_menu', array(__CLASS__, 'admin_menu'));
        add_action('admin_post_ga_rai_alert_save', array(__CLASS__, 'save_settings'));
        add_action('admin_post_ga_rai_alert_test', array(__CLASS__, 'send_test_email'));
    }

    public static function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = self::log_table();
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            session_ref bigint(20) unsigned NOT NULL DEFAULT 0,
            session_key varchar(64) NOT NULL,
            first_seen_at datetime NOT NULL,
            last_attempt_at datetime DEFAULT NULL,
            sent_at datetime DEFAULT NULL,
            status varchar(20) NOT NULL DEFAULT 'pending',
            attempts smallint(5) unsigned NOT NULL DEFAULT 0,
            last_error text DEFAULT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY session_key (session_key),
            KEY status_attempt (status,last_attempt_at)
        ) {$charset};";
        dbDelta($sql);
        if (!get_option(self::OPT_EMAIL)) {
            add_option(self::OPT_EMAIL, sanitize_email(get_option('admin_email', '')));
        }
        if (!get_option(self::OPT_STARTED)) {
            add_option(self::OPT_STARTED, current_time('mysql'));
        }
        self::ensure_cron();
    }

    public static function deactivate() {
        $timestamp = wp_next_scheduled(self::CRON_HOOK);
        while ($timestamp) {
            wp_unschedule_event($timestamp, self::CRON_HOOK);
            $timestamp = wp_next_scheduled(self::CRON_HOOK);
        }
    }

    public static function cron_schedules($schedules) {
        if (!isset($schedules['ga_rai_every_minute'])) {
            $schedules['ga_rai_every_minute'] = array(
                'interval' => 60,
                'display' => 'A cada minuto (Alertas R.A.I.)',
            );
        }
        return $schedules;
    }

    public static function ensure_cron() {
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time() + 60, 'ga_rai_every_minute', self::CRON_HOOK);
        }
    }

    private static function log_table() {
        global $wpdb;
        return $wpdb->prefix . 'ga_rai_alert_log';
    }

    private static function source_table() {
        global $wpdb;
        return $wpdb->prefix . 'wpreplai_sessions';
    }

    private static function table_exists($table) {
        global $wpdb;
        $like = $wpdb->esc_like($table);
        return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $like)) === $table;
    }

    private static function source_ready() {
        global $wpdb;
        $table = self::source_table();
        if (!self::table_exists($table)) { return false; }
        $cols = $wpdb->get_col("SHOW COLUMNS FROM `" . esc_sql($table) . "`", 0);
        return is_array($cols) && in_array('handed_off', $cols, true) && in_array('session_id', $cols, true) && in_array('created_at', $cols, true);
    }

    public static function check_handoffs() {
        global $wpdb;
        update_option(self::OPT_LAST_CHECK, current_time('mysql'), false);
        if (!self::source_ready() || !self::table_exists(self::log_table())) { return; }

        $source = self::source_table();
        $started = (string) get_option(self::OPT_STARTED, current_time('mysql'));
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, session_id, created_at FROM `" . esc_sql($source) . "` WHERE handed_off = 1 AND created_at >= %s ORDER BY id ASC LIMIT 100",
            $started
        ));
        if (!is_array($rows) || empty($rows)) { return; }

        foreach ($rows as $row) {
            $session_key = isset($row->session_id) ? sanitize_text_field((string) $row->session_id) : '';
            if ($session_key === '') { continue; }
            $existing = $wpdb->get_row($wpdb->prepare(
                'SELECT id,status,first_seen_at,last_attempt_at,attempts FROM `' . esc_sql(self::log_table()) . '` WHERE session_key = %s LIMIT 1',
                $session_key
            ));
            if ($existing && $existing->status === 'sent') { continue; }
            if ($existing && !empty($existing->last_attempt_at)) {
                $last = strtotime($existing->last_attempt_at);
                if ($last && (time() - $last) < 300) { continue; }
            }

            $email = sanitize_email(get_option(self::OPT_EMAIL, get_option('admin_email', '')));
            if (!is_email($email)) { continue; }

            $subject = '[Garibalde Amaral] Novo atendimento precisa de verificação';
            $body = "A IA do site encaminhou uma conversa para atendimento humano.\n\n";
            $body .= "Data do registro: " . sanitize_text_field((string) $row->created_at) . "\n";
            $body .= "ID interno da conversa: " . absint($row->id) . "\n\n";
            $body .= "Acesse o painel do WordPress e selecione R.A.I. para verificar a conversa.\n";
            $body .= "Este aviso não contém o texto da conversa nem dados pessoais do visitante.\n\n";
            $body .= "Se a situação envolver prazo ou audiência, confirme pessoalmente os próximos passos antes de assumir qualquer compromisso.";

            $attempts = $existing ? ((int) $existing->attempts + 1) : 1;
            $sent = self::safe_mail($email, $subject, $body, array('Content-Type: text/plain; charset=UTF-8'));
            $now = current_time('mysql');
            $data = array(
                'session_ref' => absint($row->id),
                'session_key' => $session_key,
                'first_seen_at' => $existing ? $existing->first_seen_at ?? $now : $now,
                'last_attempt_at' => $now,
                'sent_at' => $sent ? $now : null,
                'status' => $sent ? 'sent' : 'retry',
                'attempts' => $attempts,
                'last_error' => $sent ? null : 'wp_mail() não confirmou o envio; será tentado novamente após 5 minutos.',
            );
            $formats = array('%d','%s','%s','%s','%s','%s','%d','%s');
            $wpdb->replace(self::log_table(), $data, $formats);
        }

        // Keep only recent notification records; no conversation text is stored here.
        $wpdb->query('DELETE FROM `' . esc_sql(self::log_table()) . '` WHERE first_seen_at < DATE_SUB(NOW(), INTERVAL 90 DAY)');
    }

    public static function admin_menu() {
        add_management_page(
            'Alertas de Atendimento R.A.I.',
            'Alertas de Atendimento R.A.I.',
            'manage_options',
            'ga-rai-alertas',
            array(__CLASS__, 'render_page')
        );
    }

    public static function save_settings() {
        if (!current_user_can('manage_options')) { wp_die('Acesso não autorizado.'); }
        check_admin_referer('ga_rai_alert_save');
        $email = isset($_POST['notification_email']) ? sanitize_email(wp_unslash($_POST['notification_email'])) : '';
        if (!is_email($email)) {
            wp_safe_redirect(add_query_arg(array('page'=>'ga-rai-alertas','ga_rai_msg'=>'invalid_email'), admin_url('tools.php')));
            exit;
        }
        update_option(self::OPT_EMAIL, $email, false);
        wp_safe_redirect(add_query_arg(array('page'=>'ga-rai-alertas','ga_rai_msg'=>'saved'), admin_url('tools.php')));
        exit;
    }

    /**
     * Send without allowing hosting-level mail() failures to become a fatal admin error.
     * The underlying SMTP configuration must still be corrected for delivery to work.
     */
    private static function safe_mail($to, $subject, $body, $headers = array()) {
        try {
            return wp_mail($to, $subject, $body, $headers);
        } catch (\Throwable $error) {
            update_option('ga_rai_alert_last_mail_error', array(
                'time' => current_time('mysql'),
                'type' => sanitize_text_field(get_class($error)),
                'message' => 'Falha no motor de envio do servidor. Configure SMTP autenticado antes de repetir o teste.',
            ), false);
            return false;
        }
    }

    public static function send_test_email() {
        if (!current_user_can('manage_options')) { wp_die('Acesso não autorizado.'); }
        check_admin_referer('ga_rai_alert_test');
        $email = sanitize_email(get_option(self::OPT_EMAIL, get_option('admin_email', '')));
        $subject = '[Teste] Alertas de Atendimento R.A.I. — Garibalde Amaral';
        $body = "Este é um teste de e-mail do módulo Alertas de Atendimento R.A.I.\n\n";
        $body .= "Se recebeu esta mensagem, o WordPress aceitou o envio pelo mecanismo de e-mail configurado.\n";
        $body .= "O recebimento efetivo deve ser confirmado na caixa de entrada e na pasta de spam.\n\n";
        $body .= "Data/hora: " . current_time('mysql') . "\n";
        $sent = is_email($email) && self::safe_mail($email, $subject, $body, array('Content-Type: text/plain; charset=UTF-8'));
        wp_safe_redirect(add_query_arg(array('page'=>'ga-rai-alertas','ga_rai_msg'=>$sent?'test_sent':'test_failed'), admin_url('tools.php')));
        exit;
    }

    private static function plugin_active() {
        $active = (array) get_option('active_plugins', array());
        return in_array('resolai-ai-customer-support/resolai-ai-customer-support.php', $active, true);
    }

    public static function render_page() {
        if (!current_user_can('manage_options')) { wp_die('Acesso não autorizado.'); }
        global $wpdb;
        $source = self::source_table();
        $source_exists = self::table_exists($source);
        $ready = self::source_ready();
        $latest = null;
        $count = null;
        if ($ready) {
            $latest = $wpdb->get_var('SELECT MAX(created_at) FROM `' . esc_sql($source) . '`');
            $count = (int) $wpdb->get_var('SELECT COUNT(*) FROM `' . esc_sql($source) . '` WHERE handed_off = 1');
        }
        $log = self::log_table();
        $log_exists = self::table_exists($log);
        $last_check = (string) get_option(self::OPT_LAST_CHECK, 'Ainda não executado');
        $next = wp_next_scheduled(self::CRON_HOOK);
        $email = sanitize_email(get_option(self::OPT_EMAIL, get_option('admin_email', '')));
        $msg = isset($_GET['ga_rai_msg']) ? sanitize_key(wp_unslash($_GET['ga_rai_msg'])) : '';
        echo '<div class="wrap"><h1>Alertas de Atendimento R.A.I.</h1>';
        echo '<p>Este complemento não altera o plugin Resolai/R.A.I. nem lê o conteúdo das conversas. Ele verifica a marca de encaminhamento para atendimento humano e envia um aviso genérico por e-mail. O e-mail completo da habilidade Support Email continua sendo responsabilidade do Resolai.</p>';
        if ($msg === 'saved') { echo '<div class="notice notice-success"><p>Endereço de notificação salvo.</p></div>'; }
        elseif ($msg === 'invalid_email') { echo '<div class="notice notice-error"><p>Informe um endereço de e-mail válido.</p></div>'; }
        elseif ($msg === 'test_sent') { echo '<div class="notice notice-success"><p>O WordPress aceitou o envio do e-mail de teste. Confirme o recebimento na caixa de entrada e no spam; isto não comprova, sozinho, a entrega final.</p></div>'; }
        elseif ($msg === 'test_failed') { echo '<div class="notice notice-error"><p>O WordPress não confirmou o envio. Verifique o endereço e a configuração de e-mail/SMTP da hospedagem.</p></div>'; }

        echo '<h2>Diagnóstico</h2><table class="widefat striped" style="max-width:1000px"><tbody>';
        self::status_row('Usuário pode administrar configurações', current_user_can('manage_options') ? 'SIM' : 'NÃO');
        self::status_row('Resolai ativo segundo a lista do WordPress', self::plugin_active() ? 'SIM' : 'NÃO — verificar instalação/ativação');
        self::status_row('Tabela de sessões detectada', $source_exists ? 'SIM (' . esc_html($source) . ')' : 'NÃO — a tabela não foi encontrada');
        self::status_row('Campos necessários para identificar encaminhamentos', $ready ? 'SIM' : 'NÃO — esquema diferente ou incompleto');
        self::status_row('Tabela interna de controle', $log_exists ? 'SIM' : 'NÃO');
        self::status_row('Conversas marcadas para atendimento humano (histórico total)', $count === null ? 'Indisponível' : number_format_i18n($count));
        self::status_row('Registro mais recente na tabela de sessões', $latest ? esc_html($latest) : 'Nenhum registro');
        self::status_row('Última verificação do complemento', esc_html($last_check));
        self::status_row('Próxima verificação agendada', $next ? esc_html(wp_date('d/m/Y H:i:s', $next)) : 'Não agendada');
        self::status_row('WP-Cron desativado por configuração', (defined('DISABLE_WP_CRON') && DISABLE_WP_CRON) ? 'SIM — exige cron real na hospedagem' : 'NÃO');
        echo '</tbody></table>';

        echo '<h2>Destino dos avisos</h2><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="ga_rai_alert_save">';
        wp_nonce_field('ga_rai_alert_save');
        echo '<p><label for="ga-rai-email">E-mail que receberá o aviso</label><br><input id="ga-rai-email" name="notification_email" type="email" class="regular-text" required value="' . esc_attr($email) . '"></p>';
        echo '<p class="description">Padrão: e-mail administrativo do WordPress. Recomendado: uma caixa que já esteja com notificações ativadas no Gmail do Samsung.</p>';
        submit_button('Salvar destino do aviso');
        echo '</form>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin-top:12px">';
        echo '<input type="hidden" name="action" value="ga_rai_alert_test">';
        wp_nonce_field('ga_rai_alert_test');
        submit_button('Enviar e-mail de teste', 'secondary');
        echo '</form>';

        echo '<h2>O que este complemento faz — e o que não faz</h2><ul style="list-style:disc;padding-left:24px;max-width:1000px">';
        echo '<li>Verifica a tabela de sessões do Resolai e procura conversas assinaladas como encaminhadas para atendimento humano.</li>';
        echo '<li>Envia um aviso interno genérico; não inclui nome, e-mail, resumo jurídico ou texto da conversa no alerta.</li>';
        echo '<li>Evita enviar o mesmo aviso novamente após confirmação de envio e retenta falhas após intervalo de segurança.</li>';
        echo '<li>O agendamento usa WP-Cron: a execução pode atrasar até chegar uma requisição ao site. Não é garantia de entrega instantânea.</li>';
        echo '<li>Não envia mensagem dentro do WhatsApp. Isso exige credenciais e configuração da WhatsApp Business Platform; este complemento não modifica sua conta WhatsApp Business.</li>';
        echo '<li>A tela R.A.I. bloqueada continua sendo uma questão separada. O diagnóstico acima ajudará a separar problema de permissão, ausência de tabela ou falha de integração.</li>';
        echo '</ul></div>';
    }

    private static function status_row($label, $value) {
        echo '<tr><th style="width:360px">' . esc_html($label) . '</th><td>' . wp_kses_post($value) . '</td></tr>';
    }
}

register_activation_hook(__FILE__, array('Garibalde_RAI_Alertas', 'activate'));
register_deactivation_hook(__FILE__, array('Garibalde_RAI_Alertas', 'deactivate'));
Garibalde_RAI_Alertas::init();
