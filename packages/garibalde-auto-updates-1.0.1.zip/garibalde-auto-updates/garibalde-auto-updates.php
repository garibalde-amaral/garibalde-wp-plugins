<?php
/**
 * Plugin Name: Garibalde Amaral — Atualizações Automáticas
 * Description: Gerencia atualizações de plugins personalizados Garibalde por manifesto HTTPS, integrado à tela nativa de atualizações do WordPress.
 * Version: 1.0.1
 * Author: Garibalde Amaral Advogados Associados
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 * Text Domain: garibalde-auto-updates
 */
if (!defined('ABSPATH')) { exit; }

final class GA_Auto_Updates {
    const VERSION = '1.0.1';
    const OPTION = 'ga_auto_updates_settings';
    const CACHE = 'ga_auto_updates_manifest_cache';
    const CACHE_TTL = 6 * HOUR_IN_SECONDS;
    const NONCE = 'ga_auto_updates_action';

    public static function init() {
        add_filter('pre_set_site_transient_update_plugins', array(__CLASS__, 'inject_updates'));
        add_filter('plugins_api', array(__CLASS__, 'plugin_information'), 20, 3);
        add_filter('auto_update_plugin', array(__CLASS__, 'auto_update_managed'), 20, 2);
        add_action('admin_menu', array(__CLASS__, 'admin_menu'));
        add_action('admin_post_ga_auto_updates_save', array(__CLASS__, 'save_settings'));
        add_action('admin_post_ga_auto_updates_check', array(__CLASS__, 'check_now'));
        add_action('admin_notices', array(__CLASS__, 'admin_notice'));
    }

    public static function defaults() {
        return array(
            'manifest_url' => '',
            'auto_update_managed' => 0,
        );
    }

    public static function settings() {
        $saved = get_option(self::OPTION, array());
        if (!is_array($saved)) { $saved = array(); }
        return wp_parse_args($saved, self::defaults());
    }

    private static function valid_https_url($url) {
        $url = esc_url_raw(trim((string) $url), array('https'));
        return $url && wp_http_validate_url($url) ? $url : '';
    }

    public static function get_manifest($force = false) {
        if (!$force) {
            $cached = get_transient(self::CACHE);
            if (is_array($cached) && !empty($cached['_ga_valid'])) { return $cached; }
        }
        $url = self::valid_https_url(self::settings()['manifest_url']);
        if (!$url) { return new WP_Error('ga_manifest_unconfigured', 'URL HTTPS do manifesto ainda não configurada.'); }
        $response = wp_remote_get($url, array(
            'timeout' => 10,
            'redirection' => 3,
            'sslverify' => true,
            'headers' => array('Accept' => 'application/json', 'User-Agent' => 'GaribaldeAutoUpdates/' . self::VERSION . '; ' . home_url('/')),
        ));
        if (is_wp_error($response)) { return new WP_Error('ga_manifest_http', 'Falha ao acessar o manifesto HTTPS: ' . $response->get_error_message()); }
        $status = (int) wp_remote_retrieve_response_code($response);
        if ($status !== 200) { return new WP_Error('ga_manifest_status', 'O manifesto respondeu com HTTP ' . $status . '.'); }
        $body = wp_remote_retrieve_body($response);
        if (!is_string($body) || strlen($body) > 512000) { return new WP_Error('ga_manifest_size', 'Manifesto vazio ou maior que o limite permitido.'); }
        $manifest = json_decode($body, true);
        if (!is_array($manifest) || empty($manifest['schema_version']) || (int)$manifest['schema_version'] !== 1 || empty($manifest['plugins']) || !is_array($manifest['plugins'])) {
            return new WP_Error('ga_manifest_schema', 'Estrutura do manifesto inválida. Esperado schema_version=1 e objeto plugins.');
        }
        $clean = array('schema_version'=>1, 'generated_at'=>sanitize_text_field($manifest['generated_at'] ?? ''), 'plugins'=>array(), '_ga_valid'=>1, '_fetched_at'=>time());
        foreach ($manifest['plugins'] as $basename => $item) {
            if (!is_string($basename) || strpos($basename, '/') === false || !is_array($item)) { continue; }
            $version = sanitize_text_field((string)($item['version'] ?? ''));
            $package = self::valid_https_url($item['package_url'] ?? '');
            $slug = sanitize_key((string)($item['slug'] ?? ''));
            if (!$version || !$package || !$slug) { continue; }
            $clean['plugins'][$basename] = array(
                'slug' => $slug,
                'name' => sanitize_text_field((string)($item['name'] ?? $slug)),
                'version' => $version,
                'package_url' => $package,
                'details_url' => self::valid_https_url($item['details_url'] ?? '') ?: home_url('/'),
                'requires' => sanitize_text_field((string)($item['requires'] ?? '6.2')),
                'requires_php' => sanitize_text_field((string)($item['requires_php'] ?? '7.4')),
                'tested' => sanitize_text_field((string)($item['tested'] ?? '7.1.3')),
                'sections' => is_array($item['sections'] ?? null) ? $item['sections'] : array(),
            );
        }
        if (empty($clean['plugins'])) { return new WP_Error('ga_manifest_empty', 'Nenhum pacote válido foi encontrado no manifesto.'); }
        set_transient(self::CACHE, $clean, self::CACHE_TTL);
        update_option('ga_auto_updates_last_success', current_time('mysql'), false);
        delete_option('ga_auto_updates_last_error');
        return $clean;
    }

    private static function installed_plugins() {
        if (!function_exists('get_plugins')) { require_once ABSPATH . 'wp-admin/includes/plugin.php'; }
        return get_plugins();
    }

    public static function inject_updates($transient) {
        if (!is_object($transient)) { $transient = new stdClass(); }
        if (!isset($transient->response) || !is_array($transient->response)) { $transient->response = array(); }
        if (!isset($transient->no_update) || !is_array($transient->no_update)) { $transient->no_update = array(); }
        $manifest = self::get_manifest(false);
        if (is_wp_error($manifest)) {
            update_option('ga_auto_updates_last_error', sanitize_text_field($manifest->get_error_message()), false);
            return $transient;
        }
        $installed = self::installed_plugins();
        foreach ($manifest['plugins'] as $basename => $item) {
            if (!isset($installed[$basename])) { continue; }
            $current = (string)($installed[$basename]['Version'] ?? '0.0.0');
            $object = (object) array(
                'id' => $item['details_url'],
                'slug' => $item['slug'],
                'plugin' => $basename,
                'new_version' => $item['version'],
                'url' => $item['details_url'],
                'package' => $item['package_url'],
                'tested' => $item['tested'],
                'requires' => $item['requires'],
                'requires_php' => $item['requires_php'],
            );
            if (version_compare($item['version'], $current, '>')) {
                $transient->response[$basename] = $object;
                unset($transient->no_update[$basename]);
            } else {
                $transient->no_update[$basename] = $object;
                unset($transient->response[$basename]);
            }
        }
        return $transient;
    }

    public static function plugin_information($result, $action, $args) {
        if ($action !== 'plugin_information' || empty($args->slug)) { return $result; }
        $manifest = self::get_manifest(false);
        if (is_wp_error($manifest)) { return $result; }
        foreach ($manifest['plugins'] as $basename => $item) {
            if ($item['slug'] !== sanitize_key($args->slug)) { continue; }
            $installed = self::installed_plugins();
            return (object) array(
                'name' => $item['name'], 'slug' => $item['slug'], 'version' => $item['version'],
                'author' => '<a href="' . esc_url(home_url('/')) . '">Garibalde Amaral Advogados Associados</a>',
                'homepage' => $item['details_url'], 'requires' => $item['requires'], 'tested' => $item['tested'],
                'requires_php' => $item['requires_php'], 'download_link' => $item['package_url'],
                'sections' => array('description' => 'Plugin personalizado do ecossistema Garibalde Amaral. Atualizações distribuídas pelo repositório do escritório.', 'changelog' => 'Consulte a versão e o changelog no repositório oficial.'),
            );
        }
        return $result;
    }

    public static function auto_update_managed($update, $item) {
        if (!is_object($item) || empty($item->plugin)) { return $update; }
        $settings = self::settings();
        if (empty($settings['auto_update_managed'])) { return $update; }
        $manifest = self::get_manifest(false);
        if (is_wp_error($manifest) || !isset($manifest['plugins'][$item->plugin])) { return $update; }
        if (!empty($item->new_version) && !empty($item->package)) { return true; }
        return $update;
    }

    public static function admin_menu() {
        add_options_page('Garibalde — Atualizações', 'Garibalde Atualizações', 'manage_options', 'ga-auto-updates', array(__CLASS__, 'render_page'));
    }

    public static function save_settings() {
        if (!current_user_can('manage_options')) { wp_die('Acesso não autorizado.'); }
        check_admin_referer(self::NONCE);
        $url = isset($_POST['manifest_url']) ? self::valid_https_url(wp_unslash($_POST['manifest_url'])) : '';
        if (!$url && !empty($_POST['manifest_url'])) {
            wp_safe_redirect(add_query_arg(array('page'=>'ga-auto-updates','ga_update_status'=>'invalid_url'), admin_url('options-general.php')));
            exit;
        }
        $auto = !empty($_POST['auto_update_managed']) ? 1 : 0;
        update_option(self::OPTION, array('manifest_url'=>$url,'auto_update_managed'=>$auto), false);
        delete_transient(self::CACHE);
        $status = 'saved';
        if ($url) {
            $manifest = self::get_manifest(true);
            $status = is_wp_error($manifest) ? 'manifest_error' : 'manifest_ok';
            if (is_wp_error($manifest)) { update_option('ga_auto_updates_last_error', sanitize_text_field($manifest->get_error_message()), false); }
        }
        wp_safe_redirect(add_query_arg(array('page'=>'ga-auto-updates','ga_update_status'=>$status), admin_url('options-general.php')));
        exit;
    }

    public static function check_now() {
        if (!current_user_can('manage_options')) { wp_die('Acesso não autorizado.'); }
        check_admin_referer(self::NONCE);
        delete_transient(self::CACHE);
        $manifest = self::get_manifest(true);
        wp_clean_plugins_cache(false);
        delete_site_transient('update_plugins');
        wp_update_plugins();
        $status = is_wp_error($manifest) ? 'manifest_error' : 'manifest_ok';
        if (is_wp_error($manifest)) { update_option('ga_auto_updates_last_error', sanitize_text_field($manifest->get_error_message()), false); }
        wp_safe_redirect(add_query_arg(array('page'=>'ga-auto-updates','ga_update_status'=>$status), admin_url('options-general.php')));
        exit;
    }

    public static function admin_notice() {
        if (!is_admin() || !current_user_can('manage_options') || empty($_GET['ga_update_status'])) { return; }
        $status = sanitize_key(wp_unslash($_GET['ga_update_status']));
        $messages = array(
            'saved' => array('success','Configurações salvas. Configure o manifesto para ativar a verificação de versões.'),
            'manifest_ok' => array('success','Manifesto acessível e válido. Confira a lista de atualizações na tela de Plugins.'),
            'manifest_error' => array('error','Não foi possível validar o manifesto. Verifique a URL HTTPS e a publicação dos arquivos.'),
            'invalid_url' => array('error','A URL do manifesto deve ser HTTPS e válida.'),
        );
        if (isset($messages[$status])) { printf('<div class="notice notice-%s is-dismissible"><p>%s</p></div>', esc_attr($messages[$status][0]), esc_html($messages[$status][1])); }
    }

    public static function render_page() {
        if (!current_user_can('manage_options')) { return; }
        $settings = self::settings();
        $manifest = self::get_manifest(false);
        $last_success = (string)get_option('ga_auto_updates_last_success', '');
        $last_error = (string)get_option('ga_auto_updates_last_error', '');
        $installed = self::installed_plugins();
        echo '<div class="wrap"><h1>Garibalde Amaral — Atualizações Automáticas</h1>';
        echo '<p>Este gerenciador usa o mecanismo nativo do WordPress. Ele não instala código aleatório: só oferece pacotes presentes no manifesto HTTPS configurado pelo administrador.</p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="ga_auto_updates_save">';
        wp_nonce_field(self::NONCE);
        echo '<table class="form-table"><tr><th scope="row"><label for="manifest_url">URL HTTPS do manifesto</label></th><td><input class="regular-text code" id="manifest_url" name="manifest_url" type="url" value="' . esc_attr($settings['manifest_url']) . '" placeholder="https://raw.githubusercontent.com/USUARIO/garibalde-wp-plugins/main/manifest.json"><p class="description">URL HTTPS do manifesto público que contém as versões e os endereços dos pacotes autorizados.</p></td></tr>';
        echo '<tr><th scope="row">Instalação automática</th><td><label><input type="checkbox" name="auto_update_managed" value="1" ' . checked((int)$settings['auto_update_managed'], 1, false) . '> Instalar automaticamente atualizações estáveis dos plugins listados no manifesto</label><p class="description">Ative somente depois de validar o manifesto e testar a primeira atualização em produção. O controle aplica-se apenas aos plugins incluídos no manifesto.</p></td></tr></table>';
        submit_button('Salvar configurações'); echo '</form>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin-top:8px">';
        echo '<input type="hidden" name="action" value="ga_auto_updates_check">'; wp_nonce_field(self::NONCE); submit_button('Verificar manifesto e atualizações agora', 'secondary'); echo '</form>';
        echo '<h2>Estado</h2><ul>';
        echo '<li><strong>Manifesto:</strong> ' . (is_wp_error($manifest) ? '<span style="color:#b32d2e">Não validado</span>' : '<span style="color:#008a20">Válido/acessível</span>') . '</li>';
        echo '<li><strong>Última validação bem-sucedida:</strong> ' . esc_html($last_success ?: 'Ainda não ocorreu') . '</li>';
        if ($last_error) { echo '<li><strong>Último erro:</strong> ' . esc_html($last_error) . '</li>'; }
        echo '</ul><h2>Plugins gerenciados</h2><table class="widefat striped"><thead><tr><th>Plugin</th><th>Instalado</th><th>Versão local</th><th>Versão remota</th><th>Pacote</th></tr></thead><tbody>';
        $remote_plugins = is_wp_error($manifest) ? array() : $manifest['plugins'];
        $keys = array_unique(array_merge(array_keys($remote_plugins), array('garibalde-modo-manutencao/garibalde-modo-manutencao.php','garibalde-rai-alertas/garibalde-rai-alertas.php','garibalde-whatsapp-assistente/garibalde-whatsapp-assistente.php','garibalde-auto-updates/garibalde-auto-updates.php')));
        foreach ($keys as $basename) {
            $local = isset($installed[$basename]) ? (string)($installed[$basename]['Version'] ?? '—') : '—';
            $item = $remote_plugins[$basename] ?? null;
            $name = $item['name'] ?? $basename;
            $remote = $item['version'] ?? 'Aguardando manifesto';
            $pkg = $item ? '<a href="' . esc_url($item['package_url']) . '" target="_blank" rel="noopener noreferrer">Abrir pacote</a>' : 'Não publicado';
            printf('<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>', esc_html($name), isset($installed[$basename]) ? 'Sim' : 'Não', esc_html($local), esc_html($remote), $pkg);
        }
        echo '</tbody></table>';
        echo '<p><strong>Importante:</strong> o gerenciador lista as versões declaradas no manifesto HTTPS. Se um plugin aparecer como “Não instalado”, confira se o caminho completo do arquivo principal coincide com a chave usada no manifesto. Este gerenciador não publica arquivos no GitHub.</p>';
        echo '</div>';
    }
}
GA_Auto_Updates::init();
