Garibalde Amaral — Atualizações Automáticas 1.0.1

Correção: removida a referência fixa ao caminho antigo consulta-processual-segura/consulta-processual-segura.php da tabela de plugins gerenciados. A Consulta Processual passa a ser listada pelo caminho real declarado no manifesto.

Instalação: atualize pela tela nativa de plugins do WordPress após o gerenciador oferecer a versão 1.0.1. Não habilite atualização automática antes de concluir os testes.
