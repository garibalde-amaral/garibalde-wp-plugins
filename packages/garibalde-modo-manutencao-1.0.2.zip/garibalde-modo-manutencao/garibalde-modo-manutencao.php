<?php
/**
 * Plugin Name: Garibalde Amaral - Modo Manutenção Institucional
 * Description: Ativa uma página temporária de manutenção com identidade visual Garibalde Amaral e contato seguro via WhatsApp, preservando o acesso administrativo.
 * Version: 1.0.2
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Garibalde Amaral Advogados Associados
 * License: GPL-2.0-or-later
 * Text Domain: garibalde-modo-manutencao
 */
if (!defined('ABSPATH')) { exit; }

const GA_MM_OPTION = 'ga_mm_settings';

function ga_mm_defaults() {
    return array(
        'enabled' => 1,
        'whatsapp' => '5562991340228',
        'email' => '',
        'message' => 'Olá, acessei o site Garibalde Amaral durante a atualização e gostaria de falar com o escritório.',
        'facebook' => '',
        'instagram' => '',
        'tiktok' => '',
        'linkedin' => '',
        'youtube' => '',
    );
}
function ga_mm_settings() {
    $saved = get_option(GA_MM_OPTION, array());
    return wp_parse_args(is_array($saved) ? $saved : array(), ga_mm_defaults());
}
function ga_mm_activate() {
    if (get_option(GA_MM_OPTION, false) === false) {
        add_option(GA_MM_OPTION, ga_mm_defaults(), '', false);
    } else {
        $s = ga_mm_settings();
        $s['enabled'] = 1;
        update_option(GA_MM_OPTION, $s, false);
    }
}
register_activation_hook(__FILE__, 'ga_mm_activate');

function ga_mm_admin_menu() {
    add_options_page('Garibalde - Modo Manutenção', 'Garibalde Manutenção', 'manage_options', 'ga-mm-settings', 'ga_mm_settings_page');
}
add_action('admin_menu', 'ga_mm_admin_menu');

function ga_mm_register_settings() {
    register_setting('ga_mm_group', GA_MM_OPTION, array('sanitize_callback' => 'ga_mm_sanitize_settings'));
}
add_action('admin_init', 'ga_mm_register_settings');

function ga_mm_sanitize_settings($input) {
    $out = ga_mm_settings();
    $out['enabled'] = !empty($input['enabled']) ? 1 : 0;
    $phone = isset($input['whatsapp']) ? preg_replace('/[^0-9]/', '', (string)$input['whatsapp']) : $out['whatsapp'];
    $out['whatsapp'] = substr($phone, 0, 15);
    $out['email'] = isset($input['email']) ? sanitize_email((string)$input['email']) : $out['email'];
    if (!$out['email'] || !is_email($out['email'])) $out['email'] = '';
    $out['message'] = isset($input['message']) ? sanitize_textarea_field($input['message']) : $out['message'];
    foreach (array('facebook','instagram','tiktok','linkedin','youtube') as $key) {
        $value = isset($input[$key]) ? trim((string)$input[$key]) : '';
        $out[$key] = $value === '' ? '' : esc_url_raw($value, array('https','http'));
        if ($out[$key] && !preg_match('#^https?://#i', $out[$key])) $out[$key] = '';
    }
    return $out;
}

function ga_mm_settings_page() {
    if (!current_user_can('manage_options')) return;
    $s = ga_mm_settings();
    ?>
    <div class="wrap">
      <h1>Garibalde Amaral — Modo Manutenção</h1>
      <p>A ativação exibe a página temporária aos visitantes públicos. Administradores autenticados continuam vendo o site normal para trabalhar e testar.</p>
      <div style="padding:12px 16px;max-width:900px;background:#f6f2ec;border-left:4px solid #a66a2c;margin:16px 0">
        <strong>Importante para o Google:</strong> esta página responde com HTTP 503, adequado para uma indisponibilidade temporária curta. O Google alerta que manter 503 por períodos prolongados pode prejudicar a presença das páginas nos resultados. Para uma reconstrução de várias semanas, prefira desenvolver em homologação e manter o site público atual até a troca final.
      </div>
      <form method="post" action="options.php">
        <?php settings_fields('ga_mm_group'); ?>
        <table class="form-table" role="presentation">
          <tr><th scope="row">Modo de manutenção</th><td><label><input type="checkbox" name="<?php echo esc_attr(GA_MM_OPTION); ?>[enabled]" value="1" <?php checked(!empty($s['enabled'])); ?>> Exibir a página de manutenção para visitantes</label></td></tr>
          <tr><th scope="row"><label for="ga-mm-whatsapp">WhatsApp do escritório</label></th><td><input id="ga-mm-whatsapp" class="regular-text" name="<?php echo esc_attr(GA_MM_OPTION); ?>[whatsapp]" value="<?php echo esc_attr($s['whatsapp']); ?>"><p class="description">Use somente números com código do país e DDD. Inicial configurado conforme a solicitação: 55 62 99134-0228.</p></td></tr>
          <tr><th scope="row"><label for="ga-mm-email">E-mail de contato</label></th><td><input type="email" id="ga-mm-email" class="regular-text" name="<?php echo esc_attr(GA_MM_OPTION); ?>[email]" value="<?php echo esc_attr($s['email']); ?>"><p class="description">O botão de e-mail da página de manutenção abrirá uma mensagem para este endereço.</p></td></tr>
          <tr><th scope="row"><label for="ga-mm-message">Mensagem pré-preenchida</label></th><td><textarea id="ga-mm-message" rows="3" class="large-text" name="<?php echo esc_attr(GA_MM_OPTION); ?>[message]"><?php echo esc_textarea($s['message']); ?></textarea><p class="description">Não inclua CPF, número de processo ou informação sigilosa nesta mensagem padrão.</p></td></tr>
          <?php foreach (array('facebook'=>'Facebook','instagram'=>'Instagram','tiktok'=>'TikTok','linkedin'=>'LinkedIn','youtube'=>'YouTube') as $key=>$label): ?>
          <tr><th scope="row"><label for="ga-mm-<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?> — URL oficial</label></th><td><input type="url" id="ga-mm-<?php echo esc_attr($key); ?>" class="regular-text" name="<?php echo esc_attr(GA_MM_OPTION); ?>[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr($s[$key]); ?>" placeholder="https://"><p class="description">Deixe em branco até confirmar o perfil oficial; links vazios não serão exibidos.</p></td></tr>
          <?php endforeach; ?>
        </table>
        <?php submit_button('Salvar configurações'); ?>
      </form>
      <p><a class="button button-secondary" href="<?php echo esc_url(home_url('/')); ?>" target="_blank" rel="noopener">Abrir site (como administrador)</a> <a class="button button-secondary" href="<?php echo esc_url(add_query_arg('ga_mm_preview','1',home_url('/'))); ?>" target="_blank" rel="noopener">Pré-visualização da manutenção</a></p>
      <p class="description">A pré-visualização usa um parâmetro temporário e só é mostrada a administradores autenticados.</p>
    </div>
    <?php
}

function ga_mm_is_bypass_request() {
    if (is_admin() || (defined('DOING_AJAX') && DOING_AJAX) || (defined('DOING_CRON') && DOING_CRON)) return true;
    if (defined('REST_REQUEST') && REST_REQUEST) return true;
    if (isset($GLOBALS['pagenow']) && in_array($GLOBALS['pagenow'], array('wp-login.php','wp-register.php'), true)) return true;
    if (function_exists('wp_doing_ajax') && wp_doing_ajax()) return true;
    return false;
}

function ga_mm_template_redirect() {
    if (ga_mm_is_bypass_request()) return;
    $s = ga_mm_settings();
    if (empty($s['enabled'])) return;
    if (isset($_GET['ga_mm_preview']) && is_user_logged_in() && current_user_can('manage_options')) {
        // Administrador pode visualizar a tela sem bloquear o site para os outros visitantes.
        ga_mm_render_page($s, false);
        exit;
    }
    if (is_user_logged_in() && current_user_can('manage_options')) return;
    if (is_feed() || is_trackback()) return;
    ga_mm_render_page($s, true);
    exit;
}
add_action('template_redirect', 'ga_mm_template_redirect', 0);

function ga_mm_render_page($s, $send_503 = true) {
    if ($send_503) {
        if (!headers_sent()) {
            status_header(503);
            header('Retry-After: 3600');
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
        }
    } else {
        if (!headers_sent()) status_header(200);
    }
    $phone = preg_replace('/[^0-9]/', '', (string)$s['whatsapp']);
    $message = rawurlencode((string)$s['message']);
    $wa_url = $phone ? 'https://wa.me/' . $phone . ($message ? '?text=' . $message : '') : '';
    $socials = array(
        'facebook' => array('Facebook', 'f'),
        'instagram' => array('Instagram', '◎'),
        'tiktok' => array('TikTok', '♪'),
        'linkedin' => array('LinkedIn', 'in'),
        'youtube' => array('YouTube', '▶'),
    );
    $image = plugin_dir_url(__FILE__) . 'assets/garibalde-balanca.webp';
    ?><!doctype html>
    <html lang="pt-BR">
    <head>
      <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="theme-color" content="#171615">
      <title>Estamos renovando nossa presença digital | Garibalde Amaral</title>
      <meta name="description" content="O site Garibalde Amaral Advogados Associados está passando por uma renovação. O atendimento segue disponível pelos canais oficiais.">
      <style>
      :root{color-scheme:dark;--bg:#171615;--panel:#201e1c;--paper:#f4efe8;--gold:#bd8b52;--muted:#c9c1b7;--line:rgba(218,190,155,.23)}
      *{box-sizing:border-box}html{min-height:100%;background:var(--bg)}body{margin:0;min-height:100vh;font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;background:radial-gradient(circle at 15% 12%,rgba(166,106,44,.17),transparent 32%),linear-gradient(135deg,#141312 0%,#24211e 55%,#161514 100%);color:var(--paper);display:flex;align-items:center;justify-content:center;padding:32px 20px}
      .wrap{width:min(1160px,100%);margin:auto}.topline{display:flex;align-items:center;gap:12px;color:#d4c9bb;font-size:11px;font-weight:700;letter-spacing:.22em;text-transform:uppercase;margin:0 0 20px}.seal{width:34px;height:1px;background:var(--gold)}.panel{display:grid;grid-template-columns:1.04fr .96fr;min-height:565px;border:1px solid var(--line);border-radius:4px;overflow:hidden;background:linear-gradient(125deg,rgba(40,37,33,.98),rgba(25,24,22,.98));box-shadow:0 32px 90px rgba(0,0,0,.34)}
      .copy{padding:clamp(30px,5.5vw,72px);display:flex;flex-direction:column;justify-content:center;position:relative}.eyebrow{font-size:10px;letter-spacing:.2em;color:var(--gold);font-weight:750;text-transform:uppercase;margin:0 0 20px}.copy h1{font-family:Georgia,"Times New Roman",serif;font-size:clamp(36px,4.4vw,58px);font-weight:400;line-height:1.04;letter-spacing:-.035em;max-width:570px;margin:0 0 22px}.copy h1 span{color:#d4ad7d;font-style:italic}.lead{font-size:16px;line-height:1.75;color:#ded7ce;max-width:490px;margin:0 0 26px}.rule{width:70px;height:1px;background:var(--gold);margin:4px 0 26px}.note{border-left:2px solid var(--gold);padding:2px 0 2px 15px;color:#bdb4a8;font-size:12px;line-height:1.7;max-width:470px}.actions{display:flex;gap:12px;flex-wrap:wrap;margin-top:30px}.cta{min-height:48px;display:inline-flex;align-items:center;justify-content:center;gap:10px;padding:0 19px;text-decoration:none;font-size:12px;font-weight:750;letter-spacing:.015em;transition:transform .2s ease,background .2s ease,border-color .2s ease}.cta:hover{transform:translateY(-2px)}.cta-wa{background:#c9a36f;color:#1b1916;border:1px solid #d9b986}.cta-wa:hover{background:#e0bd89}.cta-secondary{border:1px solid rgba(244,239,232,.24);color:var(--paper);background:transparent}.cta-secondary:hover{border-color:var(--gold)}.arrow{font-size:16px}.photo{position:relative;min-height:565px;background:#30251b;overflow:hidden}.photo img{position:absolute;width:100%;height:100%;inset:0;object-fit:cover;object-position:62% center;opacity:.9}.photo:after{content:"";position:absolute;inset:0;background:linear-gradient(90deg,rgba(25,23,21,.25),transparent 35%),linear-gradient(0deg,rgba(19,18,17,.44),transparent 45%)}.photo-label{position:absolute;z-index:2;left:28px;right:24px;bottom:25px;font-size:10px;letter-spacing:.17em;text-transform:uppercase;color:#f1ddc3}.foot{display:flex;align-items:center;justify-content:space-between;gap:20px;color:#827a71;font-size:10px;line-height:1.6;margin-top:19px}.socials{display:flex;align-items:center;gap:8px}.socials a{display:grid;place-items:center;text-decoration:none;color:#dfd5c8;border:1px solid rgba(244,239,232,.2);width:30px;height:30px;border-radius:50%;font-size:12px}.socials a:hover{color:var(--gold);border-color:var(--gold)}
      @media(max-width:760px){body{padding:14px}.topline{margin-bottom:13px;font-size:9px;letter-spacing:.14em}.panel{grid-template-columns:1fr;min-height:0}.copy{padding:34px 25px 32px}.copy h1{font-size:42px}.lead{font-size:14px}.photo{min-height:265px;order:-1}.photo-label{left:22px;bottom:18px}.foot{align-items:flex-start;flex-direction:column;margin-top:15px}.actions{flex-direction:column}.cta{width:100%}}
      @media(prefers-reduced-motion:reduce){*,*:before,*:after{transition:none!important;scroll-behavior:auto!important}}
      </style>
    </head><body><main class="wrap">
      <div class="topline"><span class="seal"></span> Garibalde Amaral <span style="color:var(--gold)">/</span> Advogados Associados</div>
      <section class="panel" aria-labelledby="ga-maintenance-title">
        <div class="copy">
          <p class="eyebrow">Uma nova experiência está sendo preparada</p>
          <h1 id="ga-maintenance-title">Estamos renovando nossa <span>presença digital.</span></h1>
          <p class="lead">Estamos reconstruindo nosso espaço digital para oferecer uma experiência mais clara, contemporânea e cuidadosa — com a mesma seriedade que orienta a atuação do escritório.</p>
          <div class="rule" aria-hidden="true"></div>
          <p class="note">Durante esta etapa, o atendimento do escritório continua disponível. Para contato, utilize nosso canal oficial abaixo. Evite enviar documentos sigilosos ou dados sensíveis no primeiro contato.</p>
          <div class="actions">
            <?php if ($wa_url): ?><a class="cta cta-wa" href="<?php echo esc_url($wa_url); ?>" target="_blank" rel="noopener noreferrer"><span>Falar pelo WhatsApp</span><span class="arrow" aria-hidden="true">↗</span></a><?php endif; ?>
            <?php $contact_email = sanitize_email((string)($s['email'] ?? '')); if ($contact_email && is_email($contact_email)): ?><a class="cta cta-secondary" href="<?php echo esc_url('mailto:' . $contact_email); ?>">Contato por e-mail <span class="arrow" aria-hidden="true">↗</span></a><?php endif; ?>
          </div>
        </div>
        <div class="photo"><img src="<?php echo esc_url($image); ?>" alt="Balança da justiça em ambiente de escritório, em tons de bronze e grafite" width="1600" height="900"><div class="photo-label">Sobriedade · estratégia · confiança</div></div>
      </section>
      <footer class="foot"><span>© <?php echo esc_html(wp_date('Y')); ?> Garibalde Amaral Advogados Associados<br>Informação institucional e canais oficiais de atendimento.</span>
      <?php $has_social = false; foreach ($socials as $key=>$meta) { if (!empty($s[$key]) && wp_http_validate_url($s[$key])) { $has_social = true; break; } } if ($has_social): ?><nav class="socials" aria-label="Redes sociais oficiais"><?php foreach ($socials as $key=>$meta): if (!empty($s[$key]) && wp_http_validate_url($s[$key])): ?><a href="<?php echo esc_url($s[$key]); ?>" target="_blank" rel="noopener noreferrer" aria-label="Abrir perfil oficial no <?php echo esc_attr($meta[0]); ?>"><?php echo esc_html($meta[1]); ?></a><?php endif; endforeach; ?></nav><?php endif; ?></footer>
    </main></body></html><?php
}
