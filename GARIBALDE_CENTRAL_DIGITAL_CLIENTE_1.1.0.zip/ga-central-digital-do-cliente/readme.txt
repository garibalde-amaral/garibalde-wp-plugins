=== Garibalde Amaral — Central Digital do Cliente ===
Contributors: garibaldeamaral
Tags: atendimento, central do cliente, formulário, documentos privados
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPL-2.0-or-later

Cria a página Central Digital do Cliente, inclui modelos de procuração e declaração de hipossuficiência para download, formulário de triagem inicial, ditado por voz quando compatível e envio opcional de até três arquivos para armazenamento privado fora do diretório público, quando o servidor permitir validar esse armazenamento.

== Instalação ==
1. Faça backup restaurável dos arquivos e do banco de dados do WordPress.
2. Em Plugins > Adicionar novo > Enviar plugin, envie o ZIP deste plugin.
3. Ative o plugin. Ele cria a página /central-digital-do-cliente/ se o slug estiver livre e tenta incluir um link em localizações de menu identificadas como principal/cabeçalho. Se já houver página com esse slug sem o shortcode, o plugin preserva o conteúdo e mostra aviso para revisão manual.
4. Abra Central Digital > Configurações e configure o aviso de privacidade e o e-mail que receberá apenas alertas sem dados do cliente.
5. Confirme o estado de armazenamento privado. Se não for validado como fora do diretório público, o envio de arquivos fica desabilitado.
6. Teste em computador e celular: página, download dos quatro modelos, ditado, envio sem anexos, envio com arquivos pequenos, recebimento do alerta e download administrativo dos arquivos.
7. Confirme que mensagens gerais de atendimento apontam para a Central Digital — nunca para Consulta Processual. O diagnóstico informa se a página contém o shortcode, mas a abertura pública, o menu e os downloads ainda precisam ser testados no tema em uso.

== Segurança e privacidade ==
* A triagem armazena nome, telefone, e-mail, área selecionada, resumo e consentimento.
* Não armazena o endereço IP em texto claro; usa hash de curta duração para limitar envios repetidos.
* Os anexos são limitados a até três arquivos, cinco MB por arquivo e seis MB no total, e só são aceitos após validação de tipo e armazenamento privado. PDF e imagens exigem PHP fileinfo. DOCX exige também PHP ZipArchive para conferir a estrutura interna. A lista de formatos da página se ajusta às extensões presentes.
* Os anexos ficam disponíveis para download somente a administradores autenticados com capacidade manage_options e nonce válido.
* A mensagem por e-mail não inclui relato, dados de contato nem arquivos.
* A exclusão de uma solicitação remove os respectivos anexos. A versão ainda não faz expurgo automático: o escritório deve definir e executar uma política de retenção.
* O plugin não inclui varredura antimalware dos arquivos; a equipe deve manter proteção do servidor e tratar todos os anexos com cautela.

== Limitações conhecidas ==
* Não gera procuração ou declaração automaticamente preenchida a partir dos dados do cliente; disponibiliza modelos editáveis para download.
* Não inclui assinatura eletrônica, acompanhamento público por protocolo, CRM, motor de IA ou integração de mensagens recebidas do WhatsApp.
* A página não substitui a página Consulta Processual, que continua destinada exclusivamente à consulta de processos.
* Antes de produção, confirmar o aviso de privacidade, retenção, extensões PHP, limite de upload configurado na hospedagem e teste do comportamento do tema/menu.
