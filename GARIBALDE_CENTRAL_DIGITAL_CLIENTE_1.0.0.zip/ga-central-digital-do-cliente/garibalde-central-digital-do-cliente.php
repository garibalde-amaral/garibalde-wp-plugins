<?php
/**
 * Plugin Name: Garibalde Amaral — Central Digital do Cliente
 * Description: Cria a página Central Digital do Cliente, acrescenta o acesso ao menu principal quando detectável e recebe solicitações iniciais em painel restrito.
 * Version: 1.0.0
 * Author: Garibalde Amaral Advogados Associados
 * Requires at least: 6.2
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) { exit; }

final class GA_Central_Digital_Cliente {
    const VERSION = '1.0.0';
    const PAGE_SLUG = 'central-digital-do-cliente';
    const TABLE_SUFFIX = 'ga_cdc_intakes';
    const OPTION_PRIVACY_URL = 'ga_cdc_privacy_url';
    const OPTION_NOTIFY_EMAIL = 'ga_cdc_notify_email';

    public static function init() {
        add_shortcode('ga_central_digital', [__CLASS__, 'render_shortcode']);
        add_action('admin_menu', [__CLASS__, 'admin_menu']);
        add_action('admin_init', [__CLASS__, 'register_settings']);
        add_action('admin_post_nopriv_ga_cdc_submit', [__CLASS__, 'handle_submit']);
        add_action('admin_post_ga_cdc_submit', [__CLASS__, 'handle_submit']);
        add_action('admin_post_ga_cdc_delete', [__CLASS__, 'handle_delete']);
        add_filter('wp_nav_menu_items', [__CLASS__, 'append_menu_link'], 20, 2);
        add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
    }

    public static function activate() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = $wpdb->prefix . self::TABLE_SUFFIX;
        $charset = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            created_at datetime NOT NULL,
            full_name varchar(180) NOT NULL,
            phone varchar(40) NOT NULL,
            email varchar(190) NOT NULL,
            area varchar(80) NOT NULL,
            summary text NOT NULL,
            consent_at datetime NOT NULL,
            status varchar(24) NOT NULL DEFAULT 'novo',
            PRIMARY KEY  (id),
            KEY created_at (created_at),
            KEY status (status)
        ) {$charset};";
        dbDelta($sql);

        $existing = get_page_by_path(self::PAGE_SLUG, OBJECT, 'page');
        if (!$existing) {
            wp_insert_post([
                'post_title'   => 'Central Digital do Cliente',
                'post_name'    => self::PAGE_SLUG,
                'post_type'    => 'page',
                'post_status'  => 'publish',
                'post_content' => '[ga_central_digital]',
                'post_excerpt' => 'Atendimento inicial e encaminhamento digital da Garibalde Amaral Advogados Associados.',
            ], true);
        }

        if (!get_option(self::OPTION_NOTIFY_EMAIL)) {
            update_option(self::OPTION_NOTIFY_EMAIL, get_option('admin_email'));
        }
        flush_rewrite_rules();
    }

    public static function deactivate() {
        flush_rewrite_rules();
    }

    public static function enqueue_assets() {
        if (!is_page(self::PAGE_SLUG)) { return; }
        wp_register_style('ga-cdc-inline', false, [], self::VERSION);
        wp_enqueue_style('ga-cdc-inline');
        wp_add_inline_style('ga-cdc-inline', self::css());
        wp_register_script('ga-cdc-inline', false, [], self::VERSION, true);
        wp_enqueue_script('ga-cdc-inline');
        wp_add_inline_script('ga-cdc-inline', self::js());
    }

    private static function page_url() {
        $page = get_page_by_path(self::PAGE_SLUG, OBJECT, 'page');
        if ($page && !empty($page->ID)) {
            $permalink = get_permalink($page->ID);
            if ($permalink) { return $permalink; }
        }
        return home_url('/' . self::PAGE_SLUG . '/');
    }

    private static function css() {
        return '
        .ga-cdc{--ga-navy:#0b2138;--ga-blue:#164663;--ga-gold:#b99a5b;--ga-ink:#1c2733;--ga-muted:#5f6b77;--ga-line:#dce3e8;max-width:1160px;margin:0 auto;padding:clamp(20px,4vw,52px) 18px;color:var(--ga-ink);font-family:inherit}
        .ga-cdc *{box-sizing:border-box}.ga-cdc-hero{background:linear-gradient(125deg,#0b2138 0%,#143e59 72%,#1c5868 100%);border-radius:22px;padding:clamp(28px,5vw,62px);color:#fff;position:relative;overflow:hidden}
        .ga-cdc-kicker{font-size:.78rem;letter-spacing:.14em;text-transform:uppercase;color:#e8d6ad;font-weight:700;margin:0 0 14px}.ga-cdc h1{color:#fff;font-size:clamp(2rem,5vw,3.4rem);line-height:1.08;max-width:760px;margin:0 0 18px;letter-spacing:-.025em}.ga-cdc-hero p{max-width:760px;color:#e7edf2;font-size:1.08rem;line-height:1.7;margin:0}
        .ga-cdc-security{display:flex;gap:10px;align-items:flex-start;margin-top:24px;font-size:.92rem;color:#f5f1e8}.ga-cdc-security svg{flex:none;margin-top:2px}.ga-cdc-section-title{font-size:clamp(1.45rem,3vw,2rem);color:var(--ga-navy);margin:38px 0 8px;letter-spacing:-.02em}.ga-cdc-intro{color:var(--ga-muted);line-height:1.65;margin:0 0 22px;max-width:800px}
        .ga-cdc-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.ga-cdc-card{border:1px solid var(--ga-line);border-radius:16px;padding:24px;background:#fff;box-shadow:0 6px 22px rgba(12,34,54,.05)}.ga-cdc-card h3{margin:0 0 10px;font-size:1.12rem;color:var(--ga-navy)}.ga-cdc-card p{margin:0;color:var(--ga-muted);line-height:1.6;font-size:.96rem}.ga-cdc-icon{height:42px;width:42px;border-radius:12px;background:#eef3f5;color:var(--ga-blue);display:flex;align-items:center;justify-content:center;margin-bottom:18px;font-size:1.25rem}
        .ga-cdc-form-wrap{margin-top:22px;border:1px solid var(--ga-line);border-radius:18px;padding:clamp(20px,4vw,34px);background:#f8fafb}.ga-cdc-form-wrap h2{margin:0 0 8px;color:var(--ga-navy);font-size:1.55rem}.ga-cdc-form-intro{color:var(--ga-muted);line-height:1.6;margin:0 0 24px}.ga-cdc-form{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.ga-cdc-field{display:flex;flex-direction:column;gap:7px}.ga-cdc-field-full{grid-column:1/-1}.ga-cdc-field label{font-weight:650;color:#263747;font-size:.94rem}.ga-cdc input[type=text],.ga-cdc input[type=email],.ga-cdc input[type=tel],.ga-cdc select,.ga-cdc textarea{width:100%;padding:13px 14px;border:1px solid #c7d2db;border-radius:10px;background:#fff;color:#1c2733;font:inherit;min-height:48px}.ga-cdc textarea{min-height:150px;resize:vertical}.ga-cdc input:focus,.ga-cdc select:focus,.ga-cdc textarea:focus{outline:3px solid rgba(22,70,99,.17);border-color:var(--ga-blue)}.ga-cdc-help{font-size:.82rem;color:var(--ga-muted);line-height:1.5}.ga-cdc-consent{display:flex;gap:10px;align-items:flex-start;line-height:1.55;font-size:.9rem;color:#3d4a55}.ga-cdc-consent input{margin-top:5px;flex:none}.ga-cdc-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;border:0;border-radius:999px;background:var(--ga-gold);color:#132436;padding:14px 23px;min-height:48px;font-weight:750;text-decoration:none;cursor:pointer;line-height:1.2}.ga-cdc-btn:hover{filter:brightness(.96);color:#132436}.ga-cdc-btn:focus{outline:3px solid rgba(22,70,99,.22);outline-offset:3px}.ga-cdc-btn-secondary{background:#fff;border:1px solid #c7d2db;color:var(--ga-navy)}.ga-cdc-actions{display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin-top:20px}.ga-cdc-status{padding:15px 17px;border-radius:12px;background:#e9f4ee;border:1px solid #b8d8c5;color:#174c2c;margin:0 0 22px;line-height:1.55}.ga-cdc-notice{padding:16px 18px;border-left:4px solid var(--ga-gold);background:#f7f4ed;color:#354451;border-radius:0 10px 10px 0;line-height:1.6;margin:22px 0}.ga-cdc-voice{margin-top:9px}.ga-cdc-footer-note{font-size:.84rem;color:var(--ga-muted);line-height:1.6;margin:24px 0 0}.ga-cdc-hp{position:absolute!important;left:-9999px!important;width:1px!important;height:1px!important;overflow:hidden!important}.ga-cdc-small-link{color:#244f6b;text-decoration:underline;text-underline-offset:3px}
        @media(max-width:800px){.ga-cdc-grid{grid-template-columns:1fr}.ga-cdc-form{grid-template-columns:1fr}.ga-cdc-field-full{grid-column:auto}.ga-cdc-hero{border-radius:16px}.ga-cdc-card{padding:20px}.ga-cdc-actions{align-items:stretch;flex-direction:column}.ga-cdc-btn{width:100%;text-align:center}}
        @media(prefers-reduced-motion:reduce){.ga-cdc *{scroll-behavior:auto!important;transition:none!important;animation:none!important}}
        ';
    }

    private static function js() {
        return "(function(){function ready(fn){if(document.readyState!=='loading'){fn()}else{document.addEventListener('DOMContentLoaded',fn)}}ready(function(){var btn=document.querySelector('[data-ga-cdc-voice]');var ta=document.getElementById('ga-cdc-summary');var status=document.getElementById('ga-cdc-voice-status');if(!btn||!ta)return;var SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){btn.disabled=true;btn.setAttribute('aria-disabled','true');if(status)status.textContent='Ditado por voz não é compatível com este navegador. Você pode digitar normalmente.';return;}btn.addEventListener('click',function(){var rec=new SR();rec.lang='pt-BR';rec.interimResults=false;rec.maxAlternatives=1;btn.disabled=true;if(status)status.textContent='Ouvindo… fale agora.';rec.onresult=function(e){var t=e.results&&e.results[0]&&e.results[0][0]?e.results[0][0].transcript:'';if(t){ta.value=(ta.value?ta.value+' ':'')+t;ta.dispatchEvent(new Event('input',{bubbles:true}));}if(status)status.textContent='Texto reconhecido. Revise antes de enviar; o áudio não é armazenado por esta página.';};rec.onerror=function(){if(status)status.textContent='Não foi possível reconhecer a fala. Digite o relato ou tente novamente.';};rec.onend=function(){btn.disabled=false;};try{rec.start();}catch(err){btn.disabled=false;if(status)status.textContent='Não foi possível iniciar o ditado neste momento.';}});});})();";
    }

    public static function render_shortcode() {
        $privacy_url = esc_url(get_option(self::OPTION_PRIVACY_URL, ''));
        $status = isset($_GET['ga_cdc_status']) ? sanitize_key(wp_unslash($_GET['ga_cdc_status'])) : '';
        ob_start(); ?>
        <main class="ga-cdc">
          <section class="ga-cdc-hero" aria-labelledby="ga-cdc-title">
            <p class="ga-cdc-kicker">Garibalde Amaral Advogados Associados</p>
            <h1 id="ga-cdc-title">Central Digital do Cliente</h1>
            <p>Um ponto de entrada organizado para iniciar contato com o escritório. Informe apenas o necessário para que a equipe compreenda o assunto e identifique o próximo passo.</p>
            <div class="ga-cdc-security"><span aria-hidden="true">◆</span><span>Este canal recolhe somente os dados iniciais de contato e uma descrição breve. Não envie documentos, senhas, dados bancários ou informações de terceiros nesta etapa.</span></div>
          </section>

          <?php if ($status === 'recebido') : ?>
            <div class="ga-cdc-status" role="status"><strong>Solicitação recebida.</strong> A equipe poderá entrar em contato pelos dados informados. O envio deste formulário não significa contratação, não confirma conflito de interesses e não equivale à conclusão de uma análise jurídica.</div>
          <?php elseif ($status === 'erro') : ?>
            <div class="ga-cdc-notice" role="alert"><strong>Não foi possível enviar.</strong> Confira os campos obrigatórios e tente novamente. Se o problema persistir, use o canal de contato assistido do escritório.</div>
          <?php endif; ?>

          <h2 class="ga-cdc-section-title">Comece por aqui</h2>
          <p class="ga-cdc-intro">Preencha o formulário inicial. A página de consulta processual é uma ferramenta diferente e não é o destino deste atendimento.</p>
          <div class="ga-cdc-grid" aria-label="Etapas do atendimento">
            <article class="ga-cdc-card"><div class="ga-cdc-icon" aria-hidden="true">01</div><h3>Identifique o assunto</h3><p>Selecione a área aproximada e informe como o escritório pode retornar.</p></article>
            <article class="ga-cdc-card"><div class="ga-cdc-icon" aria-hidden="true">02</div><h3>Descreva o essencial</h3><p>Use texto ou ditado por voz. Revise nomes, datas e o conteúdo antes de enviar.</p></article>
            <article class="ga-cdc-card"><div class="ga-cdc-icon" aria-hidden="true">03</div><h3>Aguarde o encaminhamento</h3><p>A equipe fará a triagem inicial e orientará o próximo passo. Nenhuma contratação é automática.</p></article>
          </div>

          <section class="ga-cdc-form-wrap" aria-labelledby="ga-cdc-form-title">
            <h2 id="ga-cdc-form-title">Iniciar atendimento</h2>
            <p class="ga-cdc-form-intro">Campos com * são obrigatórios. Não inclua número completo de processo, CPF, dados médicos, bancários ou outros dados sensíveis no relato inicial.</p>
            <form class="ga-cdc-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
              <input type="hidden" name="action" value="ga_cdc_submit">
              <?php wp_nonce_field('ga_cdc_submit', 'ga_cdc_nonce'); ?>
              <div class="ga-cdc-hp" aria-hidden="true"><label>Deixe vazio <input type="text" name="company_website" tabindex="-1" autocomplete="off"></label></div>
              <div class="ga-cdc-field"><label for="ga-cdc-name">Nome completo *</label><input id="ga-cdc-name" name="full_name" type="text" maxlength="180" autocomplete="name" required></div>
              <div class="ga-cdc-field"><label for="ga-cdc-phone">Telefone com DDD *</label><input id="ga-cdc-phone" name="phone" type="tel" maxlength="40" autocomplete="tel" required></div>
              <div class="ga-cdc-field"><label for="ga-cdc-email">E-mail *</label><input id="ga-cdc-email" name="email" type="email" maxlength="190" autocomplete="email" required></div>
              <div class="ga-cdc-field"><label for="ga-cdc-area">Assunto principal *</label><select id="ga-cdc-area" name="area" required><option value="">Selecione</option><option>Trabalhista</option><option>Cível e contratos</option><option>Consumidor</option><option>Família e sucessões</option><option>Previdenciário</option><option>Imobiliário</option><option>Empresarial</option><option>Administrativo</option><option>Outro / não sei identificar</option></select></div>
              <div class="ga-cdc-field ga-cdc-field-full"><label for="ga-cdc-summary">Resumo inicial (sem documentos ou dados sensíveis)</label><textarea id="ga-cdc-summary" name="summary" maxlength="3000" placeholder="Em poucas linhas, informe o assunto e o que precisa esclarecer."></textarea><div class="ga-cdc-actions ga-cdc-voice"><button class="ga-cdc-btn ga-cdc-btn-secondary" type="button" data-ga-cdc-voice>Ditado por voz</button><span class="ga-cdc-help" id="ga-cdc-voice-status" aria-live="polite">Se compatível com o navegador, a fala será convertida em texto no próprio dispositivo. O áudio não será enviado.</span></div></div>
              <div class="ga-cdc-field ga-cdc-field-full"><label class="ga-cdc-consent"><input type="checkbox" name="consent" value="1" required><span>Autorizo o uso dos dados acima para retorno e triagem inicial pelo escritório. Entendo que o formulário não cria, por si só, relação contratual nem garante aceitação do caso. <?php if ($privacy_url) : ?><a class="ga-cdc-small-link" href="<?php echo $privacy_url; ?>" target="_blank" rel="noopener">Ler aviso de privacidade</a><?php endif; ?></span></label></div>
              <div class="ga-cdc-field ga-cdc-field-full"><button class="ga-cdc-btn" type="submit">Enviar solicitação inicial <span aria-hidden="true">→</span></button><span class="ga-cdc-help">Envio de documentos e geração automatizada de procuração/declaração ainda dependem da configuração e dos testes do módulo seguro; não use este formulário para anexar arquivos.</span></div>
            </form>
          </section>
          <div class="ga-cdc-notice"><strong>Importante:</strong> a equipe poderá solicitar documentos e confirmações por um canal apropriado após a triagem. Não publique informações pessoais em comentários de redes sociais.</div>
          <p class="ga-cdc-footer-note">A Central Digital é independente da página “Consulta Processual”. O formulário registra apenas dados de contato e triagem inicial; não realiza análise jurídica automática.</p>
        </main>
        <?php return ob_get_clean();
    }

    public static function handle_submit() {
        if (!isset($_POST['ga_cdc_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['ga_cdc_nonce'])), 'ga_cdc_submit')) {
            self::redirect_status('erro');
        }
        if (!empty($_POST['company_website'])) {
            self::redirect_status('recebido');
        }
        $name = isset($_POST['full_name']) ? sanitize_text_field(wp_unslash($_POST['full_name'])) : '';
        $phone = isset($_POST['phone']) ? sanitize_text_field(wp_unslash($_POST['phone'])) : '';
        $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
        $area = isset($_POST['area']) ? sanitize_text_field(wp_unslash($_POST['area'])) : '';
        $summary = isset($_POST['summary']) ? sanitize_textarea_field(wp_unslash($_POST['summary'])) : '';
        $consent = isset($_POST['consent']) && (string) wp_unslash($_POST['consent']) === '1';
        $allowed_areas = ['Trabalhista','Cível e contratos','Consumidor','Família e sucessões','Previdenciário','Imobiliário','Empresarial','Administrativo','Outro / não sei identificar'];
        if (!$name || !$phone || !$email || !is_email($email) || !in_array($area, $allowed_areas, true) || !$consent || strlen($summary) > 3000) {
            self::redirect_status('erro');
        }
        // Rate limit with a short-lived hash; no raw IP is stored in the database.
        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown';
        $rate_key = 'ga_cdc_rate_' . substr(hash_hmac('sha256', $ip, wp_salt('nonce')), 0, 32);
        if (get_transient($rate_key)) { self::redirect_status('erro'); }
        set_transient($rate_key, 1, 60);

        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;
        $now = current_time('mysql');
        $inserted = $wpdb->insert($table, [
            'created_at' => $now,
            'full_name' => $name,
            'phone' => $phone,
            'email' => $email,
            'area' => $area,
            'summary' => $summary,
            'consent_at' => $now,
            'status' => 'novo',
        ], ['%s','%s','%s','%s','%s','%s','%s','%s']);
        if (!$inserted) { self::redirect_status('erro'); }
        $id = (int) $wpdb->insert_id;
        $to = sanitize_email(get_option(self::OPTION_NOTIFY_EMAIL, get_option('admin_email')));
        if ($to && is_email($to)) {
            $subject = sprintf('Nova solicitação na Central Digital — registro #%d', $id);
            $body = "Uma solicitação inicial foi recebida.\n\nRegistro: #{$id}\nÁrea: {$area}\nData: {$now}\n\nPor privacidade, o relato e os dados de contato não foram incluídos neste e-mail. Entre no WordPress e acesse Central Digital do Cliente > Solicitações.";
            wp_mail($to, $subject, $body);
        }
        self::redirect_status('recebido');
    }

    private static function redirect_status($status) {
        $referer = wp_get_referer();
        $url = $referer ? $referer : self::page_url();
        $url = remove_query_arg(['ga_cdc_status'], $url);
        wp_safe_redirect(add_query_arg('ga_cdc_status', sanitize_key($status), $url));
        exit;
    }

    public static function admin_menu() {
        add_menu_page('Solicitações da Central Digital', 'Central Digital', 'manage_options', 'ga-cdc', [__CLASS__, 'render_admin_page'], 'dashicons-id-alt', 26);
        add_submenu_page('ga-cdc', 'Configurações', 'Configurações', 'manage_options', 'ga-cdc-settings', [__CLASS__, 'render_settings_page']);
    }

    public static function register_settings() {
        register_setting('ga_cdc_settings', self::OPTION_PRIVACY_URL, ['type'=>'string','sanitize_callback'=>'esc_url_raw','default'=>'']);
        register_setting('ga_cdc_settings', self::OPTION_NOTIFY_EMAIL, ['type'=>'string','sanitize_callback'=>'sanitize_email','default'=>get_option('admin_email')]);
    }

    public static function render_settings_page() {
        if (!current_user_can('manage_options')) { return; } ?>
        <div class="wrap"><h1>Central Digital do Cliente — Configurações</h1><p>Configure o aviso de privacidade e o e-mail que recebe apenas o alerta de nova solicitação. O conteúdo do caso não é enviado no e-mail.</p>
          <form method="post" action="options.php"><?php settings_fields('ga_cdc_settings'); ?>
            <table class="form-table" role="presentation"><tr><th scope="row"><label for="ga-cdc-privacy-url">URL do aviso de privacidade</label></th><td><input class="regular-text" type="url" id="ga-cdc-privacy-url" name="<?php echo esc_attr(self::OPTION_PRIVACY_URL); ?>" value="<?php echo esc_attr(get_option(self::OPTION_PRIVACY_URL, '')); ?>"><p class="description">Deixe em branco até existir uma página de privacidade conferida.</p></td></tr>
            <tr><th scope="row"><label for="ga-cdc-notify-email">E-mail de alerta</label></th><td><input class="regular-text" type="email" id="ga-cdc-notify-email" name="<?php echo esc_attr(self::OPTION_NOTIFY_EMAIL); ?>" value="<?php echo esc_attr(get_option(self::OPTION_NOTIFY_EMAIL, get_option('admin_email'))); ?>" required><p class="description">O e-mail contém apenas o número do registro e a área, sem o relato do cliente.</p></td></tr></table>
            <?php submit_button('Salvar configurações'); ?>
          </form><hr><p><strong>Estado desta versão:</strong> formulário de triagem inicial ativo. Upload seguro de documentos, downloads dos modelos oficiais, assinatura eletrônica e procuração automatizada não estão incluídos nesta versão e devem ser implantados após desenvolvimento e testes específicos.</p></div>
        <?php
    }

    public static function render_admin_page() {
        if (!current_user_can('manage_options')) { wp_die('Acesso não autorizado.'); }
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_SUFFIX;
        $rows = $wpdb->get_results("SELECT id, created_at, full_name, phone, email, area, summary, consent_at, status FROM {$table} ORDER BY id DESC LIMIT 100");
        echo '<div class="wrap"><h1>Central Digital do Cliente — Solicitações</h1><p>Dados acessíveis somente a administradores com permissão <code>manage_options</code>. Não encaminhe o conteúdo por e-mail; use o painel e observe o sigilo profissional.</p>';
        if (!$rows) { echo '<p>Nenhuma solicitação recebida.</p></div>'; return; }
        echo '<table class="widefat striped"><thead><tr><th>ID / Data</th><th>Contato</th><th>Área</th><th>Resumo inicial</th><th>Consentimento</th><th>Ação</th></tr></thead><tbody>';
        foreach ($rows as $row) {
            echo '<tr><td>#' . (int)$row->id . '<br>' . esc_html($row->created_at) . '<br><strong>' . esc_html($row->status) . '</strong></td>';
            echo '<td><strong>' . esc_html($row->full_name) . '</strong><br>' . esc_html($row->phone) . '<br><a href="mailto:' . esc_attr($row->email) . '">' . esc_html($row->email) . '</a></td>';
            echo '<td>' . esc_html($row->area) . '</td><td style="min-width:220px;max-width:420px;white-space:pre-wrap">' . esc_html($row->summary) . '</td><td>' . esc_html($row->consent_at) . '</td><td><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" onsubmit="return confirm(\'Excluir permanentemente este registro?\')">';
            echo '<input type="hidden" name="action" value="ga_cdc_delete"><input type="hidden" name="id" value="' . (int)$row->id . '">';
            wp_nonce_field('ga_cdc_delete_' . (int)$row->id, 'ga_cdc_delete_nonce');
            echo '<button type="submit" class="button button-secondary">Excluir</button></form></td></tr>';
        }
        echo '</tbody></table><p class="description">A listagem mostra os 100 registros mais recentes. Esta versão não inclui política automática de descarte; o escritório precisa definir e cumprir um prazo de retenção.</p></div>';
    }

    public static function handle_delete() {
        if (!current_user_can('manage_options')) { wp_die('Acesso não autorizado.'); }
        $id = isset($_POST['id']) ? absint($_POST['id']) : 0;
        $nonce = isset($_POST['ga_cdc_delete_nonce']) ? sanitize_text_field(wp_unslash($_POST['ga_cdc_delete_nonce'])) : '';
        if (!$id || !wp_verify_nonce($nonce, 'ga_cdc_delete_' . $id)) { wp_die('Validação de segurança falhou.'); }
        global $wpdb;
        $wpdb->delete($wpdb->prefix . self::TABLE_SUFFIX, ['id'=>$id], ['%d']);
        wp_safe_redirect(admin_url('admin.php?page=ga-cdc&deleted=1'));
        exit;
    }

    public static function append_menu_link($items, $args) {
        if (!is_object($args) || empty($args->theme_location)) { return $items; }
        $location = strtolower((string)$args->theme_location);
        $is_header = (strpos($location, 'primary') !== false || strpos($location, 'main') !== false || strpos($location, 'header') !== false || strpos($location, 'top') !== false || strpos($location, 'navigation') !== false);
        if (!$is_header || strpos($location, 'footer') !== false) { return $items; }
        $url = self::page_url();
        if (strpos($items, esc_url($url)) !== false || strpos($items, 'menu-item-ga-central-digital') !== false) { return $items; }
        $label = '<span class="ga-cdc-menu-label">Central Digital do Cliente</span>';
        return $items . '<li class="menu-item menu-item-ga-central-digital"><a href="' . esc_url($url) . '">' . $label . '</a></li>';
    }
}

GA_Central_Digital_Cliente::init();
register_activation_hook(__FILE__, ['GA_Central_Digital_Cliente', 'activate']);
register_deactivation_hook(__FILE__, ['GA_Central_Digital_Cliente', 'deactivate']);
