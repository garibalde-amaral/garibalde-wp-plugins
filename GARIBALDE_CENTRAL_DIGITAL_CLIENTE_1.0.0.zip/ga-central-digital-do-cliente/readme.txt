=== Garibalde Amaral — Central Digital do Cliente ===
Contributors: garibalde-amaral
Tags: atendimento, formulário, central digital
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 1.0.0

Cria a página /central-digital-do-cliente/, acrescenta link ao menu principal quando identifica uma localização de cabeçalho e registra solicitações iniciais num painel restrito.

INSTALAÇÃO
1. Faça e confirme backup restaurável de arquivos e banco de dados antes de alterar o site.
2. No WordPress, Plugins > Adicionar novo > Enviar plugin, carregue o ZIP e ative.
3. Abra https://SEU-DOMINIO/central-digital-do-cliente/ e teste o formulário com dados fictícios.
4. No painel, abra Central Digital > Configurações; configure o aviso de privacidade e o e-mail de alerta.
5. Teste recepção, notificação, proteção do painel, exclusão de solicitação e apresentação em celular.
6. Confira se o tema usa uma localização de menu contendo primary, main, header, top ou navigation. Se não usar, acrescente o link manualmente ao menu principal do WordPress.

ESCOPO 1.0.0
- Página central distinta da página Consulta Processual.
- Formulário de contato e triagem inicial, com resumo breve e consentimento.
- Ditado por voz no navegador quando suportado; o áudio não é enviado nem armazenado.
- Registros guardados na tabela do WordPress; acessíveis pela permissão manage_options.
- E-mail de alerta sem incluir o relato ou dados de contato.
- Excluir solicitação no painel.

NÃO INCLUÍDO
- Upload seguro de documentos, downloads dos modelos oficiais, procuração/hipossuficiência automática, assinatura eletrônica, CRM, WhatsApp Cloud API, n8n ou protocolo ao cliente. Não anuncie essas funções como disponíveis até serem implementadas e testadas.

SEGURANÇA E PRIVACIDADE
Esta versão é um MVP de triagem, não uma plataforma completa de gestão de documentos jurídicos. O escritório deve configurar o aviso de privacidade, revisar a retenção de dados, proteger as contas administrativas, verificar SMTP, realizar testes no ambiente real e validar a política de tratamento de dados antes da divulgação ampla. Não solicite que o usuário envie documentos, senhas, dados bancários ou dados sensíveis nesta etapa.
