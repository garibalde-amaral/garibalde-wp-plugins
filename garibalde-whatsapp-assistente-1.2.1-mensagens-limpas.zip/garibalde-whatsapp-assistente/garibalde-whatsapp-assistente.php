<?php
/**
 * Plugin Name: Garibalde Amaral — WhatsApp de Atendimento Inicial
 * Description: Botão de WhatsApp acessível, com triagem por assunto e mensagem pré-preenchida. Não envia mensagens automaticamente nem coleta dados do visitante.
 * Version: 1.2.1
 * Author: Garibalde Amaral Advogados Associados
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 * Text Domain: garibalde-whatsapp-assistente
 */

if (!defined('ABSPATH')) {
    exit;
}

final class Garibalde_WhatsApp_Assistente {
    const OPTION = 'ga_wa_assistente_options';

    public static function defaults() {
        return array(
            'phone' => '5562991340228',
            'button_label' => 'Falar com o escritório',
            'panel_title' => 'Como podemos ajudar você hoje?',
            'welcome' => 'Olá! Que bom receber seu contato. Sou o assistente digital de atendimento inicial da Garibalde Amaral Advogados Associados e vou ajudar a encaminhar sua mensagem para a equipe certa. Escolha a opção que mais se aproxima do que você precisa. Se preferir, quando o WhatsApp abrir, pode explicar o assunto com suas próprias palavras. A equipe do escritório dará continuidade quando for necessário.',
            'privacy_note' => 'Para sua segurança, não envie agora senhas, dados bancários, laudos médicos ou documentos completos de processos. Se houver prazo judicial, audiência ou outra urgência, selecione a opção correspondente e aguarde confirmação expressa da equipe. Esta mensagem inicial não confirma contratação nem assunção de prazo pelo escritório.',
            'topics' => self::default_topics(),
            'enabled' => 1,
        );
    }

    public static function settings() {
        $saved = get_option(self::OPTION, array());
        if (!is_array($saved)) {
            $saved = array();
        }
        $defaults = self::defaults();
        $settings = wp_parse_args($saved, $defaults);

        // Upgrade only old stock wording; preserve any text intentionally customized by the office.
        $previous_defaults = array(
            'button_label' => 'WhatsApp do escritório',
            'panel_title' => 'Como podemos direcionar seu atendimento?',
            'welcome' => 'Olá! Sou o assistente virtual de triagem da Garibalde Amaral Advogados Associados. Vou ajudar a encaminhar seu primeiro contato. Escolha o assunto mais próximo do que precisa; a análise jurídica, quando necessária, será feita pela equipe responsável.',
            'privacy_note' => 'Para sua proteção, não envie senhas, dados bancários, laudos médicos ou documentos do processo neste primeiro contato. A equipe orientará o canal adequado. Se houver prazo ou audiência iminente, não dependa apenas de uma resposta automatizada.',
        );
        foreach ($previous_defaults as $key => $old_value) {
            if (isset($saved[$key]) && $saved[$key] === $old_value) {
                $settings[$key] = $defaults[$key];
            }
        }
        // Migrate only exact legacy default messages that generated duplicate greetings.
        $legacy = array(
            'novo' => 'Olá! Vim pelo site da Garibalde Amaral Advogados Associados. Gostaria de saber se o escritório pode me orientar sobre o tipo de assunto que preciso tratar. Qual é o próximo passo?',
            'empresarial' => 'Olá! Meu assunto envolve empresa, contrato ou questão tributária. Gostaria de saber qual é a forma adequada de apresentar o assunto para uma avaliação inicial.',
            'imovel' => 'Olá! Preciso de informações iniciais sobre um assunto relacionado a imóvel, área rural, condomínio ou regularização patrimonial. Como posso encaminhar isso corretamente?',
            'beneficio' => 'Olá! Gostaria de informações sobre um assunto relacionado a aposentadoria ou possível isenção de Imposto de Renda. Qual é o próximo passo? Não estou enviando documentos ou dados médicos neste primeiro contato.',
            'cliente' => 'Olá! Já sou cliente do escritório e preciso tratar de um assunto em andamento. Por segurança, gostaria de saber como devo me identificar e qual canal devo utilizar.',
            'urgente' => 'Olá! Tenho uma situação que pode envolver prazo, audiência ou outra urgência. Gostaria de solicitar orientação sobre o encaminhamento. Informarei a data aproximada quando a equipe indicar como prosseguir. Sei que esta mensagem não confirma que o escritório assumiu o caso ou o prazo.',
            'outro' => 'Olá! Tenho outro assunto ou uma dúvida institucional sobre a Garibalde Amaral Advogados Associados. Poderiam me orientar sobre o próximo passo?',
        );
        if (isset($settings['topics']) && is_array($settings['topics'])) {
            $clean_by_id = array();
            foreach ($defaults['topics'] as $topic) {
                $clean_by_id[$topic['id']] = $topic['message'];
            }
            foreach ($settings['topics'] as &$topic) {
                if (!is_array($topic) || empty($topic['id']) || !isset($legacy[$topic['id']])) {
                    continue;
                }
                if (isset($topic['message']) && $topic['message'] === $legacy[$topic['id']]) {
                    $topic['message'] = $clean_by_id[$topic['id']];
                }
            }
            unset($topic);
        }
        return $settings;
    }

    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'admin_menu'));
        add_action('admin_init', array(__CLASS__, 'register_settings'));
        add_action('wp_footer', array(__CLASS__, 'render_widget'), 99);
        add_shortcode('garibalde_whatsapp', array(__CLASS__, 'shortcode'));
    }

    public static function admin_menu() {
        add_options_page(
            'WhatsApp — Garibalde Amaral',
            'WhatsApp Garibalde',
            'manage_options',
            'ga-whatsapp-assistente',
            array(__CLASS__, 'settings_page')
        );
    }

    public static function register_settings() {
        register_setting(
            'ga_wa_assistente_group',
            self::OPTION,
            array('sanitize_callback' => array(__CLASS__, 'sanitize_settings'))
        );
    }

    public static function sanitize_settings($input) {
        $defaults = self::defaults();
        $input = is_array($input) ? $input : array();
        $out = array();

        $phone = isset($input['phone']) ? preg_replace('/\D+/', '', (string) $input['phone']) : $defaults['phone'];
        // E.164 digits only: keep a conservative length to prevent accidental arbitrary input.
        if (strlen($phone) < 12 || strlen($phone) > 15) {
            add_settings_error(self::OPTION, 'ga_wa_phone', 'Confira o telefone: inclua código do país e DDD, somente números (ex.: 5562991340228).');
            $phone = $defaults['phone'];
        }
        $out['phone'] = $phone;
        $out['button_label'] = isset($input['button_label']) ? sanitize_text_field($input['button_label']) : $defaults['button_label'];
        $out['panel_title'] = isset($input['panel_title']) ? sanitize_text_field($input['panel_title']) : $defaults['panel_title'];
        $out['welcome'] = isset($input['welcome']) ? sanitize_textarea_field($input['welcome']) : $defaults['welcome'];
        $out['privacy_note'] = isset($input['privacy_note']) ? sanitize_textarea_field($input['privacy_note']) : $defaults['privacy_note'];
        $incoming_topics = isset($input['topics']) && is_array($input['topics']) ? $input['topics'] : array();
        $out['topics'] = array();
        foreach (self::default_topics() as $topic) {
            $id = $topic['id'];
            $candidate = isset($incoming_topics[$id]) && is_array($incoming_topics[$id]) ? $incoming_topics[$id] : array();
            $label = isset($candidate['label']) ? sanitize_text_field($candidate['label']) : $topic['label'];
            $message = isset($candidate['message']) ? sanitize_textarea_field($candidate['message']) : $topic['message'];
            $out['topics'][] = array('id' => $id, 'label' => $label !== '' ? $label : $topic['label'], 'message' => $message !== '' ? $message : $topic['message']);
        }
        $out['enabled'] = isset($input['enabled']) && (string) $input['enabled'] === '1' ? 1 : 0;
        return $out;
    }

    public static function settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $s = self::settings();
        ?>
        <div class="wrap">
            <h1>WhatsApp — Garibalde Amaral Advogados Associados</h1>
            <p>Este módulo apresenta um painel de triagem com linguagem natural e abre o WhatsApp com uma mensagem preparada. Ele <strong>não lê nem responde automaticamente</strong> às mensagens recebidas. Não transmite a mensagem: o visitante ainda precisa pressionar Enviar no WhatsApp. Para conversa automatizada por IA dentro do WhatsApp, será necessária integração adicional com a plataforma oficial.</p>
            <?php settings_errors(self::OPTION); ?>
            <form method="post" action="options.php">
                <?php settings_fields('ga_wa_assistente_group'); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="ga-wa-phone">Número do WhatsApp Business</label></th>
                        <td>
                            <input id="ga-wa-phone" name="<?php echo esc_attr(self::OPTION); ?>[phone]" type="tel" class="regular-text" value="<?php echo esc_attr($s['phone']); ?>" inputmode="numeric" autocomplete="tel" />
                            <p class="description">Formato internacional, somente números. Valor predefinido a partir do número profissional anteriormente informado: 5562991340228 (+55 62 99134-0228). Confirme que esse número já está ativo no WhatsApp Business antes da publicação definitiva.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="ga-wa-button">Texto do botão</label></th>
                        <td><input id="ga-wa-button" name="<?php echo esc_attr(self::OPTION); ?>[button_label]" type="text" class="regular-text" value="<?php echo esc_attr($s['button_label']); ?>" maxlength="70" /></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="ga-wa-title">Título do painel</label></th>
                        <td><input id="ga-wa-title" name="<?php echo esc_attr(self::OPTION); ?>[panel_title]" type="text" class="regular-text" value="<?php echo esc_attr($s['panel_title']); ?>" maxlength="120" /></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="ga-wa-welcome">Mensagem de abertura</label></th>
                        <td><textarea id="ga-wa-welcome" name="<?php echo esc_attr(self::OPTION); ?>[welcome]" class="large-text" rows="4"><?php echo esc_textarea($s['welcome']); ?></textarea></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="ga-wa-privacy">Aviso de privacidade e urgência</label></th>
                        <td><textarea id="ga-wa-privacy" name="<?php echo esc_attr(self::OPTION); ?>[privacy_note]" class="large-text" rows="4"><?php echo esc_textarea($s['privacy_note']); ?></textarea></td>
                    </tr>
                    <tr>
                        <th scope="row">Exibição</th>
                        <td><label><input name="<?php echo esc_attr(self::OPTION); ?>[enabled]" type="checkbox" value="1" <?php checked((int) $s['enabled'], 1); ?> /> Mostrar o painel flutuante no site</label></td>
                    </tr>
                    <tr>
                        <th scope="row">Perguntas e opções de triagem</th>
                        <td>
                            <p class="description">Edite os rótulos e as mensagens que serão preparadas no WhatsApp. A conversa fica natural e acolhedora, mas o atendimento inicial continua identificado como digital.</p>
                            <?php foreach (self::topics() as $topic) : ?>
                                <fieldset style="padding:12px;margin:0 0 12px;border:1px solid #dcdcde;max-width:850px">
                                    <legend><strong><?php echo esc_html($topic['id']); ?></strong></legend>
                                    <p><label for="ga-wa-topic-<?php echo esc_attr($topic['id']); ?>-label">Texto da opção</label><br />
                                    <input id="ga-wa-topic-<?php echo esc_attr($topic['id']); ?>-label" class="large-text" type="text" maxlength="100" name="<?php echo esc_attr(self::OPTION); ?>[topics][<?php echo esc_attr($topic['id']); ?>][label]" value="<?php echo esc_attr($topic['label']); ?>" /></p>
                                    <p><label for="ga-wa-topic-<?php echo esc_attr($topic['id']); ?>-message">Mensagem preparada para o WhatsApp</label><br />
                                    <textarea id="ga-wa-topic-<?php echo esc_attr($topic['id']); ?>-message" class="large-text" rows="2" name="<?php echo esc_attr(self::OPTION); ?>[topics][<?php echo esc_attr($topic['id']); ?>][message]"><?php echo esc_textarea($topic['message']); ?></textarea></p>
                                </fieldset>
                            <?php endforeach; ?>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Salvar configurações'); ?>
            </form>
            <hr />
            <h2>O que esta versão faz</h2>
            <ul style="list-style:disc;padding-left:24px;max-width:900px">
                <li>Mostra um botão em todas as páginas públicas e oferece assuntos para facilitar a triagem.</li>
                <li>Prepara mensagem e informa a página de origem, sem armazenar dados do visitante.</li>
                <li>Não carrega scripts externos, não utiliza cookies próprios e não envia mensagem sem ação do visitante.</li>
                <li>Utiliza linguagem acolhedora, mas identifica o atendimento inicial como digital; não finge ser uma pessoa nem simula que um advogado já leu a mensagem.</li>
                <li>Não substitui uma integração de IA com a API oficial do WhatsApp Business. Para respostas automáticas dentro do próprio WhatsApp, será necessária uma camada adicional de integração, autorização e testes.</li>
            </ul>
            <p><strong>Shortcode opcional:</strong> <code>[garibalde_whatsapp]</code> — adiciona um botão de abertura do mesmo painel dentro de uma página ou artigo.</p>
        </div>
        <?php
    }

    private static function default_topics() {
        return array(
            array('id' => 'novo', 'label' => 'Quero saber se o escritório pode me ajudar', 'message' => 'Quero saber como funciona o primeiro atendimento e quais informações devo enviar.'),
            array('id' => 'empresarial', 'label' => 'Preciso tratar de empresa, contrato ou tributos', 'message' => 'Meu assunto envolve empresa, contrato ou questão tributária. Gostaria de saber quais informações são necessárias para o primeiro atendimento.'),
            array('id' => 'imovel', 'label' => 'Meu assunto envolve imóvel, área rural ou condomínio', 'message' => 'Meu assunto envolve imóvel, área rural, condomínio ou regularização patrimonial. Gostaria de saber como encaminhar as informações iniciais.'),
            array('id' => 'beneficio', 'label' => 'Quero informações sobre aposentadoria ou isenção de IR', 'message' => 'Meu assunto envolve aposentadoria ou possível isenção de Imposto de Renda. Qual é o próximo passo? Não enviarei dados médicos neste primeiro contato.'),
            array('id' => 'cliente', 'label' => 'Já sou cliente e preciso falar de um assunto em andamento', 'message' => 'Já sou cliente e preciso tratar de um assunto em andamento. Como devo me identificar e qual canal seguro devo utilizar?'),
            array('id' => 'urgente', 'label' => 'Tenho prazo, audiência ou outra urgência', 'message' => 'Tenho possível prazo, audiência ou outra urgência. Preciso informar a data aproximada e solicitar encaminhamento prioritário. Compreendo que esta mensagem, por si só, não confirma contratação nem assunção de prazo pelo escritório.'),
            array('id' => 'outro', 'label' => 'É outro assunto ou preciso de uma informação do escritório', 'message' => 'Tenho outra dúvida institucional ou preciso de informação sobre o atendimento. Qual é o próximo passo?'),
        );
    }

    private static function topics() {
        $settings = self::settings();
        $saved = isset($settings['topics']) && is_array($settings['topics']) ? $settings['topics'] : array();
        $defaults = self::default_topics();
        $by_id = array();
        foreach ($saved as $item) {
            if (is_array($item) && isset($item['id'])) {
                $by_id[(string) $item['id']] = $item;
            }
        }
        $topics = array();
        foreach ($defaults as $topic) {
            if (isset($by_id[$topic['id']])) {
                $topic['label'] = isset($by_id[$topic['id']]['label']) ? (string) $by_id[$topic['id']]['label'] : $topic['label'];
                $topic['message'] = isset($by_id[$topic['id']]['message']) ? (string) $by_id[$topic['id']]['message'] : $topic['message'];
            }
            $topics[] = $topic;
        }
        return $topics;
    }

    private static function wa_url($s, $topic) {
        $phone = preg_replace('/\D+/', '', (string) $s['phone']);
        $page_title = wp_get_document_title();
        $page_url = get_permalink();
        if (!$page_url) {
            $page_url = home_url('/');
        }
        // Keep a single greeting. Topic text is intentionally a subject, not another greeting.
        $message = "Olá! Vim pelo site da Garibalde Amaral Advogados Associados.\n\nAssunto: " . $topic['message'] . "\n\nOrigem: " . $page_url;
        return 'https://wa.me/' . rawurlencode($phone) . '?text=' . rawurlencode($message);
    }

    public static function shortcode() {
        $s = self::settings();
        if (empty($s['enabled'])) {
            return '';
        }
        return '<button type="button" class="ga-wa-shortcode-trigger" data-ga-wa-open="1">' . esc_html($s['button_label']) . '</button>';
    }

    public static function render_widget() {
        if (is_admin()) {
            return;
        }
        $s = self::settings();
        if (empty($s['enabled'])) {
            return;
        }
        $topics = self::topics();
        $panel_id = 'ga-wa-panel';
        ?>
        <div id="ga-wa-root" class="ga-wa-root">
            <button type="button" id="ga-wa-launcher" class="ga-wa-launcher" aria-haspopup="dialog" aria-expanded="false" aria-controls="<?php echo esc_attr($panel_id); ?>">
                <span class="ga-wa-icon" aria-hidden="true">
                    <svg viewBox="0 0 32 32" width="25" height="25" focusable="false" aria-hidden="true"><path fill="currentColor" d="M16.02 3.2A12.3 12.3 0 0 0 5.45 21.8L3.8 28l6.38-1.62A12.3 12.3 0 1 0 16.02 3.2Zm0 22.47a10.1 10.1 0 0 1-5.16-1.42l-.37-.22-3.79.96 1.01-3.69-.24-.38a10.1 10.1 0 1 1 8.55 4.75Zm5.55-7.57c-.3-.15-1.78-.88-2.06-.98-.28-.1-.48-.15-.68.15-.2.3-.78.98-.95 1.18-.17.2-.35.22-.65.07-.3-.15-1.26-.46-2.4-1.47-.89-.79-1.49-1.77-1.66-2.07-.17-.3-.02-.46.13-.6.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.03-.52-.08-.15-.68-1.63-.93-2.23-.25-.6-.5-.51-.68-.52h-.58c-.2 0-.52.07-.8.37-.28.3-1.04 1.02-1.04 2.5s1.07 2.9 1.22 3.1c.15.2 2.1 3.2 5.08 4.49.71.31 1.26.5 1.69.64.71.23 1.36.2 1.88.12.57-.08 1.78-.73 2.03-1.43.25-.7.25-1.3.17-1.43-.08-.13-.28-.2-.58-.35Z"/></svg>
                </span>
                <span><?php echo esc_html($s['button_label']); ?></span>
            </button>
            <section id="<?php echo esc_attr($panel_id); ?>" class="ga-wa-panel" role="dialog" aria-modal="false" aria-labelledby="ga-wa-heading" aria-describedby="ga-wa-welcome" hidden>
                <header class="ga-wa-panel-header">
                    <div>
                        <div class="ga-wa-brand">GARIBALDE AMARAL</div>
                        <h2 id="ga-wa-heading"><?php echo esc_html($s['panel_title']); ?></h2>
                    </div>
                    <button type="button" class="ga-wa-close" aria-label="Fechar atendimento" data-ga-wa-close="1">×</button>
                </header>
                <div class="ga-wa-panel-body">
                    <p id="ga-wa-welcome" class="ga-wa-welcome"><?php echo nl2br(esc_html($s['welcome'])); ?></p>
                    <div class="ga-wa-topics" aria-label="Escolha um assunto">
                        <?php foreach ($topics as $topic) : ?>
                            <a class="ga-wa-topic" href="<?php echo esc_url(self::wa_url($s, $topic)); ?>" target="_blank" rel="noopener noreferrer">
                                <span><?php echo esc_html($topic['label']); ?></span><span class="ga-wa-arrow" aria-hidden="true">↗</span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                    <p class="ga-wa-privacy"><?php echo nl2br(esc_html($s['privacy_note'])); ?></p>
                    <p class="ga-wa-footer">A mensagem só será enviada se você confirmar o envio no WhatsApp.</p>
                </div>
            </section>
        </div>
        <style id="ga-wa-styles">
            .ga-wa-root{font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;position:fixed;right:20px;bottom:92px;z-index:99990;color:#202536}
            .ga-wa-launcher{position:relative;isolation:isolate;display:flex;align-items:center;gap:10px;border:1px solid #c8a36a;border-radius:999px;background:#182234;color:#fff;padding:12px 17px;box-shadow:0 8px 24px rgba(0,0,0,.22);font-size:14px;font-weight:650;cursor:pointer;line-height:1.25;max-width:calc(100vw - 36px);animation:ga-wa-attention-bob 6.5s ease-in-out infinite}
            .ga-wa-launcher > span{position:relative;z-index:1}
            .ga-wa-launcher::after{content:"";position:absolute;inset:-4px;border:1.5px solid rgba(37,211,102,.65);border-radius:inherit;pointer-events:none;z-index:0;opacity:0;animation:ga-wa-attention-ring 6.5s ease-out infinite}
            .ga-wa-launcher[aria-expanded="true"]{animation:none}
            .ga-wa-launcher[aria-expanded="true"]::after{animation:none;opacity:0}
            @keyframes ga-wa-attention-bob{0%,76%,100%{transform:translateY(0)}80%{transform:translateY(-3px)}84%{transform:translateY(0)}89%{transform:translateY(-2px)}93%{transform:translateY(0)}}
            @keyframes ga-wa-attention-ring{0%,75%,100%{opacity:0;transform:scale(1)}79%{opacity:.52}94%{opacity:0;transform:scale(1.12)}}
            .ga-wa-launcher:hover,.ga-wa-launcher:focus-visible{background:#24324a;outline:3px solid rgba(200,163,106,.4);outline-offset:2px}
            .ga-wa-icon{color:#25d366;display:inline-flex;align-items:center;justify-content:center;flex:0 0 25px}
            .ga-wa-panel{position:absolute;right:0;bottom:62px;width:min(390px,calc(100vw - 28px));max-height:min(76vh,710px);overflow:auto;border:1px solid #d8c6a6;border-radius:18px;background:#fff;box-shadow:0 18px 55px rgba(12,19,32,.3);color:#202536}
            .ga-wa-panel[hidden]{display:none!important}
            .ga-wa-panel-header{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;background:#182234;color:#fff;padding:18px 18px 16px;border-bottom:3px solid #c8a36a}
            .ga-wa-brand{font-size:10px;letter-spacing:.18em;color:#e1c28d;font-weight:750;margin-bottom:6px}
            .ga-wa-panel-header h2{font-family:Georgia,"Times New Roman",serif;font-size:20px;line-height:1.2;color:#fff;margin:0;max-width:285px}
            .ga-wa-close{border:0;background:transparent;color:#fff;font-size:28px;line-height:1;cursor:pointer;padding:0 3px}
            .ga-wa-panel-body{padding:16px}
            .ga-wa-welcome{margin:0 0 14px;font-size:13px;line-height:1.55;color:#384152}
            .ga-wa-topics{display:grid;gap:8px}
            .ga-wa-topic{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:11px 12px;border:1px solid #e5e7eb;border-radius:10px;text-decoration:none!important;background:#fbfaf7;color:#182234!important;font-size:13px;line-height:1.35;font-weight:650}
            .ga-wa-topic:hover,.ga-wa-topic:focus-visible{border-color:#b28a4b;background:#fff8eb;outline:2px solid rgba(178,138,75,.25)}
            .ga-wa-arrow{color:#96703a;font-size:17px;flex:0 0 auto}
            .ga-wa-privacy{margin:14px 0 6px;padding:10px 11px;background:#f5f3ef;border-left:3px solid #c8a36a;font-size:11px;line-height:1.5;color:#4b5563}
            .ga-wa-footer{margin:8px 0 0;font-size:10px;line-height:1.4;color:#6b7280}
            .ga-wa-shortcode-trigger{background:#182234;color:#fff;border:1px solid #c8a36a;border-radius:999px;padding:11px 16px;cursor:pointer;font-weight:650}
            @media(max-width:600px){.ga-wa-root{right:12px;bottom:88px}.ga-wa-launcher{padding:11px 13px;font-size:13px}.ga-wa-panel{right:0;bottom:58px;max-height:72vh}.ga-wa-panel-header h2{font-size:18px}}
            @media(prefers-reduced-motion:reduce){.ga-wa-root *{scroll-behavior:auto!important;animation:none!important;transition:none!important}}
        </style>
        <script id="ga-wa-script">
        (function(){
          var root=document.getElementById('ga-wa-root'); if(!root){return;}
          var panel=document.getElementById('ga-wa-panel');
          var launcher=document.getElementById('ga-wa-launcher');
          var closeButtons=root.querySelectorAll('[data-ga-wa-close]');
          function openPanel(){panel.hidden=false;launcher.setAttribute('aria-expanded','true');var first=panel.querySelector('.ga-wa-close');if(first){first.focus();}}
          function closePanel(){panel.hidden=true;launcher.setAttribute('aria-expanded','false');launcher.focus();}
          launcher.addEventListener('click',function(){if(panel.hidden){openPanel();}else{closePanel();}});
          closeButtons.forEach(function(btn){btn.addEventListener('click',closePanel);});
          document.addEventListener('keydown',function(e){if(e.key==='Escape'&&!panel.hidden){closePanel();}});
          document.querySelectorAll('[data-ga-wa-open="1"]').forEach(function(btn){btn.addEventListener('click',function(){openPanel();});});
          document.addEventListener('click',function(e){if(!panel.hidden&&!root.contains(e.target)&&!e.target.closest('[data-ga-wa-open="1"]')){panel.hidden=true;launcher.setAttribute('aria-expanded','false');}});
        })();
        </script>
        <?php
    }
}

Garibalde_WhatsApp_Assistente::init();
